import { EventBridgeEvent, Context } from 'aws-lambda';
import { Logger, PerformanceMonitor } from '../services/logger.service';
import { ResponseUtil, ErrorHandler } from '../utils/response.util';
import { TimeService } from '../services/time.service';
import axios from 'axios';

/**
 * 배치 작업 Lambda 핸들러
 * EventBridge Scheduler에 의해 트리거되는 배치 작업 처리
 */

interface BatchJobPayload {
  jobType: 'cache_refresh' | 'cache_cleanup' | 'stats_aggregation';
  targetDate?: string;
  parameters?: Record<string, any>;
}

interface BatchJobResponse {
  jobId: string;
  jobType: string;
  status: 'completed' | 'failed' | 'partial_failure';
  processedCount: number;
  errorCount: number;
  startedAt: string;
  completedAt: string;
  errors: string[];
}

/**
 * 메인 핸들러
 */
export const handler = ErrorHandler.asyncHandler(
  async (event: EventBridgeEvent<string, BatchJobPayload>, context: Context): Promise<void> => {
    const correlationId = `batch-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const logger = new Logger(correlationId, context.functionName);
    const monitor = new PerformanceMonitor(logger, `batch-${event.detail.jobType}`);

    try {
      logger.info('배치 작업 시작', {
        jobType: event.detail.jobType,
        targetDate: event.detail.targetDate,
        source: event.source,
        account: event.account
      });

      let result: BatchJobResponse;

      switch (event.detail.jobType) {
        case 'cache_refresh':
          result = await handleCacheRefresh(event.detail, logger);
          break;
        case 'cache_cleanup':
          result = await handleCacheCleanup(event.detail, logger);
          break;
        case 'stats_aggregation':
          result = await handleStatsAggregation(event.detail, logger);
          break;
        default:
          throw new Error(`Unknown job type: ${event.detail.jobType}`);
      }

      monitor.recordSuccess();
      
      logger.info('배치 작업 완료', {
        jobId: result.jobId,
        jobType: result.jobType,
        status: result.status,
        processedCount: result.processedCount,
        errorCount: result.errorCount,
        duration: monitor.getElapsedTime()
      });

      // CloudWatch 메트릭 전송
      await sendBatchMetrics(result, logger);

    } catch (error) {
      monitor.recordFailure(error as Error);
      logger.error('배치 작업 실패', error as Error, {
        jobType: event.detail.jobType,
        duration: monitor.getElapsedTime()
      });
      
      // 실패 알람 전송
      await sendFailureAlarm(event.detail.jobType, error as Error, logger);
      
      throw error;
    }
  }
);

/**
 * 캐시 갱신 배치 작업
 */
async function handleCacheRefresh(
  payload: BatchJobPayload,
  logger: Logger
): Promise<BatchJobResponse> {
  const targetDate = payload.targetDate || TimeService.formatDateKST();
  const fastApiUrl = process.env.EC2_ENGINE_URL;
  
  if (!fastApiUrl) {
    throw new Error('EC2_ENGINE_URL 환경변수가 설정되지 않았습니다');
  }

  try {
    logger.info('FastAPI 서비스 캐시 갱신 요청', {
      url: fastApiUrl,
      targetDate
    });

    // FastAPI 배치 서비스 호출
    const response = await axios.post(
      `${fastApiUrl}/api/v1/batch/cache-refresh`,
      {
        targetDate,
        maxConcurrent: payload.parameters?.maxConcurrent || 10
      },
      {
        timeout: 300000, // 5분 타임아웃
        headers: {
          'Content-Type': 'application/json',
          'X-Correlation-Id': logger['correlationId']
        }
      }
    );

    return response.data;

  } catch (error) {
    logger.error('FastAPI 캐시 갱신 실패', error as Error);
    
    if (axios.isAxiosError(error)) {
      const status = error.response?.status;
      const data = error.response?.data;
      
      throw new Error(`FastAPI 호출 실패: ${status} - ${JSON.stringify(data)}`);
    }
    
    throw error;
  }
}

/**
 * 캐시 정리 배치 작업
 */
async function handleCacheCleanup(
  payload: BatchJobPayload,
  logger: Logger
): Promise<BatchJobResponse> {
  const fastApiUrl = process.env.EC2_ENGINE_URL;
  
  if (!fastApiUrl) {
    throw new Error('EC2_ENGINE_URL 환경변수가 설정되지 않았습니다');
  }

  try {
    logger.info('FastAPI 서비스 캐시 정리 요청');

    const response = await axios.post(
      `${fastApiUrl}/api/v1/batch/cache-cleanup`,
      {},
      {
        timeout: 60000, // 1분 타임아웃
        headers: {
          'Content-Type': 'application/json',
          'X-Correlation-Id': logger['correlationId']
        }
      }
    );

    return response.data;

  } catch (error) {
    logger.error('FastAPI 캐시 정리 실패', error as Error);
    throw error;
  }
}

/**
 * 통계 집계 배치 작업 (B2B용)
 */
async function handleStatsAggregation(
  payload: BatchJobPayload,
  logger: Logger
): Promise<BatchJobResponse> {
  // B2B 통계 집계는 향후 구현
  logger.info('통계 집계 작업은 아직 구현되지 않았습니다');
  
  return {
    jobId: `stats-${Date.now()}`,
    jobType: 'stats_aggregation',
    status: 'completed',
    processedCount: 0,
    errorCount: 0,
    startedAt: TimeService.nowKST(),
    completedAt: TimeService.nowKST(),
    errors: []
  };
}

/**
 * 배치 메트릭 전송
 */
async function sendBatchMetrics(
  result: BatchJobResponse,
  logger: Logger
): Promise<void> {
  try {
    const { CloudWatchClient, PutMetricDataCommand } = await import('@aws-sdk/client-cloudwatch');
    const cloudWatch = new CloudWatchClient({ region: process.env.AWS_REGION || 'us-east-1' });

    const metrics = [
      {
        MetricName: 'BatchJobCount',
        Dimensions: [
          { Name: 'JobType', Value: result.jobType },
          { Name: 'Status', Value: result.status }
        ],
        Value: 1,
        Unit: 'Count'
      },
      {
        MetricName: 'BatchProcessedCount',
        Dimensions: [
          { Name: 'JobType', Value: result.jobType }
        ],
        Value: result.processedCount,
        Unit: 'Count'
      },
      {
        MetricName: 'BatchErrorCount',
        Dimensions: [
          { Name: 'JobType', Value: result.jobType }
        ],
        Value: result.errorCount,
        Unit: 'Count'
      }
    ];

    await cloudWatch.send(new PutMetricDataCommand({
      Namespace: 'ShiftSleep/Batch',
      MetricData: metrics
    }));

    logger.info('배치 메트릭 전송 완료', {
      jobType: result.jobType,
      metricsCount: metrics.length
    });

  } catch (error) {
    logger.error('배치 메트릭 전송 실패', error as Error);
    // 메트릭 전송 실패는 배치 작업 실패로 처리하지 않음
  }
}

/**
 * 실패 알람 전송
 */
async function sendFailureAlarm(
  jobType: string,
  error: Error,
  logger: Logger
): Promise<void> {
  try {
    const { SNSClient, PublishCommand } = await import('@aws-sdk/client-sns');
    const sns = new SNSClient({ region: process.env.AWS_REGION || 'us-east-1' });

    const topicArn = process.env.BATCH_FAILURE_TOPIC_ARN;
    if (!topicArn) {
      logger.warn('BATCH_FAILURE_TOPIC_ARN이 설정되지 않아 알람을 전송하지 않습니다');
      return;
    }

    const message = {
      jobType,
      error: error.message,
      timestamp: TimeService.nowKST(),
      correlationId: logger['correlationId']
    };

    await sns.send(new PublishCommand({
      TopicArn: topicArn,
      Subject: `[ShiftSleep] 배치 작업 실패: ${jobType}`,
      Message: JSON.stringify(message, null, 2)
    }));

    logger.info('실패 알람 전송 완료', { jobType });

  } catch (alarmError) {
    logger.error('실패 알람 전송 실패', alarmError as Error);
    // 알람 전송 실패는 배치 작업 실패로 처리하지 않음
  }
}