"""
시간 처리 유틸리티
"""

from datetime import datetime, timedelta, date
from typing import Union
import pytz

# KST 타임존
KST = pytz.timezone('Asia/Seoul')


class TimeUtils:
    """시간 처리 유틸리티 클래스"""
    
    @staticmethod
    def now_kst() -> str:
        """현재 KST 시간을 ISO 8601 형식으로 반환"""
        now = datetime.now(KST)
        return now.strftime('%Y-%m-%dT%H:%M:%S+09:00')
    
    @staticmethod
    def today_kst() -> str:
        """오늘 날짜를 YYYY-MM-DD 형식으로 반환"""
        today = datetime.now(KST).date()
        return today.isoformat()
    
    @staticmethod
    def format_datetime(dt: datetime) -> str:
        """datetime을 KST ISO 8601 형식으로 변환"""
        if dt.tzinfo is None:
            # naive datetime은 KST로 가정
            dt = KST.localize(dt)
        else:
            # 다른 타임존이면 KST로 변환
            dt = dt.astimezone(KST)
        
        return dt.strftime('%Y-%m-%dT%H:%M:%S+09:00')
    
    @staticmethod
    def format_date(d: date) -> str:
        """date를 YYYY-MM-DD 형식으로 변환"""
        return d.isoformat()
    
    @staticmethod
    def parse_datetime(dt_str: str) -> datetime:
        """ISO 8601 문자열을 datetime으로 파싱"""
        try:
            # ISO 8601 형식 파싱
            if dt_str.endswith('+09:00'):
                dt_str = dt_str[:-6]  # 타임존 제거
                dt = datetime.fromisoformat(dt_str)
                return KST.localize(dt)
            elif 'T' in dt_str:
                dt = datetime.fromisoformat(dt_str)
                if dt.tzinfo is None:
                    return KST.localize(dt)
                return dt.astimezone(KST)
            else:
                # 날짜만 있는 경우
                d = date.fromisoformat(dt_str)
                dt = datetime.combine(d, datetime.min.time())
                return KST.localize(dt)
        except ValueError as e:
            raise ValueError(f"Invalid datetime format: {dt_str}") from e
    
    @staticmethod
    def parse_date(date_str: str) -> date:
        """YYYY-MM-DD 문자열을 date로 파싱"""
        try:
            return date.fromisoformat(date_str)
        except ValueError as e:
            raise ValueError(f"Invalid date format: {date_str}") from e
    
    @staticmethod
    def add_hours(dt: datetime, hours: float) -> datetime:
        """datetime에 시간 추가"""
        return dt + timedelta(hours=hours)
    
    @staticmethod
    def subtract_hours(dt: datetime, hours: float) -> datetime:
        """datetime에서 시간 빼기"""
        return dt - timedelta(hours=hours)
    
    @staticmethod
    def add_minutes(dt: datetime, minutes: int) -> datetime:
        """datetime에 분 추가"""
        return dt + timedelta(minutes=minutes)
    
    @staticmethod
    def subtract_minutes(dt: datetime, minutes: int) -> datetime:
        """datetime에서 분 빼기"""
        return dt - timedelta(minutes=minutes)
    
    @staticmethod
    def add_days(d: date, days: int) -> date:
        """date에 일 추가"""
        return d + timedelta(days=days)
    
    @staticmethod
    def subtract_days(d: date, days: int) -> date:
        """date에서 일 빼기"""
        return d - timedelta(days=days)
    
    @staticmethod
    def format_date_kst(dt: datetime = None) -> str:
        """KST 기준 날짜를 YYYY-MM-DD 형식으로 반환"""
        if dt is None:
            dt = datetime.now(KST)
        elif dt.tzinfo is None:
            dt = KST.localize(dt)
        else:
            dt = dt.astimezone(KST)
        
        return dt.date().isoformat()
    
    @staticmethod
    def is_same_date(dt1: datetime, dt2: datetime) -> bool:
        """두 datetime이 같은 날짜인지 확인 (KST 기준)"""
        date1 = TimeUtils.format_date_kst(dt1)
        date2 = TimeUtils.format_date_kst(dt2)
        return date1 == date2
    
    @staticmethod
    def get_week_start(d: date = None) -> date:
        """주의 시작일 (월요일) 반환"""
        if d is None:
            d = datetime.now(KST).date()
        
        days_since_monday = d.weekday()
        return d - timedelta(days=days_since_monday)
    
    @staticmethod
    def get_week_end(d: date = None) -> date:
        """주의 마지막일 (일요일) 반환"""
        week_start = TimeUtils.get_week_start(d)
        return week_start + timedelta(days=6)
    
    @staticmethod
    def get_month_start(d: date = None) -> date:
        """월의 시작일 반환"""
        if d is None:
            d = datetime.now(KST).date()
        
        return d.replace(day=1)
    
    @staticmethod
    def get_month_end(d: date = None) -> date:
        """월의 마지막일 반환"""
        if d is None:
            d = datetime.now(KST).date()
        
        # 다음 달 첫날에서 하루 빼기
        if d.month == 12:
            next_month = d.replace(year=d.year + 1, month=1, day=1)
        else:
            next_month = d.replace(month=d.month + 1, day=1)
        
        return next_month - timedelta(days=1)
    
    @staticmethod
    def calculate_duration_hours(start: datetime, end: datetime) -> float:
        """두 시간 사이의 시간 차이를 시간 단위로 계산"""
        duration = end - start
        return duration.total_seconds() / 3600
    
    @staticmethod
    def is_night_time(dt: datetime) -> bool:
        """야간 시간대인지 확인 (22:00 - 06:00)"""
        if dt.tzinfo is None:
            dt = KST.localize(dt)
        else:
            dt = dt.astimezone(KST)
        
        hour = dt.hour
        return hour >= 22 or hour < 6
    
    @staticmethod
    def is_work_hours(dt: datetime) -> bool:
        """일반적인 근무 시간대인지 확인 (09:00 - 18:00)"""
        if dt.tzinfo is None:
            dt = KST.localize(dt)
        else:
            dt = dt.astimezone(KST)
        
        hour = dt.hour
        return 9 <= hour < 18
    
    @staticmethod
    def get_sleep_quality_time_score(sleep_start: datetime) -> int:
        """수면 시작 시간에 따른 품질 점수 (0-100)"""
        if sleep_start.tzinfo is None:
            sleep_start = KST.localize(sleep_start)
        else:
            sleep_start = sleep_start.astimezone(KST)
        
        hour = sleep_start.hour
        
        # 최적 수면 시간대: 22:00 - 24:00
        if 22 <= hour <= 23:
            return 100
        # 양호한 시간대: 21:00 - 22:00, 00:00 - 01:00
        elif hour == 21 or hour == 0:
            return 80
        # 보통 시간대: 20:00 - 21:00, 01:00 - 02:00
        elif hour == 20 or hour == 1:
            return 60
        # 나쁜 시간대: 그 외
        else:
            return 40