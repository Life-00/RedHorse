"""
수면 계산 유틸리티
"""

from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
from .time_utils import TimeUtils


class SleepCalculator:
    """수면 관련 계산 유틸리티"""
    
    # 수면 단계별 시간 (분)
    SLEEP_CYCLE_MINUTES = 90  # 한 수면 주기
    LIGHT_SLEEP_MINUTES = 20  # 얕은 잠 단계
    DEEP_SLEEP_MINUTES = 60   # 깊은 잠 단계
    REM_SLEEP_MINUTES = 10    # REM 수면 단계
    
    # 권장 수면 시간 (시간)
    RECOMMENDED_SLEEP_HOURS = {
        "adult": 8.0,
        "shift_worker": 7.5,  # 교대근무자는 약간 적게
        "night_worker": 7.0   # 야간근무자
    }
    
    @staticmethod
    def calculate_optimal_sleep_duration(
        work_start: datetime,
        work_duration_hours: float,
        commute_minutes: int,
        is_night_shift: bool = False
    ) -> float:
        """최적 수면 시간 계산"""
        
        base_sleep = SleepCalculator.RECOMMENDED_SLEEP_HOURS["adult"]
        
        # 교대근무 조정
        if is_night_shift:
            base_sleep = SleepCalculator.RECOMMENDED_SLEEP_HOURS["night_worker"]
        else:
            base_sleep = SleepCalculator.RECOMMENDED_SLEEP_HOURS["shift_worker"]
        
        # 근무 시간에 따른 조정
        if work_duration_hours > 10:
            base_sleep += 0.5  # 장시간 근무 시 추가 수면
        elif work_duration_hours < 6:
            base_sleep -= 0.5  # 단시간 근무 시 수면 감소
        
        # 통근 시간에 따른 조정
        if commute_minutes > 60:
            base_sleep += 0.25  # 장거리 통근 시 추가 수면
        
        return max(6.0, min(9.0, base_sleep))  # 6-9시간 범위로 제한
    
    @staticmethod
    def calculate_sleep_cycles(sleep_duration_hours: float) -> int:
        """수면 시간에 따른 수면 주기 수 계산"""
        total_minutes = sleep_duration_hours * 60
        cycles = round(total_minutes / SleepCalculator.SLEEP_CYCLE_MINUTES)
        return max(4, min(6, cycles))  # 4-6 주기로 제한
    
    @staticmethod
    def find_optimal_wake_time(
        sleep_start: datetime,
        target_wake_time: datetime,
        flexibility_minutes: int = 30
    ) -> datetime:
        """수면 주기를 고려한 최적 기상 시간 찾기"""
        
        # 목표 기상 시간 기준으로 가능한 시간들 계산
        possible_times = []
        
        # 유연성 범위 내에서 수면 주기 끝나는 시간들 찾기
        start_check = target_wake_time - timedelta(minutes=flexibility_minutes)
        end_check = target_wake_time + timedelta(minutes=flexibility_minutes)
        
        current_time = sleep_start
        while current_time < end_check:
            current_time += timedelta(minutes=SleepCalculator.SLEEP_CYCLE_MINUTES)
            
            if start_check <= current_time <= end_check:
                possible_times.append(current_time)
        
        if not possible_times:
            # 유연성 범위에 없으면 가장 가까운 주기 시간 반환
            cycles_to_target = (target_wake_time - sleep_start).total_seconds() / 60 / SleepCalculator.SLEEP_CYCLE_MINUTES
            optimal_cycles = round(cycles_to_target)
            return sleep_start + timedelta(minutes=optimal_cycles * SleepCalculator.SLEEP_CYCLE_MINUTES)
        
        # 목표 시간에 가장 가까운 시간 선택
        return min(possible_times, key=lambda t: abs((t - target_wake_time).total_seconds()))
    
    @staticmethod
    def calculate_sleep_debt(
        actual_sleep_hours: List[float],
        days: int = 7
    ) -> Dict[str, float]:
        """수면 부채 계산"""
        
        if not actual_sleep_hours:
            return {"debt_hours": 0.0, "avg_sleep": 0.0, "recommended": 8.0}
        
        avg_sleep = sum(actual_sleep_hours) / len(actual_sleep_hours)
        recommended = SleepCalculator.RECOMMENDED_SLEEP_HOURS["adult"]
        
        # 일일 부족분 계산
        daily_deficits = [max(0, recommended - sleep) for sleep in actual_sleep_hours]
        total_debt = sum(daily_deficits)
        
        return {
            "debt_hours": round(total_debt, 1),
            "avg_sleep": round(avg_sleep, 1),
            "recommended": recommended,
            "daily_deficit": round(total_debt / len(actual_sleep_hours), 1)
        }
    
    @staticmethod
    def calculate_nap_timing(
        main_sleep_end: datetime,
        work_start: datetime,
        nap_duration_minutes: int = 20
    ) -> Optional[Tuple[datetime, datetime]]:
        """파워냅 최적 타이밍 계산"""
        
        # 메인 수면 종료 후 최소 4시간, 최대 8시간 후
        earliest_nap = main_sleep_end + timedelta(hours=4)
        latest_nap = main_sleep_end + timedelta(hours=8)
        
        # 근무 시작 2시간 전까지만 가능
        work_buffer = work_start - timedelta(hours=2)
        
        if latest_nap > work_buffer:
            latest_nap = work_buffer
        
        if earliest_nap >= latest_nap:
            return None  # 낮잠 불가능
        
        # 최적 시간: 메인 수면 후 5-6시간
        optimal_start = main_sleep_end + timedelta(hours=5.5)
        
        if earliest_nap <= optimal_start <= latest_nap:
            nap_start = optimal_start
        else:
            # 가능한 범위의 중간점
            nap_start = earliest_nap + (latest_nap - earliest_nap) / 2
        
        nap_end = nap_start + timedelta(minutes=nap_duration_minutes)
        
        return (nap_start, nap_end)
    
    @staticmethod
    def evaluate_sleep_timing_quality(
        sleep_start: datetime,
        sleep_end: datetime,
        work_start: datetime
    ) -> Dict[str, any]:
        """수면 타이밍 품질 평가"""
        
        # 수면 시작 시간 점수
        start_score = TimeUtils.get_sleep_quality_time_score(sleep_start)
        
        # 수면 시간 점수
        duration_hours = TimeUtils.calculate_duration_hours(sleep_start, sleep_end)
        if 7 <= duration_hours <= 9:
            duration_score = 100
        elif 6 <= duration_hours < 7 or 9 < duration_hours <= 10:
            duration_score = 80
        elif 5 <= duration_hours < 6 or 10 < duration_hours <= 11:
            duration_score = 60
        else:
            duration_score = 40
        
        # 근무 전 여유 시간 점수
        buffer_hours = TimeUtils.calculate_duration_hours(sleep_end, work_start)
        if buffer_hours >= 2:
            buffer_score = 100
        elif buffer_hours >= 1.5:
            buffer_score = 80
        elif buffer_hours >= 1:
            buffer_score = 60
        else:
            buffer_score = 40
        
        # 전체 점수 (가중 평균)
        total_score = (start_score * 0.4 + duration_score * 0.4 + buffer_score * 0.2)
        
        # 품질 등급
        if total_score >= 90:
            quality = "excellent"
        elif total_score >= 75:
            quality = "good"
        elif total_score >= 60:
            quality = "fair"
        else:
            quality = "poor"
        
        return {
            "quality": quality,
            "score": round(total_score, 1),
            "breakdown": {
                "timing": start_score,
                "duration": duration_score,
                "buffer": buffer_score
            },
            "duration_hours": round(duration_hours, 1),
            "buffer_hours": round(buffer_hours, 1)
        }
    
    @staticmethod
    def calculate_circadian_adjustment(
        current_sleep_time: datetime,
        target_sleep_time: datetime,
        adjustment_days: int = 7
    ) -> List[Dict[str, any]]:
        """생체리듬 조정 계획 생성"""
        
        time_diff = target_sleep_time - current_sleep_time
        total_shift_hours = time_diff.total_seconds() / 3600
        
        # 하루 최대 조정 시간 (1-2시간)
        max_daily_shift = 1.5 if abs(total_shift_hours) > 6 else 1.0
        
        # 조정 방향 결정
        if total_shift_hours > 0:
            # 늦게 자기 (지연)
            daily_shift = min(max_daily_shift, total_shift_hours / adjustment_days)
        else:
            # 일찍 자기 (전진)
            daily_shift = max(-max_daily_shift, total_shift_hours / adjustment_days)
        
        adjustment_plan = []
        current_time = current_sleep_time
        
        for day in range(adjustment_days):
            current_time += timedelta(hours=daily_shift)
            
            # 목표 시간에 도달했으면 고정
            if (daily_shift > 0 and current_time >= target_sleep_time) or \
               (daily_shift < 0 and current_time <= target_sleep_time):
                current_time = target_sleep_time
            
            adjustment_plan.append({
                "day": day + 1,
                "sleep_time": TimeUtils.format_datetime(current_time),
                "shift_hours": round(daily_shift, 1),
                "total_shifted": round((current_time - current_sleep_time).total_seconds() / 3600, 1)
            })
            
            # 목표 도달 시 중단
            if current_time == target_sleep_time:
                break
        
        return adjustment_plan
    
    @staticmethod
    def calculate_recovery_sleep(
        sleep_debt_hours: float,
        available_days: int = 2
    ) -> Dict[str, any]:
        """회복 수면 계획"""
        
        if sleep_debt_hours <= 0:
            return {"needed": False, "message": "수면 부채가 없습니다"}
        
        # 하루 최대 회복 가능 시간 (2시간)
        max_daily_recovery = 2.0
        
        # 필요한 회복 일수
        needed_days = min(available_days, int(sleep_debt_hours / max_daily_recovery) + 1)
        
        # 일일 회복 시간
        daily_recovery = min(max_daily_recovery, sleep_debt_hours / needed_days)
        
        recovery_plan = []
        remaining_debt = sleep_debt_hours
        
        for day in range(needed_days):
            recovery_amount = min(daily_recovery, remaining_debt)
            recommended_sleep = SleepCalculator.RECOMMENDED_SLEEP_HOURS["adult"] + recovery_amount
            
            recovery_plan.append({
                "day": day + 1,
                "recommended_sleep_hours": round(recommended_sleep, 1),
                "recovery_hours": round(recovery_amount, 1),
                "remaining_debt": round(remaining_debt - recovery_amount, 1)
            })
            
            remaining_debt -= recovery_amount
            
            if remaining_debt <= 0:
                break
        
        return {
            "needed": True,
            "total_debt_hours": sleep_debt_hours,
            "recovery_days": needed_days,
            "plan": recovery_plan,
            "message": f"{needed_days}일간 추가 수면으로 부채 해결 가능"
        }