"""
상관관계 ID 처리 유틸리티
"""

import uuid
from typing import Optional
from fastapi import Request


def generate_correlation_id() -> str:
    """새로운 상관관계 ID 생성"""
    timestamp = int(uuid.uuid1().time)
    random_part = uuid.uuid4().hex[:9]
    return f"req-{timestamp}-{random_part}"


def get_correlation_id(request: Request) -> str:
    """요청에서 상관관계 ID 추출 또는 생성"""
    correlation_id = (
        request.headers.get("X-Correlation-Id") or
        request.headers.get("x-correlation-id") or
        generate_correlation_id()
    )
    return correlation_id


def get_correlation_id_from_header(x_correlation_id: Optional[str]) -> str:
    """헤더에서 상관관계 ID 추출 또는 생성"""
    return x_correlation_id or generate_correlation_id()