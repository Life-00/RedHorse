"""
에러 처리 유틸리티
"""

import logging
from typing import Any, Dict
from fastapi import HTTPException
from fastapi.responses import JSONResponse

logger = logging.getLogger(__name__)


def create_error_response(error: Exception, correlation_id: str) -> JSONResponse:
    """표준화된 에러 응답 생성"""
    
    # HTTPException은 그대로 전달
    if isinstance(error, HTTPException):
        return JSONResponse(
            status_code=error.status_code,
            content={
                "error": {
                    "code": "HTTP_ERROR",
                    "message": error.detail
                },
                "correlationId": correlation_id
            },
            headers={"X-Correlation-Id": correlation_id}
        )
    
    # 기타 예외는 500으로 처리
    logger.error(f"Unhandled error: {error}", exc_info=True)
    
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": "INTERNAL_ERROR",
                "message": "서버 내부 오류가 발생했습니다"
            },
            "correlationId": correlation_id
        },
        headers={"X-Correlation-Id": correlation_id}
    )


def create_validation_error_response(
    message: str, 
    details: Dict[str, Any], 
    correlation_id: str
) -> JSONResponse:
    """검증 오류 응답 생성"""
    return JSONResponse(
        status_code=400,
        content={
            "error": {
                "code": "VALIDATION_ERROR",
                "message": message,
                "details": details
            },
            "correlationId": correlation_id
        },
        headers={"X-Correlation-Id": correlation_id}
    )


def create_authentication_error_response(
    message: str, 
    correlation_id: str
) -> JSONResponse:
    """인증 오류 응답 생성"""
    return JSONResponse(
        status_code=401,
        content={
            "error": {
                "code": "AUTHENTICATION_ERROR",
                "message": message
            },
            "correlationId": correlation_id
        },
        headers={"X-Correlation-Id": correlation_id}
    )


def create_authorization_error_response(
    message: str, 
    correlation_id: str
) -> JSONResponse:
    """권한 오류 응답 생성"""
    return JSONResponse(
        status_code=403,
        content={
            "error": {
                "code": "AUTHORIZATION_ERROR",
                "message": message
            },
            "correlationId": correlation_id
        },
        headers={"X-Correlation-Id": correlation_id}
    )