"""
엔진 API 라우터
3대 핵심 엔진 (Shift-to-Sleep, Caffeine Cutoff, Fatigue Risk) 엔드포인트
"""

from fastapi import APIRouter, Depends, HTTPException, Header
from typing import Optional
import logging

from ..models.common import (
    EngineResponse, ShiftToSleepRequest, CaffeineCutoffRequest, 
    FatigueRiskRequest, DailyJumpstartRequest, SleepQualityRequest,
    MealTimeRequest, EngineType
)
from ..services.auth_service import AuthService
from ..services.logger_service import LoggerService
from ..engines.shift_to_sleep import ShiftToSleepEngine
from ..engines.caffeine_cutoff import CaffeineCutoffEngine
from ..engines.fatigue_risk import FatigueRiskEngine
from ..engines.daily_jumpstart import DailyJumpstartEngine
from ..engines.sleep_quality import SleepQualityEngine
from ..engines.meal_time_checker import MealTimeCheckerEngine
from ..utils.correlation import get_correlation_id_from_header

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/engines")

# 전역 엔진 인스턴스 (main.py에서 주입)
shift_to_sleep_engine: Optional[ShiftToSleepEngine] = None
caffeine_cutoff_engine: Optional[CaffeineCutoffEngine] = None
fatigue_risk_engine: Optional[FatigueRiskEngine] = None
daily_jumpstart_engine: Optional[DailyJumpstartEngine] = None
sleep_quality_engine: Optional[SleepQualityEngine] = None
meal_time_checker_engine: Optional[MealTimeCheckerEngine] = None


def set_engines(
    shift_engine: ShiftToSleepEngine,
    caffeine_engine: CaffeineCutoffEngine,
    fatigue_engine: FatigueRiskEngine,
    jumpstart_engine: DailyJumpstartEngine,
    sleep_quality_engine_instance: SleepQualityEngine,
    meal_time_engine: MealTimeCheckerEngine
):
    """엔진 인스턴스 설정 (main.py에서 호출)"""
    global shift_to_sleep_engine, caffeine_cutoff_engine, fatigue_risk_engine
    global daily_jumpstart_engine, sleep_quality_engine, meal_time_checker_engine
    
    shift_to_sleep_engine = shift_engine
    caffeine_cutoff_engine = caffeine_engine
    fatigue_risk_engine = fatigue_engine
    daily_jumpstart_engine = jumpstart_engine
    sleep_quality_engine = sleep_quality_engine_instance
    meal_time_checker_engine = meal_time_engine


@router.post("/shift-to-sleep", response_model=EngineResponse)
async def calculate_shift_to_sleep(
    request: ShiftToSleepRequest,
    authorization: str = Header(...),
    x_correlation_id: Optional[str] = Header(None),
    auth_service: AuthService = Depends(),
    logger_service: LoggerService = Depends()
):
    """Shift-to-Sleep 엔진 계산"""
    correlation_id = get_correlation_id_from_header(x_correlation_id)
    
    try:
        # 인증 확인
        user_id = await auth_service.get_user_from_token(authorization)
        if user_id != request.userId:
            raise HTTPException(status_code=403, detail="권한이 없습니다")
        
        # 엔진 가용성 확인
        if not shift_to_sleep_engine:
            raise HTTPException(status_code=503, detail="Shift-to-Sleep 엔진을 사용할 수 없습니다")
        
        # 계산 실행
        result = await shift_to_sleep_engine.calculate(request, correlation_id)
        
        # 로깅
        await logger_service.log_engine_request(
            correlation_id=correlation_id,
            engine_type=EngineType.SHIFT_TO_SLEEP,
            user_id=user_id,
            success=result.result is not None
        )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Shift-to-Sleep 엔진 오류: {e}")
        await logger_service.log_engine_error(
            correlation_id=correlation_id,
            engine_type=EngineType.SHIFT_TO_SLEEP,
            error=e
        )
        raise HTTPException(status_code=500, detail="엔진 계산 중 오류가 발생했습니다")


@router.post("/caffeine-cutoff", response_model=EngineResponse)
async def calculate_caffeine_cutoff(
    request: CaffeineCutoffRequest,
    authorization: str = Header(...),
    x_correlation_id: Optional[str] = Header(None),
    auth_service: AuthService = Depends(),
    logger_service: LoggerService = Depends()
):
    """Caffeine Cutoff 엔진 계산"""
    correlation_id = get_correlation_id_from_header(x_correlation_id)
    
    try:
        # 인증 확인
        user_id = await auth_service.get_user_from_token(authorization)
        if user_id != request.userId:
            raise HTTPException(status_code=403, detail="권한이 없습니다")
        
        # 엔진 가용성 확인
        if not caffeine_cutoff_engine:
            raise HTTPException(status_code=503, detail="Caffeine Cutoff 엔진을 사용할 수 없습니다")
        
        # 계산 실행
        result = await caffeine_cutoff_engine.calculate(request, correlation_id)
        
        # 로깅
        await logger_service.log_engine_request(
            correlation_id=correlation_id,
            engine_type=EngineType.CAFFEINE_CUTOFF,
            user_id=user_id,
            success=result.result is not None
        )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Caffeine Cutoff 엔진 오류: {e}")
        await logger_service.log_engine_error(
            correlation_id=correlation_id,
            engine_type=EngineType.CAFFEINE_CUTOFF,
            error=e
        )
        raise HTTPException(status_code=500, detail="엔진 계산 중 오류가 발생했습니다")


@router.post("/fatigue-risk", response_model=EngineResponse)
async def calculate_fatigue_risk(
    request: FatigueRiskRequest,
    authorization: str = Header(...),
    x_correlation_id: Optional[str] = Header(None),
    auth_service: AuthService = Depends(),
    logger_service: LoggerService = Depends()
):
    """Fatigue Risk 엔진 계산"""
    correlation_id = get_correlation_id_from_header(x_correlation_id)
    
    try:
        # 인증 확인
        user_id = await auth_service.get_user_from_token(authorization)
        if user_id != request.userId:
            raise HTTPException(status_code=403, detail="권한이 없습니다")
        
        # 엔진 가용성 확인
        if not fatigue_risk_engine:
            raise HTTPException(status_code=503, detail="Fatigue Risk 엔진을 사용할 수 없습니다")
        
        # 계산 실행
        result = await fatigue_risk_engine.calculate(request, correlation_id)
        
        # 로깅
        await logger_service.log_engine_request(
            correlation_id=correlation_id,
            engine_type=EngineType.FATIGUE_RISK,
            user_id=user_id,
            success=result.result is not None
        )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Fatigue Risk 엔진 오류: {e}")
        await logger_service.log_engine_error(
            correlation_id=correlation_id,
            engine_type=EngineType.FATIGUE_RISK,
            error=e
        )
        raise HTTPException(status_code=500, detail="엔진 계산 중 오류가 발생했습니다")


@router.get("/caffeine-info")
async def get_caffeine_info(
    authorization: str = Header(...),
    auth_service: AuthService = Depends()
):
    """카페인 함량 정보 조회"""
    try:
        # 인증 확인
        await auth_service.get_user_from_token(authorization)
        
        # 엔진 가용성 확인
        if not caffeine_cutoff_engine:
            raise HTTPException(status_code=503, detail="Caffeine Cutoff 엔진을 사용할 수 없습니다")
        
        # 카페인 정보 반환
        caffeine_info = caffeine_cutoff_engine.get_caffeine_content_info()
        
        return {
            "data": caffeine_info,
            "categories": ["coffee", "tea", "supplement", "soft_drink", "food"]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"카페인 정보 조회 오류: {e}")
        raise HTTPException(status_code=500, detail="카페인 정보 조회 중 오류가 발생했습니다")


@router.post("/daily-jumpstart", response_model=EngineResponse)
async def calculate_daily_jumpstart(
    request: DailyJumpstartRequest,
    authorization: str = Header(...),
    x_correlation_id: Optional[str] = Header(None),
    auth_service: AuthService = Depends(),
    logger_service: LoggerService = Depends()
):
    """Daily Jumpstart Plan 엔진 계산"""
    correlation_id = get_correlation_id_from_header(x_correlation_id)
    
    try:
        # 인증 확인
        user_id = await auth_service.get_user_from_token(authorization)
        if user_id != request.userId:
            raise HTTPException(status_code=403, detail="권한이 없습니다")
        
        # 엔진 가용성 확인
        if not daily_jumpstart_engine:
            raise HTTPException(status_code=503, detail="Daily Jumpstart 엔진을 사용할 수 없습니다")
        
        # 계산 실행
        result = await daily_jumpstart_engine.calculate(request, correlation_id)
        
        # 로깅
        await logger_service.log_engine_request(
            correlation_id=correlation_id,
            engine_type=EngineType.DAILY_JUMPSTART,
            user_id=user_id,
            success=result.result is not None
        )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Daily Jumpstart 엔진 오류: {e}")
        await logger_service.log_engine_error(
            correlation_id=correlation_id,
            engine_type=EngineType.DAILY_JUMPSTART,
            error=e
        )
        raise HTTPException(status_code=500, detail="엔진 계산 중 오류가 발생했습니다")


@router.post("/sleep-quality", response_model=EngineResponse)
async def calculate_sleep_quality(
    request: SleepQualityRequest,
    authorization: str = Header(...),
    x_correlation_id: Optional[str] = Header(None),
    auth_service: AuthService = Depends(),
    logger_service: LoggerService = Depends()
):
    """Sleep Quality Tracker 엔진 계산"""
    correlation_id = get_correlation_id_from_header(x_correlation_id)
    
    try:
        # 인증 확인
        user_id = await auth_service.get_user_from_token(authorization)
        if user_id != request.userId:
            raise HTTPException(status_code=403, detail="권한이 없습니다")
        
        # 엔진 가용성 확인
        if not sleep_quality_engine:
            raise HTTPException(status_code=503, detail="Sleep Quality 엔진을 사용할 수 없습니다")
        
        # 계산 실행
        result = await sleep_quality_engine.calculate(request, correlation_id)
        
        # 로깅
        await logger_service.log_engine_request(
            correlation_id=correlation_id,
            engine_type=EngineType.SLEEP_QUALITY,
            user_id=user_id,
            success=result.result is not None
        )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Sleep Quality 엔진 오류: {e}")
        await logger_service.log_engine_error(
            correlation_id=correlation_id,
            engine_type=EngineType.SLEEP_QUALITY,
            error=e
        )
        raise HTTPException(status_code=500, detail="엔진 계산 중 오류가 발생했습니다")


@router.post("/meal-time-checker", response_model=EngineResponse)
async def check_meal_time(
    request: MealTimeRequest,
    authorization: str = Header(...),
    x_correlation_id: Optional[str] = Header(None),
    auth_service: AuthService = Depends(),
    logger_service: LoggerService = Depends()
):
    """Meal Time Checker 엔진 계산"""
    correlation_id = get_correlation_id_from_header(x_correlation_id)
    
    try:
        # 인증 확인
        user_id = await auth_service.get_user_from_token(authorization)
        if user_id != request.userId:
            raise HTTPException(status_code=403, detail="권한이 없습니다")
        
        # 엔진 가용성 확인
        if not meal_time_checker_engine:
            raise HTTPException(status_code=503, detail="Meal Time Checker 엔진을 사용할 수 없습니다")
        
        # 계산 실행
        result = await meal_time_checker_engine.calculate(request, correlation_id)
        
        # 로깅
        await logger_service.log_engine_request(
            correlation_id=correlation_id,
            engine_type=EngineType.MEAL_TIME_CHECKER,
            user_id=user_id,
            success=result.result is not None
        )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Meal Time Checker 엔진 오류: {e}")
        await logger_service.log_engine_error(
            correlation_id=correlation_id,
            engine_type=EngineType.MEAL_TIME_CHECKER,
            error=e
        )
        raise HTTPException(status_code=500, detail="엔진 계산 중 오류가 발생했습니다")