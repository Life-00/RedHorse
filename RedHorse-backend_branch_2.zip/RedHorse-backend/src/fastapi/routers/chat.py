"""
AI 상담봇 라우터
Bedrock 기반 AI 상담봇 서비스
"""

from fastapi import APIRouter, Depends, HTTPException, Header
from typing import Optional, List
import logging

from ..models.common import ChatRequest, ChatResponse, ChatHistory
from ..services.auth_service import AuthService
from ..services.logger_service import LoggerService
from ..engines.ai_chatbot import AIChatbotEngine
from ..utils.correlation import get_correlation_id_from_header

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/chat")

# 전역 엔진 인스턴스 (main.py에서 주입)
ai_chatbot_engine: Optional[AIChatbotEngine] = None


def set_chatbot_engine(chatbot_engine: AIChatbotEngine):
    """AI 상담봇 엔진 인스턴스 설정"""
    global ai_chatbot_engine
    ai_chatbot_engine = chatbot_engine


@router.post("/message", response_model=ChatResponse)
async def send_chat_message(
    request: ChatRequest,
    authorization: str = Header(...),
    x_correlation_id: Optional[str] = Header(None),
    auth_service: AuthService = Depends(),
    logger_service: LoggerService = Depends()
):
    """AI 상담봇에게 메시지 전송"""
    correlation_id = get_correlation_id_from_header(x_correlation_id)
    
    try:
        # 인증 확인
        user_id = await auth_service.get_user_from_token(authorization)
        if user_id != request.userId:
            raise HTTPException(status_code=403, detail="권한이 없습니다")
        
        # 엔진 가용성 확인
        if not ai_chatbot_engine:
            raise HTTPException(status_code=503, detail="AI 상담봇을 사용할 수 없습니다")
        
        # 메시지 처리
        response = await ai_chatbot_engine.process_message(request, correlation_id)
        
        # 로깅
        await logger_service.log_chat_interaction(
            correlation_id=correlation_id,
            user_id=user_id,
            message_length=len(request.message),
            response_length=len(response.response) if response.response else 0,
            success=True
        )
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"AI 상담봇 오류: {e}")
        await logger_service.log_chat_error(
            correlation_id=correlation_id,
            user_id=request.userId,
            error=e
        )
        raise HTTPException(status_code=500, detail="AI 상담봇 처리 중 오류가 발생했습니다")


@router.get("/history", response_model=List[ChatHistory])
async def get_chat_history(
    authorization: str = Header(...),
    limit: int = 20,
    offset: int = 0,
    auth_service: AuthService = Depends()
):
    """채팅 기록 조회"""
    try:
        # 인증 확인
        user_id = await auth_service.get_user_from_token(authorization)
        
        # 엔진 가용성 확인
        if not ai_chatbot_engine:
            raise HTTPException(status_code=503, detail="AI 상담봇을 사용할 수 없습니다")
        
        # 채팅 기록 조회
        history = await ai_chatbot_engine.get_chat_history(user_id, limit, offset)
        
        return history
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"채팅 기록 조회 오류: {e}")
        raise HTTPException(status_code=500, detail="채팅 기록 조회 중 오류가 발생했습니다")


@router.delete("/history")
async def clear_chat_history(
    authorization: str = Header(...),
    auth_service: AuthService = Depends()
):
    """채팅 기록 삭제"""
    try:
        # 인증 확인
        user_id = await auth_service.get_user_from_token(authorization)
        
        # 엔진 가용성 확인
        if not ai_chatbot_engine:
            raise HTTPException(status_code=503, detail="AI 상담봇을 사용할 수 없습니다")
        
        # 채팅 기록 삭제
        await ai_chatbot_engine.clear_chat_history(user_id)
        
        return {"message": "채팅 기록이 삭제되었습니다"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"채팅 기록 삭제 오류: {e}")
        raise HTTPException(status_code=500, detail="채팅 기록 삭제 중 오류가 발생했습니다")