"""
대시보드 라우터
FastAPI 기반 대시보드 데이터 제공 (Lambda 대시보드와 연동)
"""

from fastapi import APIRouter, Depends, HTTPException, Header
from typing import Optional
import logging

from ..services.auth_service import AuthService
from ..services.database_service import DatabaseService
from ..services.logger_service import LoggerService
from ..utils.correlation import get_correlation_id_from_header

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/dashboard")


@router.get("/engine-status")
async def get_engine_status(
    authorization: str = Header(...),
    x_correlation_id: Optional[str] = Header(None),
    auth_service: AuthService = Depends(),
    db_service: DatabaseService = Depends()
):
    """엔진 상태 및 통계 조회"""
    correlation_id = get_correlation_id_from_header(x_correlation_id)
    
    try:
        # 인증 확인
        user_id = await auth_service.get_user_from_token(authorization)
        
        # 엔진 통계 조회
        engine_stats = await db_service.get_engine_statistics(user_id)
        
        return {
            "data": engine_stats,
            "correlationId": correlation_id
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"엔진 상태 조회 오류: {e}")
        raise HTTPException(status_code=500, detail="엔진 상태 조회 중 오류가 발생했습니다")


@router.get("/performance-metrics")
async def get_performance_metrics(
    authorization: str = Header(...),
    days: int = 7,
    auth_service: AuthService = Depends(),
    db_service: DatabaseService = Depends()
):
    """성능 메트릭 조회 (관리자용)"""
    try:
        # 인증 및 권한 확인
        user_id = await auth_service.get_user_from_token(authorization)
        user_role = await auth_service.get_user_role(user_id)
        
        if user_role not in ["system_admin", "b2b_admin"]:
            raise HTTPException(status_code=403, detail="관리자 권한이 필요합니다")
        
        # 성능 메트릭 조회
        metrics = await db_service.get_performance_metrics(days)
        
        return {
            "data": metrics,
            "period": f"last_{days}_days"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"성능 메트릭 조회 오류: {e}")
        raise HTTPException(status_code=500, detail="성능 메트릭 조회 중 오류가 발생했습니다")