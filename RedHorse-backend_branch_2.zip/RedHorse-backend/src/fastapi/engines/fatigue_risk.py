"""
Fatigue Risk Score 엔진
교대근무자의 피로도 위험 점수를 계산하여 안전 관리 지원
"""

import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from ..models.common import (
    EngineResponse, FatigueRiskRequest, FatigueRiskResult,
    UserProfile, ShiftSchedule, CacheKey, EngineType, ShiftType
)
from ..services.cache_service import CacheService
from ..services.database_service import DatabaseService
from ..utils.time_utils import TimeUtils

logger = logging.getLogger(__name__)


class FatigueRiskEngine:
    """Fatigue Risk Score 엔진 클래스"""
    
    # 피로도 계산 가중치
    WEIGHTS = {
        "sleep_deficit": 0.35,      # 수면 부족
        "consecutive_shifts": 0.25,  # 연속 근무
        "night_shifts": 0.20,       # 야간 근무
        "work_hours": 0.15,         # 근무 시간
        "recovery_time": 0.05       # 회복 시간
    }
    
    # 위험도 임계값
    RISK_THRESHOLDS = {
        "low": 25,
        "medium": 50,
        "high": 75,
        "critical": 90
    }
    
    def __init__(self, cache_service: CacheService, db_service: DatabaseService):
        self.cache = cache_service
        self.db = db_service
    
    async def calculate(
        self, 
        request: FatigueRiskRequest, 
        correlation_id: str
    ) -> EngineResponse:
        """피로도 위험 점수 계산"""
        try:
            logger.info(f"Fatigue Risk 계산 시작: user_id={request.userId}")
            
            # 1. 캐시 확인
            if not request.forceRefresh:
                cached_result = await self._get_cached_result(request)
                if cached_result:
                    logger.info(f"캐시에서 결과 반환: user_id={request.userId}")
                    return EngineResponse(
                        result=cached_result,
                        generatedAt=TimeUtils.now_kst(),
                        correlationId=correlation_id
                    )
            
            # 2. 입력 데이터 수집 및 검증
            validation_result = await self._validate_and_collect_data(request)
            if not validation_result["is_valid"]:
                return EngineResponse(
                    whyNotShown=validation_result["reason"],
                    dataMissing=validation_result["missing_data"],
                    generatedAt=TimeUtils.now_kst(),
                    correlationId=correlation_id
                )
            
            data = validation_result["data"]
            
            # 3. 피로도 위험 점수 계산
            fatigue_result = await self._calculate_fatigue_risk(
                data["user_profile"],
                data["recent_schedules"],
                data["sleep_data"],
                request.assessmentPeriodDays or 7
            )
            
            # 4. 결과 캐시 저장
            await self._cache_result(request, fatigue_result)
            
            logger.info(f"Fatigue Risk 계산 완료: user_id={request.userId}")
            
            return EngineResponse(
                result=fatigue_result.dict(),
                generatedAt=TimeUtils.now_kst(),
                correlationId=correlation_id
            )
            
        except Exception as e:
            logger.error(f"Fatigue Risk 계산 실패: {e}")
            return EngineResponse(
                whyNotShown="CALCULATION_ERROR",
                dataMissing=[],
                generatedAt=TimeUtils.now_kst(),
                correlationId=correlation_id
            )
    
    async def _get_cached_result(self, request: FatigueRiskRequest) -> Optional[Dict[str, Any]]:
        """캐시된 결과 조회"""
        try:
            cache_key = CacheKey(
                engine_type=EngineType.FATIGUE_RISK,
                user_id=request.userId,
                target_date=request.targetDate,
                parameters_hash=self._generate_params_hash(request)
            )
            
            return await self.cache.get(cache_key)
            
        except Exception as e:
            logger.error(f"캐시 조회 실패: {e}")
            return None
    
    async def _cache_result(self, request: FatigueRiskRequest, result: FatigueRiskResult):
        """결과 캐시 저장"""
        try:
            cache_key = CacheKey(
                engine_type=EngineType.FATIGUE_RISK,
                user_id=request.userId,
                target_date=request.targetDate,
                parameters_hash=self._generate_params_hash(request)
            )
            
            await self.cache.set(cache_key, result.dict())
            
        except Exception as e:
            logger.error(f"캐시 저장 실패: {e}")
    
    def _generate_params_hash(self, request: FatigueRiskRequest) -> str:
        """매개변수 해시 생성"""
        import hashlib
        
        params = f"{request.assessmentPeriodDays}_{request.includeWearableData}"
        return hashlib.md5(params.encode()).hexdigest()[:8]
    
    async def _validate_and_collect_data(self, request: FatigueRiskRequest) -> Dict[str, Any]:
        """입력 데이터 검증 및 수집"""
        missing_data = []
        
        # 사용자 프로필 조회
        user_profile = await self.db.get_user_profile(request.userId)
        if not user_profile:
            missing_data.append("USER_PROFILE")
        
        # 대상 날짜 설정
        target_date = request.targetDate or TimeUtils.today_kst()
        assessment_days = request.assessmentPeriodDays or 7
        
        # 최근 근무표 조회
        start_date = TimeUtils.subtract_days(
            TimeUtils.parse_date(target_date), 
            assessment_days
        )
        recent_schedules = await self.db.get_schedules_in_range(
            request.userId, 
            TimeUtils.format_date(start_date),
            target_date
        )
        
        if not recent_schedules:
            missing_data.append("RECENT_SCHEDULES")
        
        # 수면 데이터 조회 (웨어러블 데이터 포함)
        sleep_data = None
        if request.includeWearableData and user_profile and user_profile.wearableConnected:
            sleep_data = await self.db.get_sleep_data(
                request.userId,
                TimeUtils.format_date(start_date),
                target_date
            )
        
        # 검증 결과
        if missing_data:
            return {
                "is_valid": False,
                "reason": "INSUFFICIENT_DATA",
                "missing_data": missing_data,
                "data": None
            }
        
        return {
            "is_valid": True,
            "reason": None,
            "missing_data": [],
            "data": {
                "user_profile": user_profile,
                "recent_schedules": recent_schedules,
                "sleep_data": sleep_data,
                "target_date": target_date,
                "assessment_days": assessment_days
            }
        }
    
    async def _calculate_fatigue_risk(
        self,
        user_profile: UserProfile,
        recent_schedules: List[ShiftSchedule],
        sleep_data: Optional[Dict[str, Any]],
        assessment_days: int
    ) -> FatigueRiskResult:
        """피로도 위험 점수 계산 메인 로직"""
        
        # 1. 각 요소별 점수 계산
        sleep_deficit_score = self._calculate_sleep_deficit_score(
            recent_schedules, sleep_data
        )
        
        consecutive_shifts_score = self._calculate_consecutive_shifts_score(
            recent_schedules
        )
        
        night_shifts_score = self._calculate_night_shifts_score(
            recent_schedules, assessment_days
        )
        
        work_hours_score = self._calculate_work_hours_score(
            recent_schedules, assessment_days
        )
        
        recovery_time_score = self._calculate_recovery_time_score(
            recent_schedules
        )
        
        # 2. 가중 평균으로 총 점수 계산
        total_score = (
            sleep_deficit_score * self.WEIGHTS["sleep_deficit"] +
            consecutive_shifts_score * self.WEIGHTS["consecutive_shifts"] +
            night_shifts_score * self.WEIGHTS["night_shifts"] +
            work_hours_score * self.WEIGHTS["work_hours"] +
            recovery_time_score * self.WEIGHTS["recovery_time"]
        )
        
        # 3. 위험도 레벨 결정
        risk_level = self._determine_risk_level(total_score)
        
        # 4. 상세 분석 결과
        breakdown = {
            "sleepDeficit": round(sleep_deficit_score, 1),
            "consecutiveShifts": round(consecutive_shifts_score, 1),
            "nightShifts": round(night_shifts_score, 1),
            "workHours": round(work_hours_score, 1),
            "recoveryTime": round(recovery_time_score, 1)
        }
        
        # 5. 권장사항 생성
        recommendations = self._generate_recommendations(
            risk_level, breakdown, recent_schedules, user_profile
        )
        
        # 6. 트렌드 분석
        trend_analysis = self._analyze_fatigue_trend(recent_schedules)
        
        return FatigueRiskResult(
            fatigueScore=round(total_score, 1),
            riskLevel=risk_level,
            breakdown=breakdown,
            recommendations=recommendations,
            trendAnalysis=trend_analysis,
            assessmentPeriod=f"{assessment_days}일간",
            dataQuality=self._assess_data_quality(recent_schedules, sleep_data)
        )
    
    def _calculate_sleep_deficit_score(
        self, 
        schedules: List[ShiftSchedule], 
        sleep_data: Optional[Dict[str, Any]]
    ) -> float:
        """수면 부족 점수 계산"""
        if sleep_data and "averageSleepHours" in sleep_data:
            avg_sleep = sleep_data["averageSleepHours"]
            optimal_sleep = 8.0
            
            if avg_sleep >= optimal_sleep:
                return 0.0
            elif avg_sleep >= 7.0:
                return 20.0
            elif avg_sleep >= 6.0:
                return 50.0
            elif avg_sleep >= 5.0:
                return 80.0
            else:
                return 100.0
        
        # 웨어러블 데이터가 없으면 근무 패턴으로 추정
        night_shifts = len([s for s in schedules if s.shiftType == ShiftType.NIGHT])
        if night_shifts > len(schedules) * 0.5:
            return 60.0  # 야간 근무 많으면 수면 부족 가능성 높음
        
        return 30.0  # 기본값
    
    def _calculate_consecutive_shifts_score(self, schedules: List[ShiftSchedule]) -> float:
        """연속 근무 점수 계산"""
        if not schedules:
            return 0.0
        
        # 연속 근무일 수 계산
        max_consecutive = 0
        current_consecutive = 0
        
        sorted_schedules = sorted(schedules, key=lambda x: x.date)
        
        for schedule in sorted_schedules:
            if schedule.shiftType != ShiftType.OFF:
                current_consecutive += 1
                max_consecutive = max(max_consecutive, current_consecutive)
            else:
                current_consecutive = 0
        
        # 점수 매핑
        if max_consecutive <= 2:
            return 0.0
        elif max_consecutive <= 4:
            return 30.0
        elif max_consecutive <= 6:
            return 60.0
        else:
            return 100.0
    
    def _calculate_night_shifts_score(
        self, 
        schedules: List[ShiftSchedule], 
        assessment_days: int
    ) -> float:
        """야간 근무 점수 계산"""
        night_shifts = len([s for s in schedules if s.shiftType == ShiftType.NIGHT])
        night_ratio = night_shifts / assessment_days if assessment_days > 0 else 0
        
        if night_ratio <= 0.2:
            return 0.0
        elif night_ratio <= 0.4:
            return 40.0
        elif night_ratio <= 0.6:
            return 70.0
        else:
            return 100.0
    
    def _calculate_work_hours_score(
        self, 
        schedules: List[ShiftSchedule], 
        assessment_days: int
    ) -> float:
        """근무 시간 점수 계산"""
        total_hours = 0.0
        work_days = 0
        
        for schedule in schedules:
            if schedule.shiftType != ShiftType.OFF and schedule.startAt and schedule.endAt:
                start = TimeUtils.parse_datetime(schedule.startAt)
                end = TimeUtils.parse_datetime(schedule.endAt)
                hours = (end - start).total_seconds() / 3600
                total_hours += hours
                work_days += 1
        
        if work_days == 0:
            return 0.0
        
        avg_daily_hours = total_hours / assessment_days
        
        if avg_daily_hours <= 8:
            return 0.0
        elif avg_daily_hours <= 10:
            return 30.0
        elif avg_daily_hours <= 12:
            return 60.0
        else:
            return 100.0
    
    def _calculate_recovery_time_score(self, schedules: List[ShiftSchedule]) -> float:
        """회복 시간 점수 계산"""
        if len(schedules) < 2:
            return 0.0
        
        sorted_schedules = sorted(schedules, key=lambda x: x.date)
        min_recovery_hours = float('inf')
        
        for i in range(len(sorted_schedules) - 1):
            current = sorted_schedules[i]
            next_schedule = sorted_schedules[i + 1]
            
            if (current.shiftType != ShiftType.OFF and 
                next_schedule.shiftType != ShiftType.OFF and
                current.endAt and next_schedule.startAt):
                
                end_time = TimeUtils.parse_datetime(current.endAt)
                start_time = TimeUtils.parse_datetime(next_schedule.startAt)
                recovery_hours = (start_time - end_time).total_seconds() / 3600
                
                min_recovery_hours = min(min_recovery_hours, recovery_hours)
        
        if min_recovery_hours == float('inf'):
            return 0.0
        
        if min_recovery_hours >= 16:
            return 0.0
        elif min_recovery_hours >= 12:
            return 20.0
        elif min_recovery_hours >= 8:
            return 50.0
        else:
            return 100.0
    
    def _determine_risk_level(self, score: float) -> str:
        """위험도 레벨 결정"""
        if score <= self.RISK_THRESHOLDS["low"]:
            return "LOW"
        elif score <= self.RISK_THRESHOLDS["medium"]:
            return "MEDIUM"
        elif score <= self.RISK_THRESHOLDS["high"]:
            return "HIGH"
        else:
            return "CRITICAL"
    
    def _generate_recommendations(
        self,
        risk_level: str,
        breakdown: Dict[str, float],
        schedules: List[ShiftSchedule],
        user_profile: UserProfile
    ) -> List[str]:
        """위험도별 권장사항 생성"""
        recommendations = []
        
        # 위험도별 기본 권장사항
        if risk_level == "CRITICAL":
            recommendations.append("⚠️ 피로도가 매우 높습니다. 즉시 휴식을 취하세요")
            recommendations.append("가능하다면 다음 근무 전 충분한 수면을 확보하세요")
        elif risk_level == "HIGH":
            recommendations.append("피로도가 높습니다. 추가 휴식이 필요합니다")
        elif risk_level == "MEDIUM":
            recommendations.append("적절한 수면 패턴 유지가 중요합니다")
        
        # 세부 요소별 권장사항
        if breakdown["sleepDeficit"] > 50:
            recommendations.append("수면 시간을 늘리고 수면 품질을 개선하세요")
        
        if breakdown["consecutiveShifts"] > 50:
            recommendations.append("연속 근무 후에는 충분한 휴식일을 확보하세요")
        
        if breakdown["nightShifts"] > 50:
            recommendations.append("야간 근무 후 낮잠을 활용하여 수면 부족을 보충하세요")
        
        if breakdown["workHours"] > 50:
            recommendations.append("장시간 근무 시 중간 휴식을 자주 취하세요")
        
        # 교대근무 유형별 권장사항
        if user_profile.shiftType == "THREE_SHIFT":
            recommendations.append("3교대 근무 시 규칙적인 수면 스케줄 유지가 중요합니다")
        elif user_profile.shiftType == "IRREGULAR":
            recommendations.append("불규칙한 근무 패턴에서는 수면 위생 관리가 더욱 중요합니다")
        
        return recommendations
    
    def _analyze_fatigue_trend(self, schedules: List[ShiftSchedule]) -> Dict[str, Any]:
        """피로도 트렌드 분석"""
        if len(schedules) < 3:
            return {"trend": "insufficient_data", "description": "분석을 위한 데이터가 부족합니다"}
        
        # 최근 3일과 이전 3일 비교
        sorted_schedules = sorted(schedules, key=lambda x: x.date)
        mid_point = len(sorted_schedules) // 2
        
        recent_schedules = sorted_schedules[mid_point:]
        earlier_schedules = sorted_schedules[:mid_point]
        
        # 야간 근무 비율 비교
        recent_nights = len([s for s in recent_schedules if s.shiftType == ShiftType.NIGHT])
        earlier_nights = len([s for s in earlier_schedules if s.shiftType == ShiftType.NIGHT])
        
        recent_night_ratio = recent_nights / len(recent_schedules) if recent_schedules else 0
        earlier_night_ratio = earlier_nights / len(earlier_schedules) if earlier_schedules else 0
        
        if recent_night_ratio > earlier_night_ratio + 0.2:
            return {
                "trend": "worsening",
                "description": "최근 야간 근무가 증가하여 피로도가 악화되고 있습니다"
            }
        elif recent_night_ratio < earlier_night_ratio - 0.2:
            return {
                "trend": "improving",
                "description": "야간 근무가 감소하여 피로도가 개선되고 있습니다"
            }
        else:
            return {
                "trend": "stable",
                "description": "피로도가 안정적인 수준을 유지하고 있습니다"
            }
    
    def _assess_data_quality(
        self, 
        schedules: List[ShiftSchedule], 
        sleep_data: Optional[Dict[str, Any]]
    ) -> str:
        """데이터 품질 평가"""
        quality_score = 0
        
        # 근무표 완성도
        if schedules:
            complete_schedules = len([
                s for s in schedules 
                if s.shiftType != ShiftType.OFF and s.startAt and s.endAt
            ])
            schedule_completeness = complete_schedules / len(schedules)
            quality_score += schedule_completeness * 50
        
        # 수면 데이터 가용성
        if sleep_data:
            quality_score += 50
        
        if quality_score >= 80:
            return "excellent"
        elif quality_score >= 60:
            return "good"
        elif quality_score >= 40:
            return "fair"
        else:
            return "poor"