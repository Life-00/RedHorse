"""
Daily Jumpstart Plan 엔진
교대근무자를 위한 개인화된 일일 계획 생성
"""

import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from ..models.common import (
    EngineResponse, DailyJumpstartRequest, DailyJumpstartResult,
    UserProfile, ShiftSchedule, CacheKey, EngineType, ShiftType
)
from ..services.cache_service import CacheService
from ..services.database_service import DatabaseService
from ..utils.time_utils import TimeUtils

logger = logging.getLogger(__name__)


class DailyJumpstartEngine:
    """Daily Jumpstart Plan 엔진 클래스"""
    
    # 활동 카테고리별 권장 시간 (분)
    ACTIVITY_DURATIONS = {
        "hydration": 2,          # 수분 섭취
        "light_exercise": 15,    # 가벼운 운동
        "meal_prep": 20,         # 식사 준비
        "meditation": 10,        # 명상/휴식
        "energy_boost": 5,       # 에너지 부스터
        "work_prep": 15,         # 근무 준비
        "recovery": 30,          # 회복 활동
        "sleep_prep": 20         # 수면 준비
    }
    
    # 교대 유형별 우선순위 활동
    SHIFT_PRIORITIES = {
        ShiftType.DAY: ["hydration", "light_exercise", "meal_prep", "work_prep"],
        ShiftType.MID: ["energy_boost", "hydration", "meal_prep", "work_prep"],
        ShiftType.NIGHT: ["energy_boost", "hydration", "meditation", "work_prep"],
        ShiftType.OFF: ["recovery", "light_exercise", "meal_prep", "meditation"]
    }
    
    def __init__(self, cache_service: CacheService, db_service: DatabaseService):
        self.cache = cache_service
        self.db = db_service
    
    async def calculate(
        self, 
        request: DailyJumpstartRequest, 
        correlation_id: str
    ) -> EngineResponse:
        """일일 점프스타트 계획 생성"""
        try:
            logger.info(f"Daily Jumpstart 계산 시작: user_id={request.userId}")
            
            # 1. 캐시 확인
            if not request.forceRefresh:
                cached_result = await self._get_cached_result(request)
                if cached_result:
                    logger.info(f"캐시에서 결과 반환: user_id={request.userId}")
                    return EngineResponse(
                        result=cached_result,
                        generatedAt=TimeUtils.now_kst(),
                        correlationId=correlation_id
                    )
            
            # 2. 입력 데이터 수집 및 검증
            validation_result = await self._validate_and_collect_data(request)
            if not validation_result["is_valid"]:
                return EngineResponse(
                    whyNotShown=validation_result["reason"],
                    dataMissing=validation_result["missing_data"],
                    generatedAt=TimeUtils.now_kst(),
                    correlationId=correlation_id
                )
            
            data = validation_result["data"]
            
            # 3. 일일 계획 생성
            jumpstart_result = await self._generate_daily_plan(
                data["user_profile"],
                data["today_schedule"],
                data["recent_schedules"],
                data["checklist_progress"],
                request.preferredActivities or []
            )
            
            # 4. 결과 캐시 저장
            await self._cache_result(request, jumpstart_result)
            
            logger.info(f"Daily Jumpstart 계산 완료: user_id={request.userId}")
            
            return EngineResponse(
                result=jumpstart_result.dict(),
                generatedAt=TimeUtils.now_kst(),
                correlationId=correlation_id
            )
            
        except Exception as e:
            logger.error(f"Daily Jumpstart 계산 실패: {e}")
            return EngineResponse(
                whyNotShown="CALCULATION_ERROR",
                dataMissing=[],
                generatedAt=TimeUtils.now_kst(),
                correlationId=correlation_id
            )
    
    async def _get_cached_result(self, request: DailyJumpstartRequest) -> Optional[Dict[str, Any]]:
        """캐시된 결과 조회"""
        try:
            cache_key = CacheKey(
                engine_type=EngineType.DAILY_JUMPSTART,
                user_id=request.userId,
                target_date=request.targetDate,
                parameters_hash=self._generate_params_hash(request)
            )
            
            return await self.cache.get(cache_key)
            
        except Exception as e:
            logger.error(f"캐시 조회 실패: {e}")
            return None
    
    async def _cache_result(self, request: DailyJumpstartRequest, result: DailyJumpstartResult):
        """결과 캐시 저장"""
        try:
            cache_key = CacheKey(
                engine_type=EngineType.DAILY_JUMPSTART,
                user_id=request.userId,
                target_date=request.targetDate,
                parameters_hash=self._generate_params_hash(request)
            )
            
            await self.cache.set(cache_key, result.dict())
            
        except Exception as e:
            logger.error(f"캐시 저장 실패: {e}")
    
    def _generate_params_hash(self, request: DailyJumpstartRequest) -> str:
        """매개변수 해시 생성"""
        import hashlib
        
        params = f"{request.preferredActivities}_{request.availableTimeMinutes}"
        return hashlib.md5(params.encode()).hexdigest()[:8]
    
    async def _validate_and_collect_data(self, request: DailyJumpstartRequest) -> Dict[str, Any]:
        """입력 데이터 검증 및 수집"""
        missing_data = []
        
        # 사용자 프로필 조회
        user_profile = await self.db.get_user_profile(request.userId)
        if not user_profile:
            missing_data.append("USER_PROFILE")
        
        # 대상 날짜 설정
        target_date = request.targetDate or TimeUtils.today_kst()
        
        # 오늘 근무표 조회
        today_schedule = await self.db.get_schedule_by_date(request.userId, target_date)
        
        # 최근 근무표 조회 (7일)
        recent_schedules = await self.db.get_recent_schedules(request.userId, 7)
        
        # 체크리스트 진행률 조회
        checklist_progress = await self._get_checklist_progress(request.userId)
        
        # 검증 결과
        if missing_data:
            return {
                "is_valid": False,
                "reason": "INSUFFICIENT_DATA",
                "missing_data": missing_data,
                "data": None
            }
        
        return {
            "is_valid": True,
            "reason": None,
            "missing_data": [],
            "data": {
                "user_profile": user_profile,
                "today_schedule": today_schedule,
                "recent_schedules": recent_schedules,
                "checklist_progress": checklist_progress,
                "target_date": target_date
            }
        }
    
    async def _get_checklist_progress(self, user_id: str) -> Dict[str, Any]:
        """체크리스트 진행률 조회"""
        try:
            if not self.db.pool:
                return {"completed": 0, "total": 0, "items": []}
            
            async with self.db.pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT item_key, title, completed, completed_at
                    FROM jumpstart_checklists 
                    WHERE user_id = $1
                    ORDER BY created_at ASC
                    """,
                    user_id
                )
                
                items = [dict(row) for row in rows]
                completed = len([item for item in items if item['completed']])
                
                return {
                    "completed": completed,
                    "total": len(items),
                    "items": items,
                    "completion_rate": (completed / len(items) * 100) if items else 0
                }
                
        except Exception as e:
            logger.error(f"체크리스트 진행률 조회 실패: {e}")
            return {"completed": 0, "total": 0, "items": []}
    
    async def _generate_daily_plan(
        self,
        user_profile: UserProfile,
        today_schedule: Optional[ShiftSchedule],
        recent_schedules: List[Dict[str, Any]],
        checklist_progress: Dict[str, Any],
        preferred_activities: List[str]
    ) -> DailyJumpstartResult:
        """일일 계획 생성 메인 로직"""
        
        # 1. 오늘의 근무 상황 분석
        work_analysis = self._analyze_work_situation(today_schedule, recent_schedules)
        
        # 2. 개인화된 활동 추천
        recommended_activities = self._recommend_activities(
            work_analysis,
            user_profile,
            preferred_activities,
            checklist_progress
        )
        
        # 3. 시간대별 계획 생성
        time_blocks = self._create_time_blocks(
            today_schedule,
            recommended_activities,
            work_analysis
        )
        
        # 4. 목표 및 동기부여 메시지 생성
        goals = self._generate_daily_goals(work_analysis, checklist_progress)
        motivation = self._generate_motivation_message(work_analysis, user_profile)
        
        # 5. 진행률 추적
        progress_tracking = self._create_progress_tracking(recommended_activities)
        
        return DailyJumpstartResult(
            workSituation=work_analysis,
            recommendedActivities=recommended_activities,
            timeBlocks=time_blocks,
            dailyGoals=goals,
            motivationMessage=motivation,
            progressTracking=progress_tracking,
            estimatedCompletionTime=self._calculate_total_time(recommended_activities)
        )
    
    def _analyze_work_situation(
        self, 
        today_schedule: Optional[ShiftSchedule], 
        recent_schedules: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """근무 상황 분석"""
        
        if not today_schedule:
            return {
                "type": "OFF_DAY",
                "description": "오늘은 휴무일입니다",
                "energy_level": "recovery",
                "focus_areas": ["recovery", "preparation"]
            }
        
        shift_type = today_schedule.shiftType
        
        # 최근 근무 패턴 분석
        recent_night_shifts = len([s for s in recent_schedules if s.get("shift_type") == "NIGHT"])
        consecutive_days = len([s for s in recent_schedules if s.get("shift_type") != "OFF"])
        
        if shift_type == ShiftType.NIGHT:
            energy_level = "low" if recent_night_shifts >= 3 else "moderate"
            focus_areas = ["energy_management", "alertness"]
        elif shift_type == ShiftType.DAY:
            energy_level = "high" if consecutive_days <= 3 else "moderate"
            focus_areas = ["productivity", "routine"]
        else:  # MID
            energy_level = "moderate"
            focus_areas = ["balance", "flexibility"]
        
        return {
            "type": shift_type,
            "description": f"오늘은 {self._get_shift_description(shift_type)} 근무입니다",
            "energy_level": energy_level,
            "focus_areas": focus_areas,
            "consecutive_days": consecutive_days,
            "recent_night_shifts": recent_night_shifts
        }
    
    def _get_shift_description(self, shift_type: ShiftType) -> str:
        """교대 유형 설명"""
        descriptions = {
            ShiftType.DAY: "주간",
            ShiftType.MID: "중간",
            ShiftType.NIGHT: "야간",
            ShiftType.OFF: "휴무"
        }
        return descriptions.get(shift_type, "일반")
    
    def _recommend_activities(
        self,
        work_analysis: Dict[str, Any],
        user_profile: UserProfile,
        preferred_activities: List[str],
        checklist_progress: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """개인화된 활동 추천"""
        
        activities = []
        shift_type = work_analysis.get("type", ShiftType.DAY)
        energy_level = work_analysis.get("energy_level", "moderate")
        
        # 기본 우선순위 활동
        priority_activities = self.SHIFT_PRIORITIES.get(shift_type, [])
        
        # 에너지 레벨에 따른 조정
        if energy_level == "low":
            priority_activities = ["hydration", "meditation", "energy_boost"] + priority_activities
        elif energy_level == "high":
            priority_activities = ["light_exercise"] + priority_activities
        
        # 사용자 선호도 반영
        if preferred_activities:
            # 선호 활동을 우선순위에 추가
            priority_activities = preferred_activities + [a for a in priority_activities if a not in preferred_activities]
        
        # 체크리스트 진행률에 따른 활동 추가
        if checklist_progress.get("completion_rate", 0) < 50:
            priority_activities.insert(0, "work_prep")
        
        # 활동 상세 정보 생성
        for i, activity_key in enumerate(priority_activities[:6]):  # 최대 6개 활동
            activity = self._create_activity_detail(activity_key, i + 1, energy_level)
            if activity:
                activities.append(activity)
        
        return activities
    
    def _create_activity_detail(self, activity_key: str, priority: int, energy_level: str) -> Optional[Dict[str, Any]]:
        """활동 상세 정보 생성"""
        
        activity_templates = {
            "hydration": {
                "title": "수분 보충",
                "description": "충분한 수분 섭취로 하루를 시작하세요",
                "icon": "💧",
                "category": "health",
                "instructions": ["물 500ml 마시기", "전해질 보충", "카페인 적정량 섭취"]
            },
            "light_exercise": {
                "title": "가벼운 운동",
                "description": "몸을 깨우는 스트레칭과 운동",
                "icon": "🏃‍♂️",
                "category": "fitness",
                "instructions": ["5분 스트레칭", "10분 가벼운 유산소", "심호흡 운동"]
            },
            "meal_prep": {
                "title": "식사 준비",
                "description": "영양가 있는 식사로 에너지 충전",
                "icon": "🍽️",
                "category": "nutrition",
                "instructions": ["균형잡힌 아침식사", "간식 준비", "수분 섭취 계획"]
            },
            "meditation": {
                "title": "명상 및 휴식",
                "description": "마음을 진정시키고 집중력 향상",
                "icon": "🧘‍♀️",
                "category": "mental",
                "instructions": ["5분 명상", "깊은 호흡", "긍정적 생각하기"]
            },
            "energy_boost": {
                "title": "에너지 부스터",
                "description": "활력을 높이는 빠른 활동",
                "icon": "⚡",
                "category": "energy",
                "instructions": ["찬물로 세수", "밝은 조명 노출", "활기찬 음악 듣기"]
            },
            "work_prep": {
                "title": "근무 준비",
                "description": "효율적인 근무를 위한 준비",
                "icon": "💼",
                "category": "productivity",
                "instructions": ["업무 계획 세우기", "필요한 물품 준비", "마음가짐 다지기"]
            },
            "recovery": {
                "title": "회복 활동",
                "description": "피로 회복과 재충전",
                "icon": "🛌",
                "category": "recovery",
                "instructions": ["충분한 휴식", "가벼운 독서", "좋아하는 취미 활동"]
            },
            "sleep_prep": {
                "title": "수면 준비",
                "description": "질 좋은 수면을 위한 준비",
                "icon": "😴",
                "category": "sleep",
                "instructions": ["수면 환경 정리", "전자기기 끄기", "릴랙스 루틴"]
            }
        }
        
        template = activity_templates.get(activity_key)
        if not template:
            return None
        
        # 에너지 레벨에 따른 시간 조정
        base_duration = self.ACTIVITY_DURATIONS.get(activity_key, 15)
        if energy_level == "low":
            duration = max(5, base_duration - 5)
        elif energy_level == "high":
            duration = base_duration + 5
        else:
            duration = base_duration
        
        return {
            "id": activity_key,
            "title": template["title"],
            "description": template["description"],
            "icon": template["icon"],
            "category": template["category"],
            "priority": priority,
            "estimatedMinutes": duration,
            "instructions": template["instructions"],
            "completed": False
        }
    
    def _create_time_blocks(
        self,
        today_schedule: Optional[ShiftSchedule],
        activities: List[Dict[str, Any]],
        work_analysis: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """시간대별 계획 생성"""
        
        time_blocks = []
        current_time = datetime.now()
        
        if not today_schedule or today_schedule.shiftType == ShiftType.OFF:
            # 휴무일 계획
            time_blocks = [
                {
                    "time": "09:00",
                    "title": "모닝 루틴",
                    "activities": [a for a in activities if a["category"] in ["health", "fitness"]],
                    "duration": 45
                },
                {
                    "time": "14:00", 
                    "title": "오후 활동",
                    "activities": [a for a in activities if a["category"] in ["productivity", "mental"]],
                    "duration": 30
                },
                {
                    "time": "20:00",
                    "title": "저녁 루틴",
                    "activities": [a for a in activities if a["category"] in ["recovery", "sleep"]],
                    "duration": 40
                }
            ]
        else:
            # 근무일 계획
            work_start = TimeUtils.parse_datetime(today_schedule.startAt)
            work_end = TimeUtils.parse_datetime(today_schedule.endAt)
            
            # 근무 전 준비
            prep_time = work_start - timedelta(hours=2)
            time_blocks.append({
                "time": prep_time.strftime("%H:%M"),
                "title": "근무 전 준비",
                "activities": [a for a in activities if a["category"] in ["health", "energy", "productivity"]],
                "duration": 60
            })
            
            # 근무 중 (가능한 경우)
            if today_schedule.shiftType != ShiftType.NIGHT:
                break_time = work_start + timedelta(hours=4)
                time_blocks.append({
                    "time": break_time.strftime("%H:%M"),
                    "title": "중간 휴식",
                    "activities": [a for a in activities if a["category"] in ["health", "mental"] and a["estimatedMinutes"] <= 10],
                    "duration": 15
                })
            
            # 근무 후 회복
            recovery_time = work_end + timedelta(hours=1)
            time_blocks.append({
                "time": recovery_time.strftime("%H:%M"),
                "title": "근무 후 회복",
                "activities": [a for a in activities if a["category"] in ["recovery", "sleep"]],
                "duration": 45
            })
        
        return time_blocks
    
    def _generate_daily_goals(
        self, 
        work_analysis: Dict[str, Any], 
        checklist_progress: Dict[str, Any]
    ) -> List[str]:
        """일일 목표 생성"""
        
        goals = []
        
        # 기본 목표
        goals.append("건강한 하루 시작하기")
        
        # 근무 상황별 목표
        if work_analysis.get("type") == ShiftType.OFF:
            goals.extend([
                "충분한 휴식과 회복",
                "다음 근무 준비하기"
            ])
        else:
            goals.extend([
                "효율적인 근무 수행",
                "에너지 관리하기"
            ])
        
        # 체크리스트 진행률에 따른 목표
        completion_rate = checklist_progress.get("completion_rate", 0)
        if completion_rate < 50:
            goals.append("점프스타트 체크리스트 50% 달성")
        elif completion_rate < 100:
            goals.append("점프스타트 체크리스트 완료")
        
        return goals[:4]  # 최대 4개 목표
    
    def _generate_motivation_message(
        self, 
        work_analysis: Dict[str, Any], 
        user_profile: UserProfile
    ) -> str:
        """동기부여 메시지 생성"""
        
        messages = {
            "high": [
                "오늘도 활기찬 하루를 시작해보세요! 💪",
                "좋은 컨디션으로 멋진 하루를 만들어가세요! ✨",
                "에너지가 넘치는 오늘, 목표를 향해 달려보세요! 🚀"
            ],
            "moderate": [
                "차근차근 하나씩, 오늘도 화이팅! 😊",
                "꾸준함이 가장 큰 힘입니다. 오늘도 파이팅! 💙",
                "작은 실천이 큰 변화를 만듭니다! 🌱"
            ],
            "low": [
                "힘든 시기지만 잘 버텨내고 계세요. 응원합니다! 🤗",
                "오늘은 무리하지 말고 천천히 가세요. 괜찮습니다! 💚",
                "휴식도 중요한 일입니다. 자신을 돌보세요! 🌸"
            ]
        }
        
        energy_level = work_analysis.get("energy_level", "moderate")
        message_list = messages.get(energy_level, messages["moderate"])
        
        import random
        return random.choice(message_list)
    
    def _create_progress_tracking(self, activities: List[Dict[str, Any]]) -> Dict[str, Any]:
        """진행률 추적 정보 생성"""
        
        total_activities = len(activities)
        total_time = sum(activity["estimatedMinutes"] for activity in activities)
        
        return {
            "totalActivities": total_activities,
            "completedActivities": 0,
            "totalEstimatedMinutes": total_time,
            "completedMinutes": 0,
            "progressPercentage": 0,
            "categories": {
                category: len([a for a in activities if a["category"] == category])
                for category in set(activity["category"] for activity in activities)
            }
        }
    
    def _calculate_total_time(self, activities: List[Dict[str, Any]]) -> int:
        """총 소요 시간 계산"""
        return sum(activity["estimatedMinutes"] for activity in activities)