"""
Sleep Quality Tracker 엔진
교대근무자의 수면 품질을 추적하고 분석하여 개선 방안 제공
"""

import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from ..models.common import (
    EngineResponse, SleepQualityRequest, SleepQualityResult,
    UserProfile, ShiftSchedule, CacheKey, EngineType, ShiftType
)
from ..services.cache_service import CacheService
from ..services.database_service import DatabaseService
from ..utils.time_utils import TimeUtils
from ..utils.sleep_calculator import SleepCalculator

logger = logging.getLogger(__name__)


class SleepQualityEngine:
    """Sleep Quality Tracker 엔진 클래스"""
    
    # 수면 품질 평가 가중치
    QUALITY_WEIGHTS = {
        "duration": 0.25,        # 수면 시간
        "consistency": 0.20,     # 일관성
        "timing": 0.20,          # 수면 타이밍
        "efficiency": 0.15,      # 수면 효율성
        "recovery": 0.10,        # 회복도
        "environment": 0.10      # 수면 환경
    }
    
    # 품질 등급 임계값
    GRADE_THRESHOLDS = {
        "A": 90,  # 우수
        "B": 80,  # 양호
        "C": 70,  # 보통
        "D": 60,  # 미흡
        "F": 0    # 불량
    }
    
    def __init__(self, cache_service: CacheService, db_service: DatabaseService):
        self.cache = cache_service
        self.db = db_service
    
    async def calculate(
        self, 
        request: SleepQualityRequest, 
        correlation_id: str
    ) -> EngineResponse:
        """수면 품질 분석"""
        try:
            logger.info(f"Sleep Quality 분석 시작: user_id={request.userId}")
            
            # 1. 캐시 확인
            if not request.forceRefresh:
                cached_result = await self._get_cached_result(request)
                if cached_result:
                    logger.info(f"캐시에서 결과 반환: user_id={request.userId}")
                    return EngineResponse(
                        result=cached_result,
                        generatedAt=TimeUtils.now_kst(),
                        correlationId=correlation_id
                    )
            
            # 2. 입력 데이터 수집 및 검증
            validation_result = await self._validate_and_collect_data(request)
            if not validation_result["is_valid"]:
                return EngineResponse(
                    whyNotShown=validation_result["reason"],
                    dataMissing=validation_result["missing_data"],
                    generatedAt=TimeUtils.now_kst(),
                    correlationId=correlation_id
                )
            
            data = validation_result["data"]
            
            # 3. 수면 품질 분석
            quality_result = await self._analyze_sleep_quality(
                data["user_profile"],
                data["recent_schedules"],
                data["sleep_data"],
                request.assessmentPeriodDays or 7
            )
            
            # 4. 결과 캐시 저장
            await self._cache_result(request, quality_result)
            
            logger.info(f"Sleep Quality 분석 완료: user_id={request.userId}")
            
            return EngineResponse(
                result=quality_result.dict(),
                generatedAt=TimeUtils.now_kst(),
                correlationId=correlation_id
            )
            
        except Exception as e:
            logger.error(f"Sleep Quality 분석 실패: {e}")
            return EngineResponse(
                whyNotShown="CALCULATION_ERROR",
                dataMissing=[],
                generatedAt=TimeUtils.now_kst(),
                correlationId=correlation_id
            )
    
    async def _get_cached_result(self, request: SleepQualityRequest) -> Optional[Dict[str, Any]]:
        """캐시된 결과 조회"""
        try:
            cache_key = CacheKey(
                engine_type=EngineType.SLEEP_QUALITY,
                user_id=request.userId,
                target_date=request.targetDate or TimeUtils.today_kst(),
                parameters_hash=self._generate_params_hash(request)
            )
            
            return await self.cache.get(cache_key)
            
        except Exception as e:
            logger.error(f"캐시 조회 실패: {e}")
            return None
    
    async def _cache_result(self, request: SleepQualityRequest, result: SleepQualityResult):
        """결과 캐시 저장"""
        try:
            cache_key = CacheKey(
                engine_type=EngineType.SLEEP_QUALITY,
                user_id=request.userId,
                target_date=request.targetDate or TimeUtils.today_kst(),
                parameters_hash=self._generate_params_hash(request)
            )
            
            await self.cache.set(cache_key, result.dict())
            
        except Exception as e:
            logger.error(f"캐시 저장 실패: {e}")
    
    def _generate_params_hash(self, request: SleepQualityRequest) -> str:
        """매개변수 해시 생성"""
        import hashlib
        
        params = f"{request.assessmentPeriodDays}_{request.includeWearableData}"
        return hashlib.md5(params.encode()).hexdigest()[:8]
    
    async def _validate_and_collect_data(self, request: SleepQualityRequest) -> Dict[str, Any]:
        """입력 데이터 검증 및 수집"""
        missing_data = []
        
        # 사용자 프로필 조회
        user_profile = await self.db.get_user_profile(request.userId)
        if not user_profile:
            missing_data.append("USER_PROFILE")
        
        # 대상 날짜 설정
        target_date = request.targetDate or TimeUtils.today_kst()
        assessment_days = request.assessmentPeriodDays or 7
        
        # 최근 근무표 조회
        start_date = TimeUtils.subtract_days(
            TimeUtils.parse_date(target_date), 
            assessment_days
        )
        recent_schedules = await self.db.get_schedules_in_range(
            request.userId, 
            TimeUtils.format_date(start_date),
            target_date
        )
        
        if not recent_schedules:
            missing_data.append("RECENT_SCHEDULES")
        
        # 수면 데이터 조회
        sleep_data = None
        if request.includeWearableData and user_profile and user_profile.wearableConnected:
            sleep_data = await self.db.get_sleep_data(
                request.userId,
                TimeUtils.format_date(start_date),
                target_date
            )
        
        # 검증 결과
        if missing_data:
            return {
                "is_valid": False,
                "reason": "INSUFFICIENT_DATA",
                "missing_data": missing_data,
                "data": None
            }
        
        return {
            "is_valid": True,
            "reason": None,
            "missing_data": [],
            "data": {
                "user_profile": user_profile,
                "recent_schedules": recent_schedules,
                "sleep_data": sleep_data,
                "target_date": target_date,
                "assessment_days": assessment_days
            }
        }
    
    async def _analyze_sleep_quality(
        self,
        user_profile: UserProfile,
        recent_schedules: List[ShiftSchedule],
        sleep_data: Optional[Dict[str, Any]],
        assessment_days: int
    ) -> SleepQualityResult:
        """수면 품질 분석 메인 로직"""
        
        # 1. 수면 메트릭 계산
        sleep_metrics = self._calculate_sleep_metrics(
            recent_schedules, sleep_data, assessment_days
        )
        
        # 2. 각 품질 요소별 점수 계산
        duration_score = self._calculate_duration_score(sleep_metrics)
        consistency_score = self._calculate_consistency_score(sleep_metrics)
        timing_score = self._calculate_timing_score(recent_schedules, sleep_metrics)
        efficiency_score = self._calculate_efficiency_score(sleep_data)
        recovery_score = self._calculate_recovery_score(sleep_metrics, recent_schedules)
        environment_score = self._calculate_environment_score(user_profile, recent_schedules)
        
        # 3. 가중 평균으로 총 점수 계산
        total_score = (
            duration_score * self.QUALITY_WEIGHTS["duration"] +
            consistency_score * self.QUALITY_WEIGHTS["consistency"] +
            timing_score * self.QUALITY_WEIGHTS["timing"] +
            efficiency_score * self.QUALITY_WEIGHTS["efficiency"] +
            recovery_score * self.QUALITY_WEIGHTS["recovery"] +
            environment_score * self.QUALITY_WEIGHTS["environment"]
        )
        
        # 4. 품질 등급 결정
        quality_grade = self._determine_quality_grade(total_score)
        
        # 5. 수면 패턴 분석
        sleep_patterns = self._analyze_sleep_patterns(recent_schedules, sleep_metrics)
        
        # 6. 권장사항 생성
        recommendations = self._generate_recommendations(
            quality_grade, sleep_metrics, sleep_patterns, user_profile
        )
        
        # 7. 트렌드 분석
        trend_analysis = self._analyze_sleep_trend(recent_schedules, sleep_data)
        
        # 8. 데이터 소스 결정
        data_source = self._determine_data_source(sleep_data, user_profile)
        
        return SleepQualityResult(
            qualityScore=round(total_score, 1),
            qualityGrade=quality_grade,
            sleepMetrics=sleep_metrics,
            sleepPatterns=sleep_patterns,
            recommendations=recommendations,
            trendAnalysis=trend_analysis,
            dataSource=data_source
        )
    
    def _calculate_sleep_metrics(
        self, 
        schedules: List[ShiftSchedule], 
        sleep_data: Optional[Dict[str, Any]], 
        assessment_days: int
    ) -> Dict[str, Any]:
        """수면 메트릭 계산"""
        
        if sleep_data and "sleepSessions" in sleep_data:
            # 웨어러블 데이터 기반 계산
            sessions = sleep_data["sleepSessions"]
            
            durations = [session.get("durationHours", 0) for session in sessions]
            bedtimes = [session.get("bedtime") for session in sessions if session.get("bedtime")]
            wake_times = [session.get("wakeTime") for session in sessions if session.get("wakeTime")]
            
            avg_duration = sum(durations) / len(durations) if durations else 0
            avg_bedtime = self._calculate_average_time(bedtimes) if bedtimes else None
            avg_wake_time = self._calculate_average_time(wake_times) if wake_times else None
            
            return {
                "averageSleepHours": round(avg_duration, 1),
                "averageBedtime": avg_bedtime,
                "averageWakeTime": avg_wake_time,
                "sleepVariability": self._calculate_sleep_variability(durations),
                "totalSleepHours": sum(durations),
                "sleepDebt": SleepCalculator.calculate_sleep_debt(durations, assessment_days),
                "dataQuality": "high"
            }
        else:
            # 근무표 기반 추정
            estimated_sleep = self._estimate_sleep_from_schedules(schedules)
            
            return {
                "averageSleepHours": estimated_sleep["avg_hours"],
                "averageBedtime": estimated_sleep["avg_bedtime"],
                "averageWakeTime": estimated_sleep["avg_wake_time"],
                "sleepVariability": estimated_sleep["variability"],
                "totalSleepHours": estimated_sleep["total_hours"],
                "sleepDebt": estimated_sleep["debt_info"],
                "dataQuality": "estimated"
            }
    
    def _calculate_average_time(self, time_strings: List[str]) -> str:
        """평균 시간 계산"""
        if not time_strings:
            return "00:00"
        
        total_minutes = 0
        for time_str in time_strings:
            try:
                dt = TimeUtils.parse_datetime(time_str)
                total_minutes += dt.hour * 60 + dt.minute
            except:
                continue
        
        if total_minutes == 0:
            return "00:00"
        
        avg_minutes = total_minutes // len(time_strings)
        hours = avg_minutes // 60
        minutes = avg_minutes % 60
        
        return f"{hours:02d}:{minutes:02d}"
    
    def _calculate_sleep_variability(self, durations: List[float]) -> float:
        """수면 시간 변동성 계산"""
        if len(durations) < 2:
            return 0.0
        
        avg = sum(durations) / len(durations)
        variance = sum((d - avg) ** 2 for d in durations) / len(durations)
        
        return round(variance ** 0.5, 2)  # 표준편차
    
    def _estimate_sleep_from_schedules(self, schedules: List[ShiftSchedule]) -> Dict[str, Any]:
        """근무표에서 수면 추정"""
        sleep_estimates = []
        bedtimes = []
        wake_times = []
        
        for schedule in schedules:
            if schedule.shiftType == ShiftType.OFF:
                # 휴무일: 일반적인 수면 패턴
                sleep_estimates.append(8.0)
                bedtimes.append("23:00")
                wake_times.append("07:00")
            elif schedule.shiftType == ShiftType.NIGHT:
                # 야간 근무: 낮잠 + 메인 수면
                sleep_estimates.append(6.5)
                bedtimes.append("09:00")  # 근무 후 낮잠
                wake_times.append("15:30")
            elif schedule.shiftType == ShiftType.DAY:
                # 주간 근무: 일반 수면
                sleep_estimates.append(7.5)
                bedtimes.append("22:30")
                wake_times.append("06:00")
            else:  # MID
                # 중간 근무: 약간 조정된 수면
                sleep_estimates.append(7.0)
                bedtimes.append("00:30")
                wake_times.append("07:30")
        
        avg_hours = sum(sleep_estimates) / len(sleep_estimates) if sleep_estimates else 0
        total_hours = sum(sleep_estimates)
        variability = self._calculate_sleep_variability(sleep_estimates)
        
        debt_info = SleepCalculator.calculate_sleep_debt(sleep_estimates, len(schedules))
        
        return {
            "avg_hours": round(avg_hours, 1),
            "avg_bedtime": self._calculate_average_time(bedtimes),
            "avg_wake_time": self._calculate_average_time(wake_times),
            "variability": variability,
            "total_hours": total_hours,
            "debt_info": debt_info
        }
    
    def _calculate_duration_score(self, sleep_metrics: Dict[str, Any]) -> float:
        """수면 시간 점수 계산"""
        avg_sleep = sleep_metrics.get("averageSleepHours", 0)
        
        if 7.5 <= avg_sleep <= 8.5:
            return 100.0
        elif 7.0 <= avg_sleep < 7.5 or 8.5 < avg_sleep <= 9.0:
            return 85.0
        elif 6.5 <= avg_sleep < 7.0 or 9.0 < avg_sleep <= 9.5:
            return 70.0
        elif 6.0 <= avg_sleep < 6.5 or 9.5 < avg_sleep <= 10.0:
            return 55.0
        else:
            return 30.0
    
    def _calculate_consistency_score(self, sleep_metrics: Dict[str, Any]) -> float:
        """수면 일관성 점수 계산"""
        variability = sleep_metrics.get("sleepVariability", 0)
        
        if variability <= 0.5:
            return 100.0
        elif variability <= 1.0:
            return 80.0
        elif variability <= 1.5:
            return 60.0
        elif variability <= 2.0:
            return 40.0
        else:
            return 20.0
    
    def _calculate_timing_score(
        self, 
        schedules: List[ShiftSchedule], 
        sleep_metrics: Dict[str, Any]
    ) -> float:
        """수면 타이밍 점수 계산"""
        # 근무 유형별 최적 수면 시간과의 일치도 평가
        night_shifts = len([s for s in schedules if s.shiftType == ShiftType.NIGHT])
        total_shifts = len([s for s in schedules if s.shiftType != ShiftType.OFF])
        
        if total_shifts == 0:
            return 80.0  # 기본값
        
        night_ratio = night_shifts / total_shifts
        
        # 야간 근무 비율에 따른 수면 타이밍 적절성 평가
        if night_ratio > 0.5:
            # 주로 야간 근무: 낮 시간 수면이 적절
            return 75.0  # 야간 근무자는 타이밍 점수가 낮을 수밖에 없음
        elif night_ratio > 0.2:
            # 혼합 근무: 유연한 수면 패턴 필요
            return 65.0
        else:
            # 주로 주간 근무: 일반적인 수면 타이밍
            return 90.0
    
    def _calculate_efficiency_score(self, sleep_data: Optional[Dict[str, Any]]) -> float:
        """수면 효율성 점수 계산"""
        if not sleep_data or "sleepSessions" not in sleep_data:
            return 75.0  # 데이터 없으면 평균값
        
        sessions = sleep_data["sleepSessions"]
        efficiencies = []
        
        for session in sessions:
            if "sleepEfficiency" in session:
                efficiencies.append(session["sleepEfficiency"])
        
        if not efficiencies:
            return 75.0
        
        avg_efficiency = sum(efficiencies) / len(efficiencies)
        
        if avg_efficiency >= 90:
            return 100.0
        elif avg_efficiency >= 85:
            return 85.0
        elif avg_efficiency >= 80:
            return 70.0
        elif avg_efficiency >= 75:
            return 55.0
        else:
            return 40.0
    
    def _calculate_recovery_score(
        self, 
        sleep_metrics: Dict[str, Any], 
        schedules: List[ShiftSchedule]
    ) -> float:
        """회복도 점수 계산"""
        debt_info = sleep_metrics.get("sleepDebt", {})
        debt_hours = debt_info.get("debt_hours", 0)
        
        # 수면 부채가 적을수록 높은 점수
        if debt_hours <= 2:
            return 100.0
        elif debt_hours <= 5:
            return 80.0
        elif debt_hours <= 10:
            return 60.0
        elif debt_hours <= 15:
            return 40.0
        else:
            return 20.0
    
    def _calculate_environment_score(
        self, 
        user_profile: UserProfile, 
        schedules: List[ShiftSchedule]
    ) -> float:
        """수면 환경 점수 계산"""
        # 교대근무 유형에 따른 환경 적응도 평가
        night_shifts = len([s for s in schedules if s.shiftType == ShiftType.NIGHT])
        
        if user_profile.shiftType == "FIXED_NIGHT":
            # 고정 야간: 야간 근무에 최적화된 환경
            return 85.0
        elif user_profile.shiftType == "IRREGULAR":
            # 불규칙: 환경 적응이 어려움
            return 60.0
        elif night_shifts > 0:
            # 야간 근무 포함: 환경 조정 필요
            return 70.0
        else:
            # 주간 근무만: 일반적인 환경
            return 90.0
    
    def _determine_quality_grade(self, score: float) -> str:
        """품질 등급 결정"""
        for grade, threshold in self.GRADE_THRESHOLDS.items():
            if score >= threshold:
                return grade
        return "F"
    
    def _analyze_sleep_patterns(
        self, 
        schedules: List[ShiftSchedule], 
        sleep_metrics: Dict[str, Any]
    ) -> Dict[str, Any]:
        """수면 패턴 분석"""
        
        # 근무 유형별 수면 패턴
        shift_distribution = {}
        for schedule in schedules:
            shift_type = schedule.shiftType
            shift_distribution[shift_type] = shift_distribution.get(shift_type, 0) + 1
        
        # 주요 패턴 식별
        total_days = len(schedules)
        night_ratio = shift_distribution.get(ShiftType.NIGHT, 0) / total_days if total_days > 0 else 0
        off_ratio = shift_distribution.get(ShiftType.OFF, 0) / total_days if total_days > 0 else 0
        
        if night_ratio > 0.5:
            pattern_type = "night_dominant"
            pattern_description = "야간 근무 중심의 수면 패턴"
        elif night_ratio > 0.2:
            pattern_type = "mixed_shifts"
            pattern_description = "혼합 교대근무 수면 패턴"
        elif off_ratio > 0.4:
            pattern_type = "regular_with_breaks"
            pattern_description = "충분한 휴식이 있는 규칙적 패턴"
        else:
            pattern_type = "regular_shifts"
            pattern_description = "규칙적인 교대근무 패턴"
        
        return {
            "patternType": pattern_type,
            "description": pattern_description,
            "shiftDistribution": shift_distribution,
            "nightShiftRatio": round(night_ratio * 100, 1),
            "restDayRatio": round(off_ratio * 100, 1),
            "averageSleepTime": sleep_metrics.get("averageBedtime", "알 수 없음"),
            "sleepConsistency": "높음" if sleep_metrics.get("sleepVariability", 0) < 1.0 else "낮음"
        }
    
    def _generate_recommendations(
        self,
        quality_grade: str,
        sleep_metrics: Dict[str, Any],
        sleep_patterns: Dict[str, Any],
        user_profile: UserProfile
    ) -> List[str]:
        """품질별 권장사항 생성"""
        
        recommendations = []
        
        # 등급별 기본 권장사항
        if quality_grade in ["D", "F"]:
            recommendations.append("🚨 수면 품질이 매우 낮습니다. 즉시 개선이 필요합니다")
            recommendations.append("수면 전문의 상담을 고려해보세요")
        elif quality_grade == "C":
            recommendations.append("⚠️ 수면 품질 개선이 필요합니다")
        elif quality_grade == "B":
            recommendations.append("✅ 양호한 수면 품질을 유지하고 있습니다")
        else:  # A
            recommendations.append("🌟 우수한 수면 품질입니다. 현재 패턴을 유지하세요")
        
        # 수면 시간 관련 권장사항
        avg_sleep = sleep_metrics.get("averageSleepHours", 0)
        if avg_sleep < 7:
            recommendations.append("수면 시간을 7-8시간으로 늘려보세요")
        elif avg_sleep > 9:
            recommendations.append("과도한 수면은 오히려 피로를 증가시킬 수 있습니다")
        
        # 일관성 관련 권장사항
        variability = sleep_metrics.get("sleepVariability", 0)
        if variability > 1.5:
            recommendations.append("수면 시간을 일정하게 유지하여 생체리듬을 안정화하세요")
        
        # 수면 부채 관련 권장사항
        debt_info = sleep_metrics.get("sleepDebt", {})
        debt_hours = debt_info.get("debt_hours", 0)
        if debt_hours > 5:
            recommendations.append("주말이나 휴무일에 수면 부채를 해결하세요")
        
        # 교대근무 유형별 권장사항
        if user_profile.shiftType == "IRREGULAR":
            recommendations.append("불규칙한 근무 시 수면 환경 최적화가 더욱 중요합니다")
        elif sleep_patterns.get("nightShiftRatio", 0) > 30:
            recommendations.append("야간 근무 후에는 어두운 환경에서 수면을 취하세요")
            recommendations.append("카페인 섭취 시간을 조절하여 수면에 영향을 주지 않도록 하세요")
        
        return recommendations[:6]  # 최대 6개 권장사항
    
    def _analyze_sleep_trend(
        self, 
        schedules: List[ShiftSchedule], 
        sleep_data: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """수면 트렌드 분석"""
        
        if len(schedules) < 4:
            return {
                "trend": "insufficient_data",
                "description": "트렌드 분석을 위한 데이터가 부족합니다"
            }
        
        # 전반부와 후반부 비교
        mid_point = len(schedules) // 2
        early_schedules = schedules[:mid_point]
        recent_schedules = schedules[mid_point:]
        
        # 야간 근무 비율 변화
        early_nights = len([s for s in early_schedules if s.shiftType == ShiftType.NIGHT])
        recent_nights = len([s for s in recent_schedules if s.shiftType == ShiftType.NIGHT])
        
        early_night_ratio = early_nights / len(early_schedules) if early_schedules else 0
        recent_night_ratio = recent_nights / len(recent_schedules) if recent_schedules else 0
        
        ratio_change = recent_night_ratio - early_night_ratio
        
        if ratio_change > 0.2:
            return {
                "trend": "deteriorating",
                "description": "야간 근무 증가로 수면 품질이 악화되고 있습니다",
                "change_factor": "increased_night_shifts"
            }
        elif ratio_change < -0.2:
            return {
                "trend": "improving",
                "description": "야간 근무 감소로 수면 품질이 개선되고 있습니다",
                "change_factor": "decreased_night_shifts"
            }
        else:
            return {
                "trend": "stable",
                "description": "수면 패턴이 안정적으로 유지되고 있습니다",
                "change_factor": "consistent_schedule"
            }
    
    def _determine_data_source(
        self, 
        sleep_data: Optional[Dict[str, Any]], 
        user_profile: UserProfile
    ) -> str:
        """데이터 소스 결정"""
        
        if sleep_data and "sleepSessions" in sleep_data:
            if user_profile.wearableConnected:
                return "wearable"
            else:
                return "mixed"
        else:
            return "estimated"