"""
AI 상담봇 엔진
AWS Bedrock을 활용한 교대근무자 전용 AI 상담봇
"""

import logging
import json
from datetime import datetime
from typing import Optional, Dict, Any, List
import boto3
from botocore.exceptions import ClientError

from ..models.common import (
    ChatRequest, ChatResponse, ChatHistory, UserProfile
)
from ..services.cache_service import CacheService
from ..services.database_service import DatabaseService
from ..utils.time_utils import TimeUtils

logger = logging.getLogger(__name__)


class AIChatbotEngine:
    """AI 상담봇 엔진 클래스"""
    
    # Bedrock 모델 설정
    MODEL_ID = "anthropic.claude-3-sonnet-20240229-v1:0"
    MAX_TOKENS = 1000
    TEMPERATURE = 0.7
    
    # 시스템 프롬프트
    SYSTEM_PROMPT = """
당신은 교대근무자를 위한 전문 수면 상담 AI입니다. 다음 역할을 수행합니다:

1. 교대근무자의 수면 문제 상담
2. 개인화된 수면 권장사항 제공
3. 피로 관리 및 건강 유지 조언
4. 근무 패턴에 따른 생활 리듬 조절 가이드

중요한 제약사항:
- 의료 진단이나 치료는 절대 제공하지 않습니다
- 심각한 건강 문제는 의료진 상담을 권합니다
- 개인정보는 절대 저장하거나 기억하지 않습니다
- 친근하고 공감적인 톤으로 대화합니다

응답은 한국어로 제공하며, 실용적이고 실행 가능한 조언을 중심으로 합니다.
"""
    
    def __init__(self, cache_service: CacheService, db_service: DatabaseService):
        self.cache = cache_service
        self.db = db_service
        self.bedrock_client = boto3.client('bedrock-runtime', region_name='us-east-1')
    
    async def process_message(
        self, 
        request: ChatRequest, 
        correlation_id: str
    ) -> ChatResponse:
        """사용자 메시지 처리"""
        try:
            logger.info(f"AI 상담봇 메시지 처리 시작: user_id={request.userId}")
            
            # 1. 사용자 컨텍스트 수집
            user_context = await self._collect_user_context(request.userId)
            
            # 2. 대화 기록 조회
            conversation_history = await self._get_conversation_history(
                request.userId, 
                request.conversationId
            )
            
            # 3. AI 응답 생성
            ai_response = await self._generate_ai_response(
                request.message,
                user_context,
                conversation_history
            )
            
            # 4. 대화 기록 저장
            chat_history = await self._save_chat_history(
                request.userId,
                request.conversationId or self._generate_conversation_id(),
                request.message,
                ai_response,
                correlation_id
            )
            
            logger.info(f"AI 상담봇 메시지 처리 완료: user_id={request.userId}")
            
            return ChatResponse(
                response=ai_response,
                conversationId=chat_history.conversationId,
                timestamp=TimeUtils.now_kst(),
                correlationId=correlation_id,
                disclaimer="이 상담은 의료 진단이나 치료를 대체하지 않습니다. 심각한 건강 문제는 의료진과 상담하세요."
            )
            
        except Exception as e:
            logger.error(f"AI 상담봇 처리 실패: {e}")
            
            # 에러 시 기본 응답
            return ChatResponse(
                response="죄송합니다. 일시적인 오류가 발생했습니다. 잠시 후 다시 시도해주세요.",
                conversationId=request.conversationId or self._generate_conversation_id(),
                timestamp=TimeUtils.now_kst(),
                correlationId=correlation_id,
                disclaimer="이 상담은 의료 진단이나 치료를 대체하지 않습니다."
            )
    
    async def _collect_user_context(self, user_id: str) -> Dict[str, Any]:
        """사용자 컨텍스트 수집"""
        try:
            # 사용자 프로필
            user_profile = await self.db.get_user_profile(user_id)
            
            # 최근 근무표 (7일)
            recent_schedules = await self.db.get_recent_schedules(user_id, 7)
            
            # 최근 엔진 결과 (수면 권장사항 등)
            recent_engine_results = await self.db.get_recent_engine_results(user_id, 3)
            
            return {
                "shiftType": user_profile.shiftType if user_profile else "UNKNOWN",
                "commuteMin": user_profile.commuteMin if user_profile else 30,
                "recentWorkPattern": self._analyze_work_pattern(recent_schedules),
                "hasRecentSleepRecommendation": len(recent_engine_results) > 0
            }
            
        except Exception as e:
            logger.error(f"사용자 컨텍스트 수집 실패: {e}")
            return {"shiftType": "UNKNOWN"}
    
    def _analyze_work_pattern(self, schedules: List[Dict[str, Any]]) -> str:
        """근무 패턴 분석"""
        if not schedules:
            return "no_recent_work"
        
        night_shifts = len([s for s in schedules if s.get("shiftType") == "NIGHT"])
        total_shifts = len([s for s in schedules if s.get("shiftType") != "OFF"])
        
        if total_shifts == 0:
            return "no_work"
        
        night_ratio = night_shifts / total_shifts
        
        if night_ratio > 0.7:
            return "mostly_night"
        elif night_ratio > 0.3:
            return "mixed_shifts"
        else:
            return "mostly_day"
    
    async def _get_conversation_history(
        self, 
        user_id: str, 
        conversation_id: Optional[str]
    ) -> List[Dict[str, str]]:
        """대화 기록 조회"""
        if not conversation_id:
            return []
        
        try:
            history = await self.db.get_chat_history(user_id, conversation_id, limit=10)
            
            # Bedrock 형식으로 변환
            formatted_history = []
            for chat in history:
                formatted_history.extend([
                    {"role": "user", "content": chat.userMessage},
                    {"role": "assistant", "content": chat.botResponse}
                ])
            
            return formatted_history[-10:]  # 최근 10개 메시지만
            
        except Exception as e:
            logger.error(f"대화 기록 조회 실패: {e}")
            return []
    
    async def _generate_ai_response(
        self,
        user_message: str,
        user_context: Dict[str, Any],
        conversation_history: List[Dict[str, str]]
    ) -> str:
        """AI 응답 생성"""
        try:
            # 컨텍스트 기반 시스템 프롬프트 보강
            enhanced_prompt = self._build_enhanced_prompt(user_context)
            
            # 메시지 구성
            messages = conversation_history + [
                {"role": "user", "content": user_message}
            ]
            
            # Bedrock 요청 구성
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": self.MAX_TOKENS,
                "temperature": self.TEMPERATURE,
                "system": enhanced_prompt,
                "messages": messages
            }
            
            # Bedrock 호출
            response = self.bedrock_client.invoke_model(
                modelId=self.MODEL_ID,
                body=json.dumps(request_body)
            )
            
            # 응답 파싱
            response_body = json.loads(response['body'].read())
            ai_response = response_body['content'][0]['text']
            
            return ai_response
            
        except ClientError as e:
            logger.error(f"Bedrock 호출 실패: {e}")
            return self._get_fallback_response(user_message, user_context)
        except Exception as e:
            logger.error(f"AI 응답 생성 실패: {e}")
            return self._get_fallback_response(user_message, user_context)
    
    def _build_enhanced_prompt(self, user_context: Dict[str, Any]) -> str:
        """사용자 컨텍스트 기반 프롬프트 보강"""
        enhanced_prompt = self.SYSTEM_PROMPT
        
        # 교대근무 유형별 특화 정보 추가
        shift_type = user_context.get("shiftType", "UNKNOWN")
        if shift_type == "THREE_SHIFT":
            enhanced_prompt += "\n\n사용자는 3교대 근무자입니다. 불규칙한 수면 패턴과 생체리듬 조절에 특히 주의를 기울여 조언하세요."
        elif shift_type == "NIGHT":
            enhanced_prompt += "\n\n사용자는 야간 근무자입니다. 낮잠 활용과 빛 노출 관리에 중점을 둔 조언을 제공하세요."
        elif shift_type == "IRREGULAR":
            enhanced_prompt += "\n\n사용자는 불규칙한 근무 패턴을 가지고 있습니다. 유연한 수면 전략과 적응 방법을 제안하세요."
        
        # 근무 패턴별 맞춤 정보
        work_pattern = user_context.get("recentWorkPattern", "unknown")
        if work_pattern == "mostly_night":
            enhanced_prompt += "\n\n최근 주로 야간 근무를 하고 있습니다. 야간 근무 후 회복과 낮잠 전략에 집중하세요."
        elif work_pattern == "mixed_shifts":
            enhanced_prompt += "\n\n최근 다양한 시간대의 근무를 하고 있습니다. 변화하는 스케줄에 적응하는 방법을 제안하세요."
        
        return enhanced_prompt
    
    def _get_fallback_response(
        self, 
        user_message: str, 
        user_context: Dict[str, Any]
    ) -> str:
        """AI 서비스 장애 시 대체 응답"""
        # 키워드 기반 간단한 응답
        message_lower = user_message.lower()
        
        if any(keyword in message_lower for keyword in ["수면", "잠", "sleep"]):
            return """교대근무자의 수면 관리는 정말 중요합니다. 몇 가지 기본 원칙을 제안드립니다:

1. 일정한 수면 스케줄 유지하기
2. 수면 환경을 어둡고 조용하게 만들기
3. 카페인 섭취 시간 조절하기
4. 짧은 낮잠 활용하기 (20-30분)

더 구체적인 상담이 필요하시면 다시 말씀해 주세요."""
        
        elif any(keyword in message_lower for keyword in ["피로", "tired", "fatigue"]):
            return """교대근무로 인한 피로는 자연스러운 현상입니다. 피로 관리 방법을 제안드립니다:

1. 충분한 수분 섭취
2. 규칙적인 가벼운 운동
3. 영양 균형 잡힌 식사
4. 스트레스 관리
5. 적절한 휴식 시간 확보

지속적인 피로감이 있으시면 의료진과 상담하시기 바랍니다."""
        
        else:
            return """안녕하세요! 교대근무자를 위한 수면 상담 AI입니다. 

다음과 같은 주제로 도움을 드릴 수 있습니다:
- 수면 패턴 개선 방법
- 피로 관리 전략
- 근무 시간대별 생활 리듬 조절
- 카페인 섭취 타이밍
- 스트레스 관리

궁금한 점이 있으시면 언제든 말씀해 주세요!"""
    
    async def _save_chat_history(
        self,
        user_id: str,
        conversation_id: str,
        user_message: str,
        bot_response: str,
        correlation_id: str
    ) -> ChatHistory:
        """대화 기록 저장"""
        try:
            chat_history = await self.db.save_chat_history(
                user_id=user_id,
                conversation_id=conversation_id,
                user_message=user_message,
                bot_response=bot_response,
                correlation_id=correlation_id
            )
            
            return chat_history
            
        except Exception as e:
            logger.error(f"대화 기록 저장 실패: {e}")
            # 저장 실패해도 응답은 반환
            return ChatHistory(
                chatId=f"temp-{datetime.now().timestamp()}",
                userId=user_id,
                conversationId=conversation_id,
                userMessage=user_message,
                botResponse=bot_response,
                timestamp=TimeUtils.now_kst(),
                correlationId=correlation_id
            )
    
    def _generate_conversation_id(self) -> str:
        """새 대화 ID 생성"""
        import uuid
        return f"conv-{uuid.uuid4().hex[:12]}"
    
    async def get_chat_history(
        self, 
        user_id: str, 
        limit: int = 20, 
        offset: int = 0
    ) -> List[ChatHistory]:
        """채팅 기록 조회"""
        try:
            return await self.db.get_user_chat_history(user_id, limit, offset)
        except Exception as e:
            logger.error(f"채팅 기록 조회 실패: {e}")
            return []
    
    async def clear_chat_history(self, user_id: str) -> bool:
        """채팅 기록 삭제"""
        try:
            await self.db.clear_user_chat_history(user_id)
            return True
        except Exception as e:
            logger.error(f"채팅 기록 삭제 실패: {e}")
            return False
    
    async def get_conversation_summary(
        self, 
        user_id: str, 
        conversation_id: str
    ) -> Optional[str]:
        """대화 요약 생성"""
        try:
            history = await self.db.get_chat_history(user_id, conversation_id)
            
            if not history or len(history) < 3:
                return None
            
            # 간단한 요약 로직 (실제로는 AI 모델 사용 가능)
            total_messages = len(history)
            topics = set()
            
            for chat in history:
                message_lower = chat.userMessage.lower()
                if any(keyword in message_lower for keyword in ["수면", "잠"]):
                    topics.add("수면 관리")
                if any(keyword in message_lower for keyword in ["피로", "tired"]):
                    topics.add("피로 관리")
                if any(keyword in message_lower for keyword in ["카페인", "coffee"]):
                    topics.add("카페인 조절")
            
            topic_str = ", ".join(topics) if topics else "일반 상담"
            return f"{total_messages}개 메시지 - 주요 주제: {topic_str}"
            
        except Exception as e:
            logger.error(f"대화 요약 생성 실패: {e}")
            return None