"""
Meal Time Checker 엔진
교대근무자를 위한 개인화된 식사 시간 관리 및 영양 가이드
"""

import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from ..models.common import (
    EngineResponse, MealTimeRequest, MealTimeResult,
    UserProfile, ShiftSchedule, CacheKey, EngineType, ShiftType
)
from ..services.cache_service import CacheService
from ..services.database_service import DatabaseService
from ..utils.time_utils import TimeUtils

logger = logging.getLogger(__name__)


class MealTimeCheckerEngine:
    """Meal Time Checker 엔진 클래스"""
    
    # 식사 유형별 권장 시간 (근무 시작 기준)
    MEAL_TIMING = {
        ShiftType.DAY: {
            "breakfast": {"hours_before_work": 1.5, "duration_minutes": 30},
            "lunch": {"hours_after_start": 4, "duration_minutes": 45},
            "dinner": {"hours_after_work": 2, "duration_minutes": 45},
            "snack": {"hours_after_start": 2, "duration_minutes": 15}
        },
        ShiftType.MID: {
            "breakfast": {"hours_before_work": 2, "duration_minutes": 30},
            "lunch": {"hours_after_start": 3, "duration_minutes": 45},
            "dinner": {"hours_after_work": 1.5, "duration_minutes": 45},
            "snack": {"hours_after_start": 5, "duration_minutes": 15}
        },
        ShiftType.NIGHT: {
            "dinner": {"hours_before_work": 2, "duration_minutes": 45},
            "midnight_meal": {"hours_after_start": 4, "duration_minutes": 30},
            "breakfast": {"hours_after_work": 1, "duration_minutes": 30},
            "snack": {"hours_after_start": 2, "duration_minutes": 15}
        },
        ShiftType.OFF: {
            "breakfast": {"time": "08:00", "duration_minutes": 30},
            "lunch": {"time": "12:30", "duration_minutes": 45},
            "dinner": {"time": "18:30", "duration_minutes": 45},
            "snack": {"time": "15:00", "duration_minutes": 15}
        }
    }
    
    # 교대근무별 영양 권장사항
    NUTRITION_GUIDELINES = {
        ShiftType.DAY: {
            "focus": ["energy_maintenance", "afternoon_alertness"],
            "avoid": ["heavy_lunch", "late_caffeine"],
            "hydration": "regular_throughout_day"
        },
        ShiftType.MID: {
            "focus": ["sustained_energy", "evening_recovery"],
            "avoid": ["heavy_dinner", "excessive_caffeine"],
            "hydration": "increased_during_shift"
        },
        ShiftType.NIGHT: {
            "focus": ["alertness_support", "digestive_health"],
            "avoid": ["heavy_meals_during_shift", "caffeine_before_sleep"],
            "hydration": "careful_timing"
        },
        ShiftType.OFF: {
            "focus": ["recovery", "regular_pattern"],
            "avoid": ["irregular_timing", "overeating"],
            "hydration": "normal_pattern"
        }
    }
    
    def __init__(self, cache_service: CacheService, db_service: DatabaseService):
        self.cache = cache_service
        self.db = db_service
    
    async def calculate(
        self, 
        request: MealTimeRequest, 
        correlation_id: str
    ) -> EngineResponse:
        """식사 시간 체크 및 권장사항 생성"""
        try:
            logger.info(f"Meal Time Checker 계산 시작: user_id={request.userId}")
            
            # 1. 캐시 확인
            if not request.forceRefresh:
                cached_result = await self._get_cached_result(request)
                if cached_result:
                    logger.info(f"캐시에서 결과 반환: user_id={request.userId}")
                    return EngineResponse(
                        result=cached_result,
                        generatedAt=TimeUtils.now_kst(),
                        correlationId=correlation_id
                    )
            
            # 2. 입력 데이터 수집 및 검증
            validation_result = await self._validate_and_collect_data(request)
            if not validation_result["is_valid"]:
                return EngineResponse(
                    whyNotShown=validation_result["reason"],
                    dataMissing=validation_result["missing_data"],
                    generatedAt=TimeUtils.now_kst(),
                    correlationId=correlation_id
                )
            
            data = validation_result["data"]
            
            # 3. 식사 시간 분석 및 권장사항 생성
            meal_result = await self._analyze_meal_timing(
                data["user_profile"],
                data["today_schedule"],
                data["current_time"],
                request.mealType
            )
            
            # 4. 결과 캐시 저장
            await self._cache_result(request, meal_result)
            
            logger.info(f"Meal Time Checker 계산 완료: user_id={request.userId}")
            
            return EngineResponse(
                result=meal_result.dict(),
                generatedAt=TimeUtils.now_kst(),
                correlationId=correlation_id
            )
            
        except Exception as e:
            logger.error(f"Meal Time Checker 계산 실패: {e}")
            return EngineResponse(
                whyNotShown="CALCULATION_ERROR",
                dataMissing=[],
                generatedAt=TimeUtils.now_kst(),
                correlationId=correlation_id
            )
    
    async def _get_cached_result(self, request: MealTimeRequest) -> Optional[Dict[str, Any]]:
        """캐시된 결과 조회"""
        try:
            cache_key = CacheKey(
                engine_type=EngineType.MEAL_TIME_CHECKER,
                user_id=request.userId,
                target_date=request.targetDate or TimeUtils.today_kst(),
                parameters_hash=self._generate_params_hash(request)
            )
            
            return await self.cache.get(cache_key)
            
        except Exception as e:
            logger.error(f"캐시 조회 실패: {e}")
            return None
    
    async def _cache_result(self, request: MealTimeRequest, result: MealTimeResult):
        """결과 캐시 저장"""
        try:
            cache_key = CacheKey(
                engine_type=EngineType.MEAL_TIME_CHECKER,
                user_id=request.userId,
                target_date=request.targetDate or TimeUtils.today_kst(),
                parameters_hash=self._generate_params_hash(request)
            )
            
            await self.cache.set(cache_key, result.dict())
            
        except Exception as e:
            logger.error(f"캐시 저장 실패: {e}")
    
    def _generate_params_hash(self, request: MealTimeRequest) -> str:
        """매개변수 해시 생성"""
        import hashlib
        
        params = f"{request.mealType}_{request.currentTime}"
        return hashlib.md5(params.encode()).hexdigest()[:8]
    
    async def _validate_and_collect_data(self, request: MealTimeRequest) -> Dict[str, Any]:
        """입력 데이터 검증 및 수집"""
        missing_data = []
        
        # 사용자 프로필 조회
        user_profile = await self.db.get_user_profile(request.userId)
        if not user_profile:
            missing_data.append("USER_PROFILE")
        
        # 대상 날짜 설정
        target_date = request.targetDate or TimeUtils.today_kst()
        
        # 오늘 근무표 조회
        today_schedule = await self.db.get_schedule_by_date(request.userId, target_date)
        
        # 현재 시간 설정
        current_time = TimeUtils.parse_datetime(request.currentTime) if request.currentTime else datetime.now()
        
        # 검증 결과
        if missing_data:
            return {
                "is_valid": False,
                "reason": "INSUFFICIENT_DATA",
                "missing_data": missing_data,
                "data": None
            }
        
        return {
            "is_valid": True,
            "reason": None,
            "missing_data": [],
            "data": {
                "user_profile": user_profile,
                "today_schedule": today_schedule,
                "current_time": current_time,
                "target_date": target_date
            }
        }
    
    async def _analyze_meal_timing(
        self,
        user_profile: UserProfile,
        today_schedule: Optional[ShiftSchedule],
        current_time: datetime,
        requested_meal_type: Optional[str]
    ) -> MealTimeResult:
        """식사 시간 분석 메인 로직"""
        
        # 1. 현재 근무 상황 분석
        shift_type = today_schedule.shiftType if today_schedule else ShiftType.OFF
        
        # 2. 현재 식사 시간대 분석
        current_meal_window = self._analyze_current_meal_window(
            current_time, shift_type, today_schedule
        )
        
        # 3. 다음 식사 시간 계산
        next_meal_time = self._calculate_next_meal_time(
            current_time, shift_type, today_schedule, requested_meal_type
        )
        
        # 4. 하루 전체 식사 스케줄 생성
        meal_schedule = self._generate_daily_meal_schedule(
            shift_type, today_schedule
        )
        
        # 5. 영양 팁 생성
        nutrition_tips = self._generate_nutrition_tips(
            shift_type, current_meal_window, user_profile
        )
        
        # 6. 교대근무별 식사 조언
        shift_work_advice = self._generate_shift_work_advice(
            shift_type, today_schedule, current_time
        )
        
        # 7. 수분 섭취 알림
        hydration_reminder = self._generate_hydration_reminder(
            shift_type, current_time, today_schedule
        )
        
        return MealTimeResult(
            currentMealWindow=current_meal_window,
            nextMealTime=next_meal_time,
            mealSchedule=meal_schedule,
            nutritionTips=nutrition_tips,
            shiftWorkAdvice=shift_work_advice,
            hydrationReminder=hydration_reminder
        )
    
    def _analyze_current_meal_window(
        self,
        current_time: datetime,
        shift_type: ShiftType,
        schedule: Optional[ShiftSchedule]
    ) -> Dict[str, Any]:
        """현재 식사 시간대 분석"""
        
        current_hour = current_time.hour
        
        # 시간대별 식사 구분
        if 6 <= current_hour < 10:
            meal_type = "breakfast"
            status = "optimal"
        elif 11 <= current_hour < 14:
            meal_type = "lunch"
            status = "optimal"
        elif 17 <= current_hour < 20:
            meal_type = "dinner"
            status = "optimal"
        elif 14 <= current_hour < 17 or 20 <= current_hour < 22:
            meal_type = "snack"
            status = "appropriate"
        else:
            # 야간 시간대
            if shift_type == ShiftType.NIGHT and schedule:
                meal_type = "night_meal"
                status = "shift_appropriate"
            else:
                meal_type = "avoid_eating"
                status = "not_recommended"
        
        # 근무 상황에 따른 조정
        if schedule and schedule.startAt and schedule.endAt:
            work_start = TimeUtils.parse_datetime(schedule.startAt)
            work_end = TimeUtils.parse_datetime(schedule.endAt)
            
            # 근무 중인지 확인
            if work_start <= current_time <= work_end:
                if meal_type in ["breakfast", "lunch", "dinner"]:
                    status = "work_break_needed"
                elif meal_type == "snack":
                    status = "work_snack_ok"
        
        return {
            "mealType": meal_type,
            "status": status,
            "currentTime": TimeUtils.format_datetime(current_time),
            "recommendation": self._get_meal_window_recommendation(meal_type, status, shift_type),
            "timeUntilNext": self._calculate_time_until_next_meal(current_time, shift_type, schedule)
        }
    
    def _get_meal_window_recommendation(
        self, 
        meal_type: str, 
        status: str, 
        shift_type: ShiftType
    ) -> str:
        """식사 시간대별 권장사항"""
        
        recommendations = {
            ("breakfast", "optimal"): "아침 식사하기 좋은 시간입니다",
            ("lunch", "optimal"): "점심 식사 시간입니다",
            ("dinner", "optimal"): "저녁 식사 시간입니다",
            ("snack", "appropriate"): "가벼운 간식을 드셔도 좋습니다",
            ("night_meal", "shift_appropriate"): "야간 근무 중 식사 시간입니다",
            ("avoid_eating", "not_recommended"): "식사보다는 수분 섭취를 권장합니다",
            ("breakfast", "work_break_needed"): "가능하다면 짧은 휴식을 취하고 식사하세요",
            ("lunch", "work_break_needed"): "점심 휴식 시간을 활용하세요",
            ("dinner", "work_break_needed"): "근무 중이지만 저녁 식사가 필요합니다",
            ("snack", "work_snack_ok"): "근무 중 간단한 간식은 괜찮습니다"
        }
        
        return recommendations.get((meal_type, status), "적절한 식사 시간을 고려해보세요")
    
    def _calculate_time_until_next_meal(
        self,
        current_time: datetime,
        shift_type: ShiftType,
        schedule: Optional[ShiftSchedule]
    ) -> Dict[str, Any]:
        """다음 식사까지 시간 계산"""
        
        # 다음 주요 식사 시간들
        next_meals = []
        
        if shift_type == ShiftType.OFF:
            # 휴무일 일반 식사 시간
            meal_times = [
                ("breakfast", 8, 0),
                ("lunch", 12, 30),
                ("dinner", 18, 30)
            ]
        elif shift_type == ShiftType.NIGHT and schedule:
            # 야간 근무 식사 시간
            work_start = TimeUtils.parse_datetime(schedule.startAt)
            meal_times = [
                ("pre_work_dinner", work_start.hour - 2, 0),
                ("night_meal", work_start.hour + 4, 0),
                ("post_work_breakfast", work_start.hour + 10, 0)
            ]
        else:
            # 주간/중간 근무 일반 식사 시간
            meal_times = [
                ("breakfast", 7, 0),
                ("lunch", 12, 0),
                ("dinner", 18, 0)
            ]
        
        # 현재 시간 이후 가장 가까운 식사 시간 찾기
        for meal_name, hour, minute in meal_times:
            meal_time = current_time.replace(hour=hour, minute=minute, second=0, microsecond=0)
            
            # 오늘 시간이 지났으면 내일로
            if meal_time <= current_time:
                meal_time += timedelta(days=1)
            
            time_diff = meal_time - current_time
            next_meals.append({
                "meal": meal_name,
                "time": TimeUtils.format_datetime(meal_time),
                "minutes_until": int(time_diff.total_seconds() / 60)
            })
        
        # 가장 가까운 식사 반환
        if next_meals:
            next_meal = min(next_meals, key=lambda x: x["minutes_until"])
            return next_meal
        
        return {"meal": "unknown", "time": "", "minutes_until": 0}
    
    def _calculate_next_meal_time(
        self,
        current_time: datetime,
        shift_type: ShiftType,
        schedule: Optional[ShiftSchedule],
        requested_meal_type: Optional[str]
    ) -> Dict[str, Any]:
        """다음 식사 시간 계산"""
        
        if requested_meal_type:
            # 특정 식사 유형 요청 시
            next_time = self._calculate_specific_meal_time(
                current_time, shift_type, schedule, requested_meal_type
            )
        else:
            # 일반적인 다음 식사 시간
            next_time = self._calculate_time_until_next_meal(
                current_time, shift_type, schedule
            )
        
        # 권장사항 추가
        meal_advice = self._get_meal_specific_advice(
            next_time.get("meal", ""), shift_type
        )
        
        return {
            **next_time,
            "advice": meal_advice,
            "preparation_time": 15,  # 준비 시간 (분)
            "optimal_duration": self._get_optimal_meal_duration(next_time.get("meal", ""))
        }
    
    def _calculate_specific_meal_time(
        self,
        current_time: datetime,
        shift_type: ShiftType,
        schedule: Optional[ShiftSchedule],
        meal_type: str
    ) -> Dict[str, Any]:
        """특정 식사 시간 계산"""
        
        timing_rules = self.MEAL_TIMING.get(shift_type, {})
        meal_rule = timing_rules.get(meal_type)
        
        if not meal_rule:
            return {"meal": meal_type, "time": "", "minutes_until": 0}
        
        if "time" in meal_rule:
            # 고정 시간 (휴무일)
            hour, minute = map(int, meal_rule["time"].split(":"))
            meal_time = current_time.replace(hour=hour, minute=minute, second=0, microsecond=0)
            
            if meal_time <= current_time:
                meal_time += timedelta(days=1)
        
        elif schedule and schedule.startAt:
            # 근무 시간 기준 계산
            work_start = TimeUtils.parse_datetime(schedule.startAt)
            
            if "hours_before_work" in meal_rule:
                meal_time = work_start - timedelta(hours=meal_rule["hours_before_work"])
            elif "hours_after_start" in meal_rule:
                meal_time = work_start + timedelta(hours=meal_rule["hours_after_start"])
            elif "hours_after_work" in meal_rule and schedule.endAt:
                work_end = TimeUtils.parse_datetime(schedule.endAt)
                meal_time = work_end + timedelta(hours=meal_rule["hours_after_work"])
            else:
                meal_time = current_time + timedelta(hours=2)  # 기본값
        else:
            meal_time = current_time + timedelta(hours=2)  # 기본값
        
        time_diff = meal_time - current_time
        
        return {
            "meal": meal_type,
            "time": TimeUtils.format_datetime(meal_time),
            "minutes_until": max(0, int(time_diff.total_seconds() / 60))
        }
    
    def _generate_daily_meal_schedule(
        self,
        shift_type: ShiftType,
        schedule: Optional[ShiftSchedule]
    ) -> List[Dict[str, Any]]:
        """하루 전체 식사 스케줄 생성"""
        
        meal_schedule = []
        timing_rules = self.MEAL_TIMING.get(shift_type, {})
        
        for meal_type, rule in timing_rules.items():
            meal_info = {
                "mealType": meal_type,
                "duration": rule["duration_minutes"],
                "importance": self._get_meal_importance(meal_type, shift_type)
            }
            
            if "time" in rule:
                # 고정 시간
                meal_info["scheduledTime"] = rule["time"]
                meal_info["timeType"] = "fixed"
            elif schedule and schedule.startAt:
                # 근무 시간 기준
                work_start = TimeUtils.parse_datetime(schedule.startAt)
                
                if "hours_before_work" in rule:
                    meal_time = work_start - timedelta(hours=rule["hours_before_work"])
                elif "hours_after_start" in rule:
                    meal_time = work_start + timedelta(hours=rule["hours_after_start"])
                elif "hours_after_work" in rule and schedule.endAt:
                    work_end = TimeUtils.parse_datetime(schedule.endAt)
                    meal_time = work_end + timedelta(hours=rule["hours_after_work"])
                else:
                    continue
                
                meal_info["scheduledTime"] = meal_time.strftime("%H:%M")
                meal_info["timeType"] = "work_based"
            else:
                continue
            
            meal_schedule.append(meal_info)
        
        # 시간순 정렬
        meal_schedule.sort(key=lambda x: x["scheduledTime"])
        
        return meal_schedule
    
    def _get_meal_importance(self, meal_type: str, shift_type: ShiftType) -> str:
        """식사 중요도 평가"""
        
        importance_map = {
            "breakfast": "high",
            "lunch": "high", 
            "dinner": "high",
            "midnight_meal": "medium" if shift_type == ShiftType.NIGHT else "low",
            "snack": "low",
            "pre_work_dinner": "high" if shift_type == ShiftType.NIGHT else "medium"
        }
        
        return importance_map.get(meal_type, "medium")
    
    def _get_optimal_meal_duration(self, meal_type: str) -> int:
        """최적 식사 시간 (분)"""
        
        durations = {
            "breakfast": 25,
            "lunch": 40,
            "dinner": 45,
            "snack": 10,
            "midnight_meal": 30,
            "night_meal": 30
        }
        
        return durations.get(meal_type, 30)
    
    def _get_meal_specific_advice(self, meal_type: str, shift_type: ShiftType) -> str:
        """식사별 구체적 조언"""
        
        advice_map = {
            ("breakfast", ShiftType.DAY): "단백질과 복합탄수화물로 하루를 시작하세요",
            ("breakfast", ShiftType.NIGHT): "근무 후 가벼운 아침식사로 회복하세요",
            ("lunch", ShiftType.DAY): "균형잡힌 점심으로 오후 에너지를 충전하세요",
            ("lunch", ShiftType.MID): "근무 중간 영양가 있는 식사를 하세요",
            ("dinner", ShiftType.DAY): "소화가 잘 되는 저녁식사를 하세요",
            ("dinner", ShiftType.NIGHT): "근무 전 든든한 저녁식사가 중요합니다",
            ("snack", ShiftType.NIGHT): "야간 근무 중 가벼운 간식으로 에너지를 보충하세요",
            ("midnight_meal", ShiftType.NIGHT): "소화가 쉬운 음식으로 야식을 드세요"
        }
        
        return advice_map.get((meal_type, shift_type), "균형잡힌 식사를 하세요")
    
    def _generate_nutrition_tips(
        self,
        shift_type: ShiftType,
        current_meal_window: Dict[str, Any],
        user_profile: UserProfile
    ) -> List[str]:
        """영양 팁 생성"""
        
        tips = []
        guidelines = self.NUTRITION_GUIDELINES.get(shift_type, {})
        
        # 교대근무별 기본 팁
        if shift_type == ShiftType.NIGHT:
            tips.extend([
                "야간 근무 시 소화가 쉬운 음식을 선택하세요",
                "카페인은 근무 시작 6시간 전까지만 섭취하세요",
                "단백질과 복합탄수화물을 균형있게 섭취하세요"
            ])
        elif shift_type == ShiftType.DAY:
            tips.extend([
                "아침 식사를 거르지 마세요",
                "점심 후 졸음을 방지하기 위해 과식을 피하세요",
                "오후 3시 이후 카페인 섭취를 줄이세요"
            ])
        elif shift_type == ShiftType.MID:
            tips.extend([
                "근무 전 충분한 에너지 공급을 위해 든든히 드세요",
                "근무 중 혈당 유지를 위해 간식을 준비하세요",
                "늦은 저녁 식사는 가볍게 하세요"
            ])
        else:  # OFF
            tips.extend([
                "규칙적인 식사 시간을 유지하세요",
                "다음 근무를 위해 영양소를 충분히 섭취하세요",
                "휴식일에도 과식은 피하세요"
            ])
        
        # 현재 식사 상황별 추가 팁
        current_meal = current_meal_window.get("mealType", "")
        if current_meal == "breakfast":
            tips.append("아침에는 단백질 15-20g을 포함한 식사를 하세요")
        elif current_meal == "lunch":
            tips.append("점심에는 채소를 충분히 포함한 균형식을 하세요")
        elif current_meal == "dinner":
            tips.append("저녁에는 소화가 잘 되는 음식을 선택하세요")
        
        return tips[:5]  # 최대 5개 팁
    
    def _generate_shift_work_advice(
        self,
        shift_type: ShiftType,
        schedule: Optional[ShiftSchedule],
        current_time: datetime
    ) -> Dict[str, Any]:
        """교대근무별 식사 조언"""
        
        if shift_type == ShiftType.NIGHT:
            return {
                "title": "야간 근무 식사 가이드",
                "mainAdvice": "생체리듬을 고려한 식사 타이밍이 중요합니다",
                "keyPoints": [
                    "근무 시작 2-3시간 전에 주 식사를 하세요",
                    "근무 중에는 가벼운 간식 위주로 섭취하세요",
                    "근무 후에는 소화가 쉬운 음식으로 마무리하세요",
                    "수면 2시간 전에는 식사를 마치세요"
                ],
                "avoidFoods": ["기름진 음식", "매운 음식", "과도한 카페인", "단순당"],
                "recommendFoods": ["단백질", "복합탄수화물", "채소", "견과류"]
            }
        elif shift_type == ShiftType.DAY:
            return {
                "title": "주간 근무 식사 가이드", 
                "mainAdvice": "규칙적인 식사로 안정적인 에너지를 유지하세요",
                "keyPoints": [
                    "아침 식사로 하루를 든든히 시작하세요",
                    "점심은 과하지 않게 균형있게 드세요",
                    "오후 간식으로 에너지를 보충하세요",
                    "저녁은 일찍, 가볍게 드세요"
                ],
                "avoidFoods": ["과도한 점심", "늦은 저녁식사", "오후 과다 카페인"],
                "recommendFoods": ["균형잡힌 아침", "가벼운 점심", "건강한 간식"]
            }
        elif shift_type == ShiftType.MID:
            return {
                "title": "중간 근무 식사 가이드",
                "mainAdvice": "근무 시간에 맞춘 유연한 식사 계획이 필요합니다",
                "keyPoints": [
                    "늦은 아침 또는 이른 점심으로 시작하세요",
                    "근무 중 적절한 간식을 준비하세요",
                    "늦은 저녁 식사는 소화에 부담이 없게 하세요",
                    "수면 전 2-3시간은 금식하세요"
                ],
                "avoidFoods": ["늦은 시간 과식", "자극적인 음식"],
                "recommendFoods": ["소화 잘되는 음식", "적당한 간식"]
            }
        else:  # OFF
            return {
                "title": "휴무일 식사 가이드",
                "mainAdvice": "규칙적인 패턴으로 다음 근무를 준비하세요",
                "keyPoints": [
                    "일정한 시간에 식사하여 생체리듬을 유지하세요",
                    "영양가 있는 음식으로 몸을 회복시키세요",
                    "과식하지 말고 적당량을 드세요",
                    "충분한 수분을 섭취하세요"
                ],
                "avoidFoods": ["불규칙한 식사", "과식", "정크푸드"],
                "recommendFoods": ["신선한 채소", "양질의 단백질", "충분한 수분"]
            }
    
    def _generate_hydration_reminder(
        self,
        shift_type: ShiftType,
        current_time: datetime,
        schedule: Optional[ShiftSchedule]
    ) -> Dict[str, Any]:
        """수분 섭취 알림"""
        
        current_hour = current_time.hour
        
        # 기본 수분 섭취 목표 (ml)
        daily_target = 2000
        
        # 교대근무별 조정
        if shift_type == ShiftType.NIGHT:
            daily_target = 2200  # 야간 근무 시 더 많이
        elif shift_type in [ShiftType.DAY, ShiftType.MID]:
            daily_target = 2100
        
        # 현재까지 권장 섭취량 계산
        hours_passed = current_hour if current_hour >= 6 else current_hour + 24 - 6
        target_so_far = int(daily_target * hours_passed / 18)  # 18시간 활동 기준
        
        # 다음 수분 섭취 시간
        next_hydration_time = current_time + timedelta(hours=1)
        
        # 상황별 메시지
        if shift_type == ShiftType.NIGHT and 22 <= current_hour or current_hour <= 6:
            message = "야간 근무 중 수분 섭취를 잊지 마세요"
            tip = "카페인 음료보다는 물이나 허브차를 권장합니다"
        elif 14 <= current_hour <= 16:
            message = "오후 피로 방지를 위해 수분을 보충하세요"
            tip = "물과 함께 가벼운 간식을 드시면 좋습니다"
        else:
            message = "규칙적인 수분 섭취로 건강을 유지하세요"
            tip = "한 번에 많이 마시지 말고 조금씩 자주 드세요"
        
        return {
            "dailyTarget": daily_target,
            "targetSoFar": target_so_far,
            "nextReminderTime": TimeUtils.format_datetime(next_hydration_time),
            "message": message,
            "tip": tip,
            "recommendedAmount": 200,  # 한 번에 마실 권장량 (ml)
            "frequency": "매 1시간마다"
        }