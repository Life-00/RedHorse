"""
FastAPI 공통 모델 정의
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any, Union
from datetime import datetime
from enum import Enum


# Enum 정의
class ShiftType(str, Enum):
    DAY = "DAY"
    MID = "MID"
    NIGHT = "NIGHT"
    OFF = "OFF"


class EngineType(str, Enum):
    SHIFT_TO_SLEEP = "SHIFT_TO_SLEEP"
    CAFFEINE_CUTOFF = "CAFFEINE_CUTOFF"
    FATIGUE_RISK = "FATIGUE_RISK"
    DAILY_JUMPSTART = "DAILY_JUMPSTART"
    SLEEP_QUALITY = "SLEEP_QUALITY"
    MEAL_TIME_CHECKER = "MEAL_TIME_CHECKER"


class UserShiftType(str, Enum):
    TWO_SHIFT = "TWO_SHIFT"
    THREE_SHIFT = "THREE_SHIFT"
    FIXED_NIGHT = "FIXED_NIGHT"
    IRREGULAR = "IRREGULAR"


# 기본 모델들
class UserProfile(BaseModel):
    userId: str
    cognitoSub: str
    shiftType: UserShiftType
    commuteMin: int
    wearableConnected: bool
    orgId: Optional[str] = None
    lastActiveAt: str
    createdAt: str
    updatedAt: str


class ShiftSchedule(BaseModel):
    scheduleId: str
    userId: str
    date: str  # YYYY-MM-DD
    shiftType: ShiftType
    startAt: Optional[str] = None  # ISO 8601
    endAt: Optional[str] = None    # ISO 8601
    commuteMin: int
    note: Optional[str] = None
    createdAt: str
    updatedAt: str


# 엔진 요청/응답 모델들
class EngineResponse(BaseModel):
    result: Optional[Dict[str, Any]] = None
    whyNotShown: Optional[str] = None
    dataMissing: Optional[List[str]] = None
    generatedAt: str
    correlationId: Optional[str] = None


class SleepWindow(BaseModel):
    startAt: str
    endAt: str
    durationHours: float
    quality: str


class ShiftToSleepRequest(BaseModel):
    userId: str
    targetDate: Optional[str] = None  # YYYY-MM-DD
    sleepDurationHours: Optional[float] = 8.0
    bufferMinutes: Optional[int] = 30
    forceRefresh: bool = False


class ShiftToSleepResult(BaseModel):
    sleepMain: SleepWindow
    sleepNap: Optional[SleepWindow] = None
    recommendations: List[str]
    conflictWarnings: List[str]


class CaffeineCutoffRequest(BaseModel):
    userId: str
    targetDate: Optional[str] = None
    targetSleepTime: Optional[str] = None  # ISO 8601
    caffeineAmountMg: Optional[float] = 100.0
    halfLifeHours: Optional[float] = 5.0
    safeThresholdMg: Optional[float] = 25.0
    forceRefresh: bool = False


class CaffeineCutoffResult(BaseModel):
    caffeineDeadline: str
    hoursBeforeSleep: float
    targetSleepTime: str
    halfLifeInfo: Dict[str, Any]
    recommendations: List[str]
    beverageCutoffs: Dict[str, str]


class FatigueRiskRequest(BaseModel):
    userId: str
    targetDate: Optional[str] = None
    assessmentPeriodDays: Optional[int] = 7
    includeWearableData: bool = True
    forceRefresh: bool = False


class FatigueRiskResult(BaseModel):
    fatigueScore: float
    riskLevel: str  # LOW, MEDIUM, HIGH, CRITICAL
    breakdown: Dict[str, float]
    recommendations: List[str]
    trendAnalysis: Dict[str, Any]
    assessmentPeriod: str
    dataQuality: str


# AI 상담봇 모델들
class ChatRequest(BaseModel):
    userId: str
    message: str
    conversationId: Optional[str] = None
    context: Optional[Dict[str, Any]] = None


class ChatResponse(BaseModel):
    response: str
    conversationId: str
    timestamp: str
    correlationId: str
    disclaimer: str


class ChatHistory(BaseModel):
    chatId: str
    userId: str
    conversationId: str
    userMessage: str
    botResponse: str
    timestamp: str
    correlationId: str


# 캐시 관련 모델들
class CacheKey(BaseModel):
    engine_type: EngineType
    user_id: str
    target_date: str
    parameters_hash: str
    
    def to_string(self) -> str:
        return f"{self.engine_type}#{self.user_id}#{self.target_date}#{self.parameters_hash}"


# 헬스 체크 모델
class HealthStatus(BaseModel):
    status: str  # healthy, degraded, unhealthy
    timestamp: str
    services: Dict[str, Any]
    version: str
    error: Optional[str] = None


# 대시보드 모델들
class JumpstartChecklist(BaseModel):
    checklistId: str
    userId: str
    itemKey: str
    title: str
    description: str
    completed: bool
    completedAt: Optional[str] = None
    createdAt: str


class DashboardResponse(BaseModel):
    sleepRecommendation: EngineResponse
    caffeineAdvice: EngineResponse
    fatigueAssessment: EngineResponse
    jumpstartProgress: Dict[str, Any]
    todaySchedule: Optional[ShiftSchedule] = None
    disclaimer: str


# 페이지네이션 모델들
class PaginationCursor(BaseModel):
    cursorDate: str
    cursorId: str


class PaginatedResponse(BaseModel):
    data: List[Any]
    nextCursor: Optional[PaginationCursor] = None
    hasMore: bool
    correlationId: str


# 에러 모델들
class ErrorResponse(BaseModel):
    error: Dict[str, Any]
    correlationId: str


class ValidationError(BaseModel):
    field: str
    message: str
    code: str


# 파일 관련 모델들
class FileMetadata(BaseModel):
    fileId: str
    uploadedBy: str
    fileType: str
    contentType: str
    fileSize: int
    s3Key: str
    status: str
    createdAt: str
    updatedAt: str


# B2B 관련 모델들
class B2BStats(BaseModel):
    orgId: str
    participantCount: int
    avgSleepHours: float
    avgFatigueScore: float
    riskDistribution: Dict[str, int]
    generatedAt: str


# 배치 작업 모델들
class BatchJobRequest(BaseModel):
    jobType: str
    targetDate: str
    parameters: Optional[Dict[str, Any]] = None


class BatchJobResult(BaseModel):
    jobId: str
    jobType: str
    status: str
    processedCount: int
    errorCount: int
    startedAt: str
    completedAt: Optional[str] = None
    errors: List[str] = []


# Daily Jumpstart Plan 모델들
class DailyJumpstartRequest(BaseModel):
    userId: str
    targetDate: Optional[str] = None  # YYYY-MM-DD
    preferredActivities: Optional[List[str]] = None
    availableTimeMinutes: Optional[int] = 60
    forceRefresh: bool = False


class DailyJumpstartResult(BaseModel):
    workSituation: Dict[str, Any]
    recommendedActivities: List[Dict[str, Any]]
    timeBlocks: List[Dict[str, Any]]
    dailyGoals: List[str]
    motivationMessage: str
    progressTracking: Dict[str, Any]
    estimatedCompletionTime: int


# Sleep Quality Tracker 모델들
class SleepQualityRequest(BaseModel):
    userId: str
    targetDate: Optional[str] = None  # YYYY-MM-DD
    assessmentPeriodDays: Optional[int] = 7
    includeWearableData: bool = True
    forceRefresh: bool = False


class SleepQualityResult(BaseModel):
    qualityScore: float  # 0-100
    qualityGrade: str    # A, B, C, D, F
    sleepMetrics: Dict[str, Any]
    sleepPatterns: Dict[str, Any]
    recommendations: List[str]
    trendAnalysis: Dict[str, Any]
    dataSource: str      # wearable, estimated, mixed


# Meal Time Checker 모델들
class MealTimeRequest(BaseModel):
    userId: str
    targetDate: Optional[str] = None  # YYYY-MM-DD
    mealType: Optional[str] = None    # breakfast, lunch, dinner, snack
    currentTime: Optional[str] = None # ISO 8601
    forceRefresh: bool = False


class MealTimeResult(BaseModel):
    currentMealWindow: Dict[str, Any]
    nextMealTime: Dict[str, Any]
    mealSchedule: List[Dict[str, Any]]
    nutritionTips: List[str]
    shiftWorkAdvice: Dict[str, Any]
    hydrationReminder: Dict[str, Any]