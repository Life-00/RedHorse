"""
배치 캐시 서비스
활성 사용자 대상 엔진 결과 사전 계산 및 캐시
"""

import logging
import asyncio
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from ..config import settings
from ..services.database_service import DatabaseService
from ..services.cache_service import CacheService
from ..engines.shift_to_sleep import ShiftToSleepEngine
from ..engines.caffeine_cutoff import CaffeineCutoffEngine
from ..engines.fatigue_risk import FatigueRiskEngine
from ..models.common import (
    ShiftToSleepRequest, CaffeineCutoffRequest, FatigueRiskRequest,
    EngineType, BatchJobResult
)
from ..utils.time_utils import TimeUtils

logger = logging.getLogger(__name__)


class BatchCacheService:
    """배치 캐시 갱신 서비스"""
    
    def __init__(
        self,
        db_service: DatabaseService,
        cache_service: CacheService,
        shift_engine: ShiftToSleepEngine,
        caffeine_engine: CaffeineCutoffEngine,
        fatigue_engine: FatigueRiskEngine
    ):
        self.db = db_service
        self.cache = cache_service
        self.shift_engine = shift_engine
        self.caffeine_engine = caffeine_engine
        self.fatigue_engine = fatigue_engine
    
    async def refresh_all_active_users(
        self, 
        target_date: Optional[str] = None,
        max_concurrent: int = 10
    ) -> BatchJobResult:
        """활성 사용자 대상 캐시 갱신"""
        
        job_id = f"batch-{datetime.now().timestamp()}"
        start_time = datetime.now()
        target_date = target_date or TimeUtils.today_kst()
        
        logger.info(f"배치 캐시 갱신 시작: job_id={job_id}, target_date={target_date}")
        
        try:
            # 활성 사용자 조회 (7일 이내 활동)
            active_users = await self._get_active_users()
            
            if not active_users:
                logger.info("활성 사용자가 없습니다")
                return BatchJobResult(
                    jobId=job_id,
                    jobType="cache_refresh",
                    status="completed",
                    processedCount=0,
                    errorCount=0,
                    startedAt=TimeUtils.format_datetime(start_time),
                    completedAt=TimeUtils.now_kst(),
                    errors=[]
                )
            
            logger.info(f"활성 사용자 {len(active_users)}명 대상 캐시 갱신 시작")
            
            # 동시 처리를 위한 세마포어
            semaphore = asyncio.Semaphore(max_concurrent)
            
            # 각 사용자별 캐시 갱신 작업 생성
            tasks = []
            for user in active_users:
                task = self._refresh_user_cache_with_semaphore(
                    semaphore, user['user_id'], target_date
                )
                tasks.append(task)
            
            # 모든 작업 실행
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # 결과 집계
            processed_count = 0
            error_count = 0
            errors = []
            
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    error_count += 1
                    errors.append(f"User {active_users[i]['user_id']}: {str(result)}")
                    logger.error(f"사용자 캐시 갱신 실패: {active_users[i]['user_id']}, {result}")
                else:
                    processed_count += 1
            
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            logger.info(f"배치 캐시 갱신 완료: processed={processed_count}, errors={error_count}, duration={duration:.2f}s")
            
            return BatchJobResult(
                jobId=job_id,
                jobType="cache_refresh",
                status="completed" if error_count == 0 else "partial_failure",
                processedCount=processed_count,
                errorCount=error_count,
                startedAt=TimeUtils.format_datetime(start_time),
                completedAt=TimeUtils.format_datetime(end_time),
                errors=errors[:10]  # 최대 10개 에러만 기록
            )
            
        except Exception as e:
            logger.error(f"배치 캐시 갱신 실패: {e}")
            return BatchJobResult(
                jobId=job_id,
                jobType="cache_refresh",
                status="failed",
                processedCount=0,
                errorCount=1,
                startedAt=TimeUtils.format_datetime(start_time),
                completedAt=TimeUtils.now_kst(),
                errors=[str(e)]
            )
    
    async def _refresh_user_cache_with_semaphore(
        self, 
        semaphore: asyncio.Semaphore, 
        user_id: str, 
        target_date: str
    ):
        """세마포어를 사용한 사용자 캐시 갱신"""
        async with semaphore:
            return await self._refresh_user_cache(user_id, target_date)
    
    async def _refresh_user_cache(self, user_id: str, target_date: str):
        """개별 사용자 캐시 갱신"""
        correlation_id = f"batch-{user_id[:8]}-{target_date}"
        
        try:
            # 사용자 프로필 및 근무표 확인
            user_profile = await self.db.get_user_profile(user_id)
            if not user_profile:
                raise Exception("사용자 프로필 없음")
            
            today_schedule = await self.db.get_schedule_by_date(user_id, target_date)
            if not today_schedule or today_schedule.shiftType == "OFF":
                logger.debug(f"사용자 {user_id} 오늘 근무 없음, 캐시 갱신 스킵")
                return
            
            # 3대 엔진 병렬 실행
            tasks = [
                self._refresh_shift_to_sleep_cache(user_id, target_date, correlation_id),
                self._refresh_caffeine_cutoff_cache(user_id, target_date, correlation_id),
                self._refresh_fatigue_risk_cache(user_id, target_date, correlation_id)
            ]
            
            await asyncio.gather(*tasks, return_exceptions=True)
            
        except Exception as e:
            logger.error(f"사용자 {user_id} 캐시 갱신 실패: {e}")
            raise
    
    async def _refresh_shift_to_sleep_cache(
        self, 
        user_id: str, 
        target_date: str, 
        correlation_id: str
    ):
        """Shift-to-Sleep 캐시 갱신"""
        try:
            request = ShiftToSleepRequest(
                userId=user_id,
                targetDate=target_date,
                forceRefresh=True  # 배치에서는 강제 갱신
            )
            
            result = await self.shift_engine.calculate(request, correlation_id)
            logger.debug(f"Shift-to-Sleep 캐시 갱신 완료: {user_id}")
            
        except Exception as e:
            logger.error(f"Shift-to-Sleep 캐시 갱신 실패: {user_id}, {e}")
            raise
    
    async def _refresh_caffeine_cutoff_cache(
        self, 
        user_id: str, 
        target_date: str, 
        correlation_id: str
    ):
        """Caffeine Cutoff 캐시 갱신"""
        try:
            request = CaffeineCutoffRequest(
                userId=user_id,
                targetDate=target_date,
                forceRefresh=True
            )
            
            result = await self.caffeine_engine.calculate(request, correlation_id)
            logger.debug(f"Caffeine Cutoff 캐시 갱신 완료: {user_id}")
            
        except Exception as e:
            logger.error(f"Caffeine Cutoff 캐시 갱신 실패: {user_id}, {e}")
            raise
    
    async def _refresh_fatigue_risk_cache(
        self, 
        user_id: str, 
        target_date: str, 
        correlation_id: str
    ):
        """Fatigue Risk 캐시 갱신"""
        try:
            request = FatigueRiskRequest(
                userId=user_id,
                targetDate=target_date,
                forceRefresh=True
            )
            
            result = await self.fatigue_engine.calculate(request, correlation_id)
            logger.debug(f"Fatigue Risk 캐시 갱신 완료: {user_id}")
            
        except Exception as e:
            logger.error(f"Fatigue Risk 캐시 갱신 실패: {user_id}, {e}")
            raise
    
    async def _get_active_users(self) -> List[Dict[str, Any]]:
        """활성 사용자 목록 조회"""
        if not self.db.pool:
            return []
        
        try:
            async with self.db.pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT user_id, shift_type, commute_min, wearable_connected
                    FROM users 
                    WHERE last_active_at >= NOW() - INTERVAL '7 days'
                    ORDER BY last_active_at DESC
                    """
                )
                
                return [dict(row) for row in rows]
                
        except Exception as e:
            logger.error(f"활성 사용자 조회 실패: {e}")
            return []
    
    async def cleanup_expired_cache(self) -> int:
        """만료된 캐시 정리"""
        try:
            if not self.db.pool:
                return 0
            
            async with self.db.pool.acquire() as conn:
                result = await conn.fetchval(
                    "SELECT cleanup_expired_cache()"
                )
                
                logger.info(f"만료된 캐시 정리 완료: {result}개 삭제")
                return result or 0
                
        except Exception as e:
            logger.error(f"캐시 정리 실패: {e}")
            return 0
    
    async def get_cache_statistics(self) -> Dict[str, Any]:
        """캐시 통계 조회"""
        try:
            if not self.db.pool:
                return {}
            
            async with self.db.pool.acquire() as conn:
                # 엔진별 캐시 통계
                engine_stats = await conn.fetch(
                    """
                    SELECT 
                        engine_type,
                        COUNT(*) as total_count,
                        COUNT(CASE WHEN expires_at > NOW() THEN 1 END) as valid_count,
                        AVG(EXTRACT(EPOCH FROM (expires_at - generated_at))/3600) as avg_ttl_hours
                    FROM engine_cache 
                    WHERE generated_at >= NOW() - INTERVAL '24 hours'
                    GROUP BY engine_type
                    """
                )
                
                # 전체 통계
                total_stats = await conn.fetchrow(
                    """
                    SELECT 
                        COUNT(*) as total_cache_entries,
                        COUNT(CASE WHEN expires_at > NOW() THEN 1 END) as valid_entries,
                        COUNT(DISTINCT user_id) as cached_users,
                        AVG(EXTRACT(EPOCH FROM (NOW() - generated_at))/3600) as avg_age_hours
                    FROM engine_cache
                    """
                )
                
                return {
                    "engineStats": [dict(row) for row in engine_stats],
                    "totalStats": dict(total_stats) if total_stats else {},
                    "generatedAt": TimeUtils.now_kst()
                }
                
        except Exception as e:
            logger.error(f"캐시 통계 조회 실패: {e}")
            return {"error": str(e)}
    
    async def invalidate_user_cache_by_date(
        self, 
        user_id: str, 
        from_date: str
    ) -> bool:
        """특정 날짜 이후 사용자 캐시 무효화"""
        try:
            if not self.db.pool:
                return False
            
            async with self.db.pool.acquire() as conn:
                result = await conn.execute(
                    """
                    DELETE FROM engine_cache 
                    WHERE user_id = $1 AND target_date >= $2
                    """,
                    user_id, from_date
                )
                
                # Redis 캐시도 무효화
                await self.cache.invalidate_user_cache(user_id, from_date)
                
                logger.info(f"사용자 캐시 무효화 완료: user_id={user_id}, from_date={from_date}")
                return True
                
        except Exception as e:
            logger.error(f"사용자 캐시 무효화 실패: {e}")
            return False