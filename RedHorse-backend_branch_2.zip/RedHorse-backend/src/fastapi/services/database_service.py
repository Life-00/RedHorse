"""
데이터베이스 서비스 (PostgreSQL)
"""

import logging
from typing import Optional, List, Dict, Any, Tuple
import asyncpg
from datetime import datetime, timedelta
from ..config import settings
from ..models.common import UserProfile, ShiftSchedule, ChatHistory

logger = logging.getLogger(__name__)


class DatabaseService:
    """PostgreSQL 데이터베이스 서비스"""
    
    def __init__(self):
        self.pool: Optional[asyncpg.Pool] = None
        self.connected = False
    
    async def initialize(self):
        """데이터베이스 연결 풀 초기화"""
        try:
            self.pool = await asyncpg.create_pool(
                settings.DATABASE_URL,
                min_size=5,
                max_size=settings.DATABASE_POOL_SIZE,
                max_queries=50000,
                max_inactive_connection_lifetime=300,
                command_timeout=30
            )
            
            # 연결 테스트
            async with self.pool.acquire() as conn:
                await conn.fetchval("SELECT 1")
            
            self.connected = True
            logger.info("데이터베이스 연결 풀 생성 성공")
            
        except Exception as e:
            logger.error(f"데이터베이스 연결 실패: {e}")
            self.connected = False
            raise
    
    async def close(self):
        """데이터베이스 연결 풀 종료"""
        if self.pool:
            await self.pool.close()
            self.connected = False
            logger.info("데이터베이스 연결 풀 종료")
    
    async def get_user_profile(self, user_id: str) -> Optional[UserProfile]:
        """사용자 프로필 조회"""
        if not self.pool:
            return None
        
        try:
            async with self.pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    SELECT user_id, cognito_sub, shift_type, commute_min, 
                           wearable_connected, org_id, last_active_at, 
                           created_at, updated_at
                    FROM users 
                    WHERE user_id = $1
                    """,
                    user_id
                )
                
                if row:
                    return UserProfile(
                        userId=str(row['user_id']),
                        cognitoSub=row['cognito_sub'],
                        shiftType=row['shift_type'],
                        commuteMin=row['commute_min'],
                        wearableConnected=row['wearable_connected'],
                        orgId=row['org_id'],
                        lastActiveAt=row['last_active_at'].isoformat() + "+09:00",
                        createdAt=row['created_at'].isoformat() + "+09:00",
                        updatedAt=row['updated_at'].isoformat() + "+09:00"
                    )
                
                return None
                
        except Exception as e:
            logger.error(f"사용자 프로필 조회 실패: {e}")
            return None
    
    async def get_schedule_by_date(self, user_id: str, date: str) -> Optional[ShiftSchedule]:
        """특정 날짜 근무표 조회"""
        if not self.pool:
            return None
        
        try:
            async with self.pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    SELECT schedule_id, user_id, date, shift_type, start_at, end_at,
                           commute_min, note, created_at, updated_at
                    FROM shift_schedules 
                    WHERE user_id = $1 AND date = $2
                    """,
                    user_id, date
                )
                
                if row:
                    return ShiftSchedule(
                        scheduleId=str(row['schedule_id']),
                        userId=str(row['user_id']),
                        date=row['date'].isoformat(),
                        shiftType=row['shift_type'],
                        startAt=row['start_at'].isoformat() + "+09:00" if row['start_at'] else None,
                        endAt=row['end_at'].isoformat() + "+09:00" if row['end_at'] else None,
                        commuteMin=row['commute_min'],
                        note=row['note'],
                        createdAt=row['created_at'].isoformat() + "+09:00",
                        updatedAt=row['updated_at'].isoformat() + "+09:00"
                    )
                
                return None
                
        except Exception as e:
            logger.error(f"근무표 조회 실패: {e}")
            return None
    
    async def get_schedules_in_range(
        self, 
        user_id: str, 
        start_date: str, 
        end_date: str
    ) -> List[ShiftSchedule]:
        """날짜 범위 근무표 조회"""
        if not self.pool:
            return []
        
        try:
            async with self.pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT schedule_id, user_id, date, shift_type, start_at, end_at,
                           commute_min, note, created_at, updated_at
                    FROM shift_schedules 
                    WHERE user_id = $1 AND date BETWEEN $2 AND $3
                    ORDER BY date ASC
                    """,
                    user_id, start_date, end_date
                )
                
                schedules = []
                for row in rows:
                    schedules.append(ShiftSchedule(
                        scheduleId=str(row['schedule_id']),
                        userId=str(row['user_id']),
                        date=row['date'].isoformat(),
                        shiftType=row['shift_type'],
                        startAt=row['start_at'].isoformat() + "+09:00" if row['start_at'] else None,
                        endAt=row['end_at'].isoformat() + "+09:00" if row['end_at'] else None,
                        commuteMin=row['commute_min'],
                        note=row['note'],
                        createdAt=row['created_at'].isoformat() + "+09:00",
                        updatedAt=row['updated_at'].isoformat() + "+09:00"
                    ))
                
                return schedules
                
        except Exception as e:
            logger.error(f"날짜 범위 근무표 조회 실패: {e}")
            return []
    
    async def get_upcoming_schedules(self, user_id: str, days: int) -> List[ShiftSchedule]:
        """향후 근무표 조회"""
        today = datetime.now().date()
        end_date = today + timedelta(days=days)
        
        return await self.get_schedules_in_range(
            user_id, 
            today.isoformat(), 
            end_date.isoformat()
        )
    
    async def get_recent_schedules(self, user_id: str, days: int) -> List[Dict[str, Any]]:
        """최근 근무표 조회 (간단한 형태)"""
        if not self.pool:
            return []
        
        try:
            start_date = datetime.now().date() - timedelta(days=days)
            
            async with self.pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT date, shift_type, start_at, end_at
                    FROM shift_schedules 
                    WHERE user_id = $1 AND date >= $2
                    ORDER BY date DESC
                    """,
                    user_id, start_date.isoformat()
                )
                
                return [dict(row) for row in rows]
                
        except Exception as e:
            logger.error(f"최근 근무표 조회 실패: {e}")
            return []
    
    async def get_recent_engine_results(self, user_id: str, days: int) -> List[Dict[str, Any]]:
        """최근 엔진 결과 조회"""
        if not self.pool:
            return []
        
        try:
            start_date = datetime.now().date() - timedelta(days=days)
            
            async with self.pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT engine_type, target_date, result, generated_at
                    FROM engine_cache 
                    WHERE user_id = $1 AND target_date >= $2 AND expires_at > NOW()
                    ORDER BY generated_at DESC
                    """,
                    user_id, start_date.isoformat()
                )
                
                return [dict(row) for row in rows]
                
        except Exception as e:
            logger.error(f"최근 엔진 결과 조회 실패: {e}")
            return []
    
    async def get_sleep_data(
        self, 
        user_id: str, 
        start_date: str, 
        end_date: str
    ) -> Optional[Dict[str, Any]]:
        """수면 데이터 조회 (웨어러블)"""
        if not self.pool:
            return None
        
        try:
            async with self.pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT sleep_start, sleep_end, sleep_duration_hours, sleep_quality
                    FROM wearable_sleep_data 
                    WHERE user_id = $1 AND sleep_date BETWEEN $2 AND $3
                    """,
                    user_id, start_date, end_date
                )
                
                if rows:
                    total_hours = sum(row['sleep_duration_hours'] for row in rows if row['sleep_duration_hours'])
                    avg_hours = total_hours / len(rows) if rows else 0
                    
                    return {
                        "averageSleepHours": round(avg_hours, 1),
                        "totalRecords": len(rows),
                        "dataQuality": "good" if len(rows) >= 5 else "limited"
                    }
                
                return None
                
        except Exception as e:
            logger.error(f"수면 데이터 조회 실패: {e}")
            return None
    
    async def save_chat_history(
        self,
        user_id: str,
        conversation_id: str,
        user_message: str,
        bot_response: str,
        correlation_id: str
    ) -> ChatHistory:
        """채팅 기록 저장"""
        if not self.pool:
            raise Exception("데이터베이스 연결 없음")
        
        try:
            async with self.pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    INSERT INTO chat_history (user_id, conversation_id, user_message, bot_response, correlation_id)
                    VALUES ($1, $2, $3, $4, $5)
                    RETURNING chat_id, user_id, conversation_id, user_message, bot_response, 
                              created_at, correlation_id
                    """,
                    user_id, conversation_id, user_message, bot_response, correlation_id
                )
                
                return ChatHistory(
                    chatId=str(row['chat_id']),
                    userId=str(row['user_id']),
                    conversationId=row['conversation_id'],
                    userMessage=row['user_message'],
                    botResponse=row['bot_response'],
                    timestamp=row['created_at'].isoformat() + "+09:00",
                    correlationId=row['correlation_id']
                )
                
        except Exception as e:
            logger.error(f"채팅 기록 저장 실패: {e}")
            raise
    
    async def get_chat_history(
        self, 
        user_id: str, 
        conversation_id: str, 
        limit: int = 10
    ) -> List[ChatHistory]:
        """채팅 기록 조회"""
        if not self.pool:
            return []
        
        try:
            async with self.pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT chat_id, user_id, conversation_id, user_message, bot_response, 
                           created_at, correlation_id
                    FROM chat_history 
                    WHERE user_id = $1 AND conversation_id = $2
                    ORDER BY created_at DESC
                    LIMIT $3
                    """,
                    user_id, conversation_id, limit
                )
                
                history = []
                for row in rows:
                    history.append(ChatHistory(
                        chatId=str(row['chat_id']),
                        userId=str(row['user_id']),
                        conversationId=row['conversation_id'],
                        userMessage=row['user_message'],
                        botResponse=row['bot_response'],
                        timestamp=row['created_at'].isoformat() + "+09:00",
                        correlationId=row['correlation_id']
                    ))
                
                return list(reversed(history))  # 시간순 정렬
                
        except Exception as e:
            logger.error(f"채팅 기록 조회 실패: {e}")
            return []
    
    async def get_user_chat_history(
        self, 
        user_id: str, 
        limit: int = 20, 
        offset: int = 0
    ) -> List[ChatHistory]:
        """사용자 전체 채팅 기록 조회"""
        if not self.pool:
            return []
        
        try:
            async with self.pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT chat_id, user_id, conversation_id, user_message, bot_response, 
                           created_at, correlation_id
                    FROM chat_history 
                    WHERE user_id = $1
                    ORDER BY created_at DESC
                    LIMIT $2 OFFSET $3
                    """,
                    user_id, limit, offset
                )
                
                history = []
                for row in rows:
                    history.append(ChatHistory(
                        chatId=str(row['chat_id']),
                        userId=str(row['user_id']),
                        conversationId=row['conversation_id'],
                        userMessage=row['user_message'],
                        botResponse=row['bot_response'],
                        timestamp=row['created_at'].isoformat() + "+09:00",
                        correlationId=row['correlation_id']
                    ))
                
                return history
                
        except Exception as e:
            logger.error(f"사용자 채팅 기록 조회 실패: {e}")
            return []
    
    async def clear_user_chat_history(self, user_id: str) -> bool:
        """사용자 채팅 기록 삭제"""
        if not self.pool:
            return False
        
        try:
            async with self.pool.acquire() as conn:
                await conn.execute(
                    "DELETE FROM chat_history WHERE user_id = $1",
                    user_id
                )
                return True
                
        except Exception as e:
            logger.error(f"채팅 기록 삭제 실패: {e}")
            return False
    
    async def get_engine_statistics(self, user_id: str) -> Dict[str, Any]:
        """엔진 통계 조회"""
        if not self.pool:
            return {}
        
        try:
            async with self.pool.acquire() as conn:
                # 최근 30일 엔진 사용 통계
                stats = await conn.fetchrow(
                    """
                    SELECT 
                        COUNT(*) as total_calculations,
                        COUNT(DISTINCT engine_type) as engines_used,
                        AVG(CASE WHEN result IS NOT NULL THEN 1 ELSE 0 END) as success_rate
                    FROM engine_cache 
                    WHERE user_id = $1 AND generated_at >= NOW() - INTERVAL '30 days'
                    """,
                    user_id
                )
                
                return {
                    "totalCalculations": stats['total_calculations'] or 0,
                    "enginesUsed": stats['engines_used'] or 0,
                    "successRate": round(float(stats['success_rate'] or 0) * 100, 1)
                }
                
        except Exception as e:
            logger.error(f"엔진 통계 조회 실패: {e}")
            return {}
    
    async def get_performance_metrics(self, days: int) -> Dict[str, Any]:
        """성능 메트릭 조회"""
        if not self.pool:
            return {}
        
        try:
            async with self.pool.acquire() as conn:
                # 시스템 전체 성능 메트릭
                metrics = await conn.fetchrow(
                    """
                    SELECT 
                        COUNT(*) as total_requests,
                        COUNT(DISTINCT user_id) as active_users,
                        AVG(CASE WHEN result IS NOT NULL THEN 1 ELSE 0 END) as avg_success_rate
                    FROM engine_cache 
                    WHERE generated_at >= NOW() - INTERVAL '%s days'
                    """,
                    days
                )
                
                return {
                    "totalRequests": metrics['total_requests'] or 0,
                    "activeUsers": metrics['active_users'] or 0,
                    "avgSuccessRate": round(float(metrics['avg_success_rate'] or 0) * 100, 1),
                    "period": f"last_{days}_days"
                }
                
        except Exception as e:
            logger.error(f"성능 메트릭 조회 실패: {e}")
            return {}
    
    async def health_check(self) -> Dict[str, Any]:
        """데이터베이스 헬스 체크"""
        try:
            if not self.pool:
                return {"healthy": False, "error": "No connection pool"}
            
            async with self.pool.acquire() as conn:
                start_time = time.time()
                await conn.fetchval("SELECT 1")
                response_time = (time.time() - start_time) * 1000
                
                return {
                    "healthy": True,
                    "response_time_ms": round(response_time, 2),
                    "pool_size": self.pool.get_size(),
                    "pool_max_size": self.pool.get_max_size()
                }
                
        except Exception as e:
            logger.error(f"데이터베이스 헬스 체크 실패: {e}")
            return {"healthy": False, "error": str(e)}
    
    # 새로운 엔진들을 위한 메서드들
    
    async def get_sleep_data(
        self, 
        user_id: str, 
        start_date: str, 
        end_date: str
    ) -> Optional[Dict[str, Any]]:
        """수면 데이터 조회 (웨어러블)"""
        if not self.pool:
            return None
        
        try:
            async with self.pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT sleep_date, bedtime, wake_time, duration_hours, 
                           sleep_efficiency, deep_sleep_minutes, rem_sleep_minutes,
                           light_sleep_minutes, awake_minutes, sleep_score, data_source
                    FROM sleep_data 
                    WHERE user_id = $1 AND sleep_date BETWEEN $2 AND $3
                    ORDER BY sleep_date DESC
                    """,
                    user_id, start_date, end_date
                )
                
                if not rows:
                    return None
                
                sleep_sessions = []
                total_duration = 0
                
                for row in rows:
                    session = {
                        "sleepDate": row['sleep_date'].isoformat(),
                        "bedtime": row['bedtime'].isoformat() + "+09:00" if row['bedtime'] else None,
                        "wakeTime": row['wake_time'].isoformat() + "+09:00" if row['wake_time'] else None,
                        "durationHours": float(row['duration_hours']) if row['duration_hours'] else 0,
                        "sleepEfficiency": row['sleep_efficiency'],
                        "deepSleepMinutes": row['deep_sleep_minutes'],
                        "remSleepMinutes": row['rem_sleep_minutes'],
                        "lightSleepMinutes": row['light_sleep_minutes'],
                        "awakeMinutes": row['awake_minutes'],
                        "sleepScore": row['sleep_score'],
                        "dataSource": row['data_source']
                    }
                    sleep_sessions.append(session)
                    if row['duration_hours']:
                        total_duration += float(row['duration_hours'])
                
                return {
                    "sleepSessions": sleep_sessions,
                    "averageSleepHours": round(total_duration / len(rows), 1) if rows else 0,
                    "totalSessions": len(rows)
                }
                
        except Exception as e:
            logger.error(f"수면 데이터 조회 실패: {e}")
            return None
    
    async def save_sleep_data(
        self, 
        user_id: str, 
        sleep_date: str,
        sleep_data: Dict[str, Any]
    ) -> bool:
        """수면 데이터 저장"""
        if not self.pool:
            return False
        
        try:
            async with self.pool.acquire() as conn:
                await conn.execute(
                    """
                    INSERT INTO sleep_data (
                        user_id, sleep_date, bedtime, wake_time, duration_hours,
                        sleep_efficiency, deep_sleep_minutes, rem_sleep_minutes,
                        light_sleep_minutes, awake_minutes, sleep_score, data_source
                    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                    ON CONFLICT (user_id, sleep_date) 
                    DO UPDATE SET
                        bedtime = EXCLUDED.bedtime,
                        wake_time = EXCLUDED.wake_time,
                        duration_hours = EXCLUDED.duration_hours,
                        sleep_efficiency = EXCLUDED.sleep_efficiency,
                        deep_sleep_minutes = EXCLUDED.deep_sleep_minutes,
                        rem_sleep_minutes = EXCLUDED.rem_sleep_minutes,
                        light_sleep_minutes = EXCLUDED.light_sleep_minutes,
                        awake_minutes = EXCLUDED.awake_minutes,
                        sleep_score = EXCLUDED.sleep_score,
                        data_source = EXCLUDED.data_source,
                        updated_at = NOW()
                    """,
                    user_id, sleep_date,
                    sleep_data.get('bedtime'), sleep_data.get('wake_time'),
                    sleep_data.get('duration_hours'), sleep_data.get('sleep_efficiency'),
                    sleep_data.get('deep_sleep_minutes'), sleep_data.get('rem_sleep_minutes'),
                    sleep_data.get('light_sleep_minutes'), sleep_data.get('awake_minutes'),
                    sleep_data.get('sleep_score'), sleep_data.get('data_source', 'wearable')
                )
                return True
                
        except Exception as e:
            logger.error(f"수면 데이터 저장 실패: {e}")
            return False
    
    async def get_meal_records(
        self, 
        user_id: str, 
        start_date: str, 
        end_date: str
    ) -> List[Dict[str, Any]]:
        """식사 기록 조회"""
        if not self.pool:
            return []
        
        try:
            async with self.pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT meal_id, meal_date, meal_type, meal_time, 
                           duration_minutes, satisfaction_score, notes
                    FROM meal_records 
                    WHERE user_id = $1 AND meal_date BETWEEN $2 AND $3
                    ORDER BY meal_time DESC
                    """,
                    user_id, start_date, end_date
                )
                
                return [dict(row) for row in rows]
                
        except Exception as e:
            logger.error(f"식사 기록 조회 실패: {e}")
            return []
    
    async def save_meal_record(
        self, 
        user_id: str, 
        meal_data: Dict[str, Any]
    ) -> bool:
        """식사 기록 저장"""
        if not self.pool:
            return False
        
        try:
            async with self.pool.acquire() as conn:
                await conn.execute(
                    """
                    INSERT INTO meal_records (
                        user_id, meal_date, meal_type, meal_time,
                        duration_minutes, satisfaction_score, notes
                    ) VALUES ($1, $2, $3, $4, $5, $6, $7)
                    """,
                    user_id, meal_data['meal_date'], meal_data['meal_type'],
                    meal_data['meal_time'], meal_data.get('duration_minutes'),
                    meal_data.get('satisfaction_score'), meal_data.get('notes')
                )
                return True
                
        except Exception as e:
            logger.error(f"식사 기록 저장 실패: {e}")
            return False
    
    async def get_jumpstart_checklist_progress(self, user_id: str) -> Dict[str, Any]:
        """점프스타트 체크리스트 진행률 조회"""
        if not self.pool:
            return {"completed": 0, "total": 0, "items": []}
        
        try:
            async with self.pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT item_key, title, description, completed, completed_at
                    FROM jumpstart_checklists 
                    WHERE user_id = $1
                    ORDER BY created_at ASC
                    """,
                    user_id
                )
                
                items = []
                completed_count = 0
                
                for row in rows:
                    item = {
                        "itemKey": row['item_key'],
                        "title": row['title'],
                        "description": row['description'],
                        "completed": row['completed'],
                        "completedAt": row['completed_at'].isoformat() + "+09:00" if row['completed_at'] else None
                    }
                    items.append(item)
                    if row['completed']:
                        completed_count += 1
                
                return {
                    "completed": completed_count,
                    "total": len(items),
                    "items": items,
                    "completionRate": round((completed_count / len(items) * 100), 1) if items else 0
                }
                
        except Exception as e:
            logger.error(f"체크리스트 진행률 조회 실패: {e}")
            return {"completed": 0, "total": 0, "items": []}
    
    async def update_checklist_item(
        self, 
        user_id: str, 
        item_key: str, 
        completed: bool
    ) -> bool:
        """체크리스트 항목 업데이트"""
        if not self.pool:
            return False
        
        try:
            async with self.pool.acquire() as conn:
                await conn.execute(
                    """
                    UPDATE jumpstart_checklists 
                    SET completed = $3, completed_at = CASE WHEN $3 THEN NOW() ELSE NULL END
                    WHERE user_id = $1 AND item_key = $2
                    """,
                    user_id, item_key, completed
                )
                return True
                
        except Exception as e:
            logger.error(f"체크리스트 항목 업데이트 실패: {e}")
            return False