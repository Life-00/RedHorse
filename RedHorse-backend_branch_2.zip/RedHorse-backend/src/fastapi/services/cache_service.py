"""
캐시 서비스 (ElastiCache Redis)
"""

import json
import logging
import time
from typing import Optional, Dict, Any
import aioredis
from ..config import settings
from ..models.common import CacheKey

logger = logging.getLogger(__name__)


class CacheService:
    """Redis 기반 캐시 서비스"""
    
    def __init__(self):
        self.redis: Optional[aioredis.Redis] = None
        self.connected = False
    
    async def initialize(self):
        """Redis 연결 초기화"""
        try:
            self.redis = aioredis.from_url(
                settings.REDIS_URL,
                encoding="utf-8",
                decode_responses=True,
                socket_timeout=5,
                socket_connect_timeout=5,
                retry_on_timeout=True,
                max_connections=20
            )
            
            # 연결 테스트
            await self.redis.ping()
            self.connected = True
            logger.info("Redis 연결 성공")
            
        except Exception as e:
            logger.error(f"Redis 연결 실패: {e}")
            self.connected = False
            raise
    
    async def close(self):
        """Redis 연결 종료"""
        if self.redis:
            await self.redis.close()
            self.connected = False
            logger.info("Redis 연결 종료")
    
    async def get(self, cache_key: CacheKey) -> Optional[Dict[str, Any]]:
        """캐시에서 데이터 조회"""
        if not self.connected or not self.redis:
            return None
        
        try:
            key = cache_key.to_string()
            cached_data = await self.redis.get(key)
            
            if cached_data:
                return json.loads(cached_data)
            
            return None
            
        except Exception as e:
            logger.error(f"캐시 조회 실패: {e}")
            return None
    
    async def set(
        self, 
        cache_key: CacheKey, 
        data: Dict[str, Any], 
        ttl_seconds: Optional[int] = None
    ) -> bool:
        """캐시에 데이터 저장"""
        if not self.connected or not self.redis:
            return False
        
        try:
            key = cache_key.to_string()
            serialized_data = json.dumps(data, ensure_ascii=False)
            ttl = ttl_seconds or settings.CACHE_TTL_SECONDS
            
            await self.redis.setex(key, ttl, serialized_data)
            return True
            
        except Exception as e:
            logger.error(f"캐시 저장 실패: {e}")
            return False
    
    async def delete(self, cache_key: CacheKey) -> bool:
        """캐시에서 데이터 삭제"""
        if not self.connected or not self.redis:
            return False
        
        try:
            key = cache_key.to_string()
            result = await self.redis.delete(key)
            return result > 0
            
        except Exception as e:
            logger.error(f"캐시 삭제 실패: {e}")
            return False
    
    async def delete_pattern(self, pattern: str) -> int:
        """패턴에 맞는 캐시 키들 삭제"""
        if not self.connected or not self.redis:
            return 0
        
        try:
            keys = await self.redis.keys(pattern)
            if keys:
                deleted_count = await self.redis.delete(*keys)
                return deleted_count
            return 0
            
        except Exception as e:
            logger.error(f"패턴 캐시 삭제 실패: {e}")
            return 0
    
    async def invalidate_user_cache(self, user_id: str, date_from: Optional[str] = None):
        """사용자 캐시 무효화"""
        try:
            if date_from:
                # 특정 날짜 이후 캐시만 삭제
                pattern = f"*#{user_id}#{date_from}*"
            else:
                # 사용자의 모든 캐시 삭제
                pattern = f"*#{user_id}#*"
            
            deleted_count = await self.delete_pattern(pattern)
            logger.info(f"사용자 캐시 무효화 완료: user_id={user_id}, deleted={deleted_count}")
            
        except Exception as e:
            logger.error(f"사용자 캐시 무효화 실패: {e}")
    
    async def get_cache_stats(self) -> Dict[str, Any]:
        """캐시 통계 조회"""
        if not self.connected or not self.redis:
            return {"connected": False}
        
        try:
            info = await self.redis.info()
            return {
                "connected": True,
                "used_memory": info.get("used_memory_human", "N/A"),
                "connected_clients": info.get("connected_clients", 0),
                "total_commands_processed": info.get("total_commands_processed", 0),
                "keyspace_hits": info.get("keyspace_hits", 0),
                "keyspace_misses": info.get("keyspace_misses", 0),
                "hit_rate": self._calculate_hit_rate(
                    info.get("keyspace_hits", 0),
                    info.get("keyspace_misses", 0)
                )
            }
            
        except Exception as e:
            logger.error(f"캐시 통계 조회 실패: {e}")
            return {"connected": False, "error": str(e)}
    
    def _calculate_hit_rate(self, hits: int, misses: int) -> float:
        """캐시 히트율 계산"""
        total = hits + misses
        if total == 0:
            return 0.0
        return round((hits / total) * 100, 2)
    
    async def health_check(self) -> Dict[str, Any]:
        """헬스 체크"""
        try:
            if not self.connected or not self.redis:
                return {"healthy": False, "error": "Not connected"}
            
            # Ping 테스트
            start_time = time.time()
            await self.redis.ping()
            response_time = (time.time() - start_time) * 1000
            
            return {
                "healthy": True,
                "response_time_ms": round(response_time, 2),
                "connected": self.connected
            }
            
        except Exception as e:
            logger.error(f"캐시 헬스 체크 실패: {e}")
            return {"healthy": False, "error": str(e)}
    
    async def set_simple(self, key: str, value: str, ttl_seconds: Optional[int] = None) -> bool:
        """간단한 키-값 저장"""
        if not self.connected or not self.redis:
            return False
        
        try:
            ttl = ttl_seconds or settings.CACHE_TTL_SECONDS
            await self.redis.setex(key, ttl, value)
            return True
            
        except Exception as e:
            logger.error(f"간단 캐시 저장 실패: {e}")
            return False
    
    async def get_simple(self, key: str) -> Optional[str]:
        """간단한 키-값 조회"""
        if not self.connected or not self.redis:
            return None
        
        try:
            return await self.redis.get(key)
            
        except Exception as e:
            logger.error(f"간단 캐시 조회 실패: {e}")
            return None