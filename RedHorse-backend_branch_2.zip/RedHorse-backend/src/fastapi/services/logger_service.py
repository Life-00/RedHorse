"""
로깅 서비스
"""

import logging
import json
from datetime import datetime
from typing import Dict, Any, Optional
from ..config import settings
from ..models.common import EngineType

logger = logging.getLogger(__name__)


class LoggerService:
    """구조화된 로깅 서비스"""
    
    def __init__(self):
        self.service_name = "fastapi-engine-service"
    
    async def log_request(
        self,
        correlation_id: str,
        method: str,
        path: str,
        query_params: Dict[str, Any],
        user_agent: Optional[str] = None
    ):
        """API 요청 로깅"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": "INFO",
            "correlationId": correlation_id,
            "service": self.service_name,
            "message": f"{method} {path}",
            "request": {
                "method": method,
                "path": path,
                "queryParams": query_params,
                "userAgent": user_agent
            }
        }
        
        logger.info(json.dumps(log_entry, ensure_ascii=False))
    
    async def log_response(
        self,
        correlation_id: str,
        status_code: int,
        duration_ms: float
    ):
        """API 응답 로깅"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": "INFO",
            "correlationId": correlation_id,
            "service": self.service_name,
            "message": f"Response {status_code}",
            "response": {
                "statusCode": status_code,
                "durationMs": round(duration_ms, 2)
            }
        }
        
        logger.info(json.dumps(log_entry, ensure_ascii=False))
    
    async def log_error(
        self,
        correlation_id: str,
        error: Exception,
        duration_ms: float
    ):
        """에러 로깅"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": "ERROR",
            "correlationId": correlation_id,
            "service": self.service_name,
            "message": f"Request failed: {str(error)}",
            "error": {
                "name": error.__class__.__name__,
                "message": str(error),
                "stack": getattr(error, '__traceback__', None)
            },
            "durationMs": round(duration_ms, 2)
        }
        
        logger.error(json.dumps(log_entry, ensure_ascii=False))
    
    async def log_engine_request(
        self,
        correlation_id: str,
        engine_type: EngineType,
        user_id: str,
        success: bool
    ):
        """엔진 요청 로깅"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": "INFO",
            "correlationId": correlation_id,
            "service": self.service_name,
            "message": f"Engine calculation: {engine_type}",
            "engine": {
                "type": engine_type,
                "userId": user_id[:8] + "***",  # 개인정보 마스킹
                "success": success
            }
        }
        
        logger.info(json.dumps(log_entry, ensure_ascii=False))
    
    async def log_engine_error(
        self,
        correlation_id: str,
        engine_type: EngineType,
        error: Exception
    ):
        """엔진 에러 로깅"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": "ERROR",
            "correlationId": correlation_id,
            "service": self.service_name,
            "message": f"Engine error: {engine_type}",
            "engine": {
                "type": engine_type,
                "error": {
                    "name": error.__class__.__name__,
                    "message": str(error)
                }
            }
        }
        
        logger.error(json.dumps(log_entry, ensure_ascii=False))
    
    async def log_chat_interaction(
        self,
        correlation_id: str,
        user_id: str,
        message_length: int,
        response_length: int,
        success: bool
    ):
        """채팅 상호작용 로깅"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": "INFO",
            "correlationId": correlation_id,
            "service": self.service_name,
            "message": "AI chat interaction",
            "chat": {
                "userId": user_id[:8] + "***",  # 개인정보 마스킹
                "messageLength": message_length,
                "responseLength": response_length,
                "success": success
            }
        }
        
        logger.info(json.dumps(log_entry, ensure_ascii=False))
    
    async def log_chat_error(
        self,
        correlation_id: str,
        user_id: str,
        error: Exception
    ):
        """채팅 에러 로깅"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": "ERROR",
            "correlationId": correlation_id,
            "service": self.service_name,
            "message": "AI chat error",
            "chat": {
                "userId": user_id[:8] + "***",  # 개인정보 마스킹
                "error": {
                    "name": error.__class__.__name__,
                    "message": str(error)
                }
            }
        }
        
        logger.error(json.dumps(log_entry, ensure_ascii=False))