"""
인증 서비스
"""

import logging
import jwt
from typing import Optional
from fastapi import HTTPException
from ..config import settings

logger = logging.getLogger(__name__)


class AuthService:
    """JWT 토큰 기반 인증 서비스"""
    
    def __init__(self):
        self.secret_key = settings.JWT_SECRET_KEY
        self.algorithm = settings.JWT_ALGORITHM
    
    async def get_user_from_token(self, authorization: str) -> str:
        """Authorization 헤더에서 사용자 ID 추출"""
        try:
            # Bearer 토큰 추출
            if not authorization.startswith("Bearer "):
                raise HTTPException(status_code=401, detail="Invalid authorization header")
            
            token = authorization[7:]  # "Bearer " 제거
            
            # JWT 디코딩 (실제로는 Cognito JWT 검증 필요)
            # 여기서는 간단한 예시로 구현
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            user_id = payload.get("sub")
            
            if not user_id:
                raise HTTPException(status_code=401, detail="Invalid token payload")
            
            return user_id
            
        except jwt.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Token has expired")
        except jwt.InvalidTokenError:
            raise HTTPException(status_code=401, detail="Invalid token")
        except Exception as e:
            logger.error(f"Token validation error: {e}")
            raise HTTPException(status_code=401, detail="Authentication failed")
    
    async def get_user_role(self, user_id: str) -> str:
        """사용자 역할 조회 (실제로는 데이터베이스에서 조회)"""
        # 임시 구현 - 실제로는 데이터베이스에서 조회해야 함
        return "user"
    
    def create_token(self, user_id: str, role: str = "user") -> str:
        """JWT 토큰 생성 (테스트용)"""
        import datetime
        
        payload = {
            "sub": user_id,
            "role": role,
            "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=settings.JWT_EXPIRE_MINUTES),
            "iat": datetime.datetime.utcnow()
        }
        
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)