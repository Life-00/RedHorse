"""
엔진 테스트
"""

import pytest
from unittest.mock import AsyncMock, MagicMock
from datetime import datetime, timedelta

from ..engines.shift_to_sleep import ShiftToSleepEngine
from ..engines.caffeine_cutoff import CaffeineCutoffEngine
from ..engines.fatigue_risk import FatigueRiskEngine
from ..engines.daily_jumpstart import DailyJumpstartEngine
from ..engines.sleep_quality import SleepQualityEngine
from ..engines.meal_time_checker import MealTimeCheckerEngine
from ..models.common import (
    ShiftToSleepRequest, CaffeineCutoffRequest, FatigueRiskRequest,
    DailyJumpstartRequest, SleepQualityRequest, MealTimeRequest,
    UserProfile, ShiftSchedule, ShiftType, UserShiftType
)
from ..utils.time_utils import TimeUtils


@pytest.fixture
def mock_cache_service():
    """모킹된 캐시 서비스"""
    cache = AsyncMock()
    cache.get.return_value = None  # 캐시 미스 시뮬레이션
    cache.set.return_value = True
    return cache


@pytest.fixture
def mock_db_service():
    """모킹된 데이터베이스 서비스"""
    db = AsyncMock()
    
    # 샘플 사용자 프로필
    db.get_user_profile.return_value = UserProfile(
        userId="test-user-id",
        cognitoSub="test-cognito-sub",
        shiftType=UserShiftType.THREE_SHIFT,
        commuteMin=30,
        wearableConnected=True,
        orgId=None,
        lastActiveAt=TimeUtils.now_kst(),
        createdAt=TimeUtils.now_kst(),
        updatedAt=TimeUtils.now_kst()
    )
    
    # 샘플 근무표
    today = TimeUtils.today_kst()
    work_start = TimeUtils.parse_datetime(f"{today}T09:00:00+09:00")
    work_end = TimeUtils.parse_datetime(f"{today}T18:00:00+09:00")
    
    db.get_schedule_by_date.return_value = ShiftSchedule(
        scheduleId="test-schedule-id",
        userId="test-user-id",
        date=today,
        shiftType=ShiftType.DAY,
        startAt=TimeUtils.format_datetime(work_start),
        endAt=TimeUtils.format_datetime(work_end),
        commuteMin=30,
        note=None,
        createdAt=TimeUtils.now_kst(),
        updatedAt=TimeUtils.now_kst()
    )
    
    db.get_schedules_in_range.return_value = []
    db.get_upcoming_schedules.return_value = []
    db.get_sleep_data.return_value = None
    
    return db


class TestShiftToSleepEngine:
    """Shift-to-Sleep 엔진 테스트"""
    
    @pytest.mark.asyncio
    async def test_calculate_success(self, mock_cache_service, mock_db_service):
        """정상적인 수면창 계산 테스트"""
        engine = ShiftToSleepEngine(mock_cache_service, mock_db_service)
        
        request = ShiftToSleepRequest(
            userId="test-user-id",
            targetDate=TimeUtils.today_kst(),
            sleepDurationHours=8.0,
            bufferMinutes=30
        )
        
        result = await engine.calculate(request, "test-correlation-id")
        
        assert result.result is not None
        assert "sleepMain" in result.result
        assert result.generatedAt is not None
        assert result.correlationId == "test-correlation-id"
    
    @pytest.mark.asyncio
    async def test_calculate_insufficient_data(self, mock_cache_service, mock_db_service):
        """데이터 부족 시 테스트"""
        # 사용자 프로필 없음 시뮬레이션
        mock_db_service.get_user_profile.return_value = None
        
        engine = ShiftToSleepEngine(mock_cache_service, mock_db_service)
        
        request = ShiftToSleepRequest(
            userId="nonexistent-user",
            targetDate=TimeUtils.today_kst()
        )
        
        result = await engine.calculate(request, "test-correlation-id")
        
        assert result.result is None
        assert result.whyNotShown == "INSUFFICIENT_DATA"
        assert "USER_PROFILE" in result.dataMissing
    
    @pytest.mark.asyncio
    async def test_cache_hit(self, mock_cache_service, mock_db_service):
        """캐시 히트 테스트"""
        # 캐시된 결과 시뮬레이션
        cached_result = {
            "sleepMain": {
                "startAt": "2024-01-26T22:00:00+09:00",
                "endAt": "2024-01-27T06:00:00+09:00",
                "durationHours": 8.0,
                "quality": "good"
            },
            "recommendations": ["충분한 수면을 취하세요"]
        }
        mock_cache_service.get.return_value = cached_result
        
        engine = ShiftToSleepEngine(mock_cache_service, mock_db_service)
        
        request = ShiftToSleepRequest(
            userId="test-user-id",
            targetDate=TimeUtils.today_kst()
        )
        
        result = await engine.calculate(request, "test-correlation-id")
        
        assert result.result == cached_result
        # 데이터베이스 호출이 없어야 함
        mock_db_service.get_user_profile.assert_not_called()


class TestCaffeineCutoffEngine:
    """Caffeine Cutoff 엔진 테스트"""
    
    @pytest.mark.asyncio
    async def test_calculate_success(self, mock_cache_service, mock_db_service):
        """정상적인 카페인 마감시간 계산 테스트"""
        engine = CaffeineCutoffEngine(mock_cache_service, mock_db_service)
        
        request = CaffeineCutoffRequest(
            userId="test-user-id",
            targetDate=TimeUtils.today_kst(),
            targetSleepTime="2024-01-26T22:00:00+09:00",
            caffeineAmountMg=100.0
        )
        
        result = await engine.calculate(request, "test-correlation-id")
        
        assert result.result is not None
        assert "caffeineDeadline" in result.result
        assert "halfLifeInfo" in result.result
        assert result.generatedAt is not None
    
    @pytest.mark.asyncio
    async def test_beverage_cutoffs(self, mock_cache_service, mock_db_service):
        """음료별 마감시간 계산 테스트"""
        engine = CaffeineCutoffEngine(mock_cache_service, mock_db_service)
        
        caffeine_info = engine.get_caffeine_content_info()
        
        assert "coffee_regular" in caffeine_info
        assert "tea_green" in caffeine_info
        assert caffeine_info["coffee_regular"]["caffeineMg"] == 100
        assert caffeine_info["tea_green"]["caffeineMg"] == 28


class TestFatigueRiskEngine:
    """Fatigue Risk 엔진 테스트"""
    
    @pytest.mark.asyncio
    async def test_calculate_success(self, mock_cache_service, mock_db_service):
        """정상적인 피로도 계산 테스트"""
        # 최근 근무표 데이터 설정
        recent_schedules = [
            {
                "date": "2024-01-25",
                "shift_type": "NIGHT",
                "start_at": "2024-01-25T22:00:00+09:00",
                "end_at": "2024-01-26T06:00:00+09:00"
            },
            {
                "date": "2024-01-26",
                "shift_type": "NIGHT", 
                "start_at": "2024-01-26T22:00:00+09:00",
                "end_at": "2024-01-27T06:00:00+09:00"
            }
        ]
        mock_db_service.get_schedules_in_range.return_value = recent_schedules
        
        engine = FatigueRiskEngine(mock_cache_service, mock_db_service)
        
        request = FatigueRiskRequest(
            userId="test-user-id",
            targetDate=TimeUtils.today_kst(),
            assessmentPeriodDays=7
        )
        
        result = await engine.calculate(request, "test-correlation-id")
        
        assert result.result is not None
        assert "fatigueScore" in result.result
        assert "riskLevel" in result.result
        assert "breakdown" in result.result
        assert result.result["riskLevel"] in ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
    
    @pytest.mark.asyncio
    async def test_high_fatigue_night_shifts(self, mock_cache_service, mock_db_service):
        """야간 근무 많을 때 높은 피로도 테스트"""
        # 연속 야간 근무 시뮬레이션
        recent_schedules = []
        for i in range(5):  # 5일 연속 야간 근무
            date = (datetime.now().date() - timedelta(days=i)).isoformat()
            recent_schedules.append({
                "date": date,
                "shift_type": "NIGHT",
                "start_at": f"{date}T22:00:00+09:00",
                "end_at": f"{(datetime.now().date() - timedelta(days=i-1)).isoformat()}T06:00:00+09:00"
            })
        
        mock_db_service.get_schedules_in_range.return_value = recent_schedules
        
        engine = FatigueRiskEngine(mock_cache_service, mock_db_service)
        
        request = FatigueRiskRequest(
            userId="test-user-id",
            targetDate=TimeUtils.today_kst(),
            assessmentPeriodDays=7
        )
        
        result = await engine.calculate(request, "test-correlation-id")
        
        assert result.result is not None
        assert result.result["fatigueScore"] > 50  # 높은 피로도 예상
        assert result.result["riskLevel"] in ["HIGH", "CRITICAL"]


class TestDailyJumpstartEngine:
    """Daily Jumpstart Plan 엔진 테스트"""
    
    @pytest.mark.asyncio
    async def test_calculate_success(self, mock_cache_service, mock_db_service):
        """정상적인 일일 계획 생성 테스트"""
        engine = DailyJumpstartEngine(mock_cache_service, mock_db_service)
        
        request = DailyJumpstartRequest(
            userId="test-user-id",
            targetDate=TimeUtils.today_kst(),
            preferredActivities=["light_exercise", "meditation"],
            availableTimeMinutes=60
        )
        
        result = await engine.calculate(request, "test-correlation-id")
        
        assert result.result is not None
        assert "workSituation" in result.result
        assert "recommendedActivities" in result.result
        assert "timeBlocks" in result.result
        assert "dailyGoals" in result.result
        assert "motivationMessage" in result.result
    
    @pytest.mark.asyncio
    async def test_night_shift_activities(self, mock_cache_service, mock_db_service):
        """야간 근무 시 활동 추천 테스트"""
        # 야간 근무 스케줄 설정
        today = TimeUtils.today_kst()
        night_schedule = ShiftSchedule(
            scheduleId="test-schedule-id",
            userId="test-user-id",
            date=today,
            shiftType=ShiftType.NIGHT,
            startAt=f"{today}T22:00:00+09:00",
            endAt=f"{TimeUtils.tomorrow_kst()}T06:00:00+09:00",
            commuteMin=30,
            note=None,
            createdAt=TimeUtils.now_kst(),
            updatedAt=TimeUtils.now_kst()
        )
        mock_db_service.get_schedule_by_date.return_value = night_schedule
        
        engine = DailyJumpstartEngine(mock_cache_service, mock_db_service)
        
        request = DailyJumpstartRequest(
            userId="test-user-id",
            targetDate=today
        )
        
        result = await engine.calculate(request, "test-correlation-id")
        
        assert result.result is not None
        assert result.result["workSituation"]["type"] == "NIGHT"
        # 야간 근무에 적합한 활동이 포함되어야 함
        activities = result.result["recommendedActivities"]
        activity_ids = [activity["id"] for activity in activities]
        assert "energy_boost" in activity_ids or "hydration" in activity_ids


class TestSleepQualityEngine:
    """Sleep Quality Tracker 엔진 테스트"""
    
    @pytest.mark.asyncio
    async def test_calculate_with_wearable_data(self, mock_cache_service, mock_db_service):
        """웨어러블 데이터 포함 수면 품질 분석 테스트"""
        # 웨어러블 수면 데이터 설정
        sleep_data = {
            "sleepSessions": [
                {
                    "bedtime": "2024-01-25T22:30:00+09:00",
                    "wakeTime": "2024-01-26T06:30:00+09:00",
                    "durationHours": 8.0,
                    "sleepEfficiency": 85
                },
                {
                    "bedtime": "2024-01-26T23:00:00+09:00",
                    "wakeTime": "2024-01-27T07:00:00+09:00",
                    "durationHours": 8.0,
                    "sleepEfficiency": 90
                }
            ],
            "averageSleepHours": 8.0
        }
        mock_db_service.get_sleep_data.return_value = sleep_data
        
        engine = SleepQualityEngine(mock_cache_service, mock_db_service)
        
        request = SleepQualityRequest(
            userId="test-user-id",
            targetDate=TimeUtils.today_kst(),
            assessmentPeriodDays=7,
            includeWearableData=True
        )
        
        result = await engine.calculate(request, "test-correlation-id")
        
        assert result.result is not None
        assert "qualityScore" in result.result
        assert "qualityGrade" in result.result
        assert "sleepMetrics" in result.result
        assert result.result["qualityGrade"] in ["A", "B", "C", "D", "F"]
        assert result.result["dataSource"] == "wearable"
    
    @pytest.mark.asyncio
    async def test_calculate_without_wearable_data(self, mock_cache_service, mock_db_service):
        """웨어러블 데이터 없이 수면 품질 분석 테스트"""
        # 웨어러블 연결 안됨 설정
        user_profile = UserProfile(
            userId="test-user-id",
            cognitoSub="test-cognito-sub",
            shiftType=UserShiftType.THREE_SHIFT,
            commuteMin=30,
            wearableConnected=False,  # 웨어러블 연결 안됨
            orgId=None,
            lastActiveAt=TimeUtils.now_kst(),
            createdAt=TimeUtils.now_kst(),
            updatedAt=TimeUtils.now_kst()
        )
        mock_db_service.get_user_profile.return_value = user_profile
        mock_db_service.get_sleep_data.return_value = None
        
        engine = SleepQualityEngine(mock_cache_service, mock_db_service)
        
        request = SleepQualityRequest(
            userId="test-user-id",
            targetDate=TimeUtils.today_kst(),
            includeWearableData=False
        )
        
        result = await engine.calculate(request, "test-correlation-id")
        
        assert result.result is not None
        assert result.result["dataSource"] == "estimated"
        assert "sleepMetrics" in result.result


class TestMealTimeCheckerEngine:
    """Meal Time Checker 엔진 테스트"""
    
    @pytest.mark.asyncio
    async def test_calculate_day_shift_meal_timing(self, mock_cache_service, mock_db_service):
        """주간 근무 시 식사 시간 체크 테스트"""
        engine = MealTimeCheckerEngine(mock_cache_service, mock_db_service)
        
        request = MealTimeRequest(
            userId="test-user-id",
            targetDate=TimeUtils.today_kst(),
            mealType="lunch",
            currentTime="2024-01-26T12:00:00+09:00"
        )
        
        result = await engine.calculate(request, "test-correlation-id")
        
        assert result.result is not None
        assert "currentMealWindow" in result.result
        assert "nextMealTime" in result.result
        assert "mealSchedule" in result.result
        assert "nutritionTips" in result.result
        assert "shiftWorkAdvice" in result.result
        assert "hydrationReminder" in result.result
    
    @pytest.mark.asyncio
    async def test_night_shift_meal_advice(self, mock_cache_service, mock_db_service):
        """야간 근무 시 식사 조언 테스트"""
        # 야간 근무 스케줄 설정
        today = TimeUtils.today_kst()
        night_schedule = ShiftSchedule(
            scheduleId="test-schedule-id",
            userId="test-user-id",
            date=today,
            shiftType=ShiftType.NIGHT,
            startAt=f"{today}T22:00:00+09:00",
            endAt=f"{TimeUtils.tomorrow_kst()}T06:00:00+09:00",
            commuteMin=30,
            note=None,
            createdAt=TimeUtils.now_kst(),
            updatedAt=TimeUtils.now_kst()
        )
        mock_db_service.get_schedule_by_date.return_value = night_schedule
        
        engine = MealTimeCheckerEngine(mock_cache_service, mock_db_service)
        
        request = MealTimeRequest(
            userId="test-user-id",
            targetDate=today,
            currentTime=f"{today}T20:00:00+09:00"  # 야간 근무 2시간 전
        )
        
        result = await engine.calculate(request, "test-correlation-id")
        
        assert result.result is not None
        advice = result.result["shiftWorkAdvice"]
        assert advice["title"] == "야간 근무 식사 가이드"
        assert "생체리듬" in advice["mainAdvice"]
    
    @pytest.mark.asyncio
    async def test_off_day_meal_schedule(self, mock_cache_service, mock_db_service):
        """휴무일 식사 스케줄 테스트"""
        # 휴무일 스케줄 설정
        today = TimeUtils.today_kst()
        off_schedule = ShiftSchedule(
            scheduleId="test-schedule-id",
            userId="test-user-id",
            date=today,
            shiftType=ShiftType.OFF,
            startAt=None,
            endAt=None,
            commuteMin=0,
            note=None,
            createdAt=TimeUtils.now_kst(),
            updatedAt=TimeUtils.now_kst()
        )
        mock_db_service.get_schedule_by_date.return_value = off_schedule
        
        engine = MealTimeCheckerEngine(mock_cache_service, mock_db_service)
        
        request = MealTimeRequest(
            userId="test-user-id",
            targetDate=today,
            currentTime=f"{today}T10:00:00+09:00"
        )
        
        result = await engine.calculate(request, "test-correlation-id")
        
        assert result.result is not None
        meal_schedule = result.result["mealSchedule"]
        assert len(meal_schedule) >= 3  # 최소 3끼 식사
        
        # 휴무일 조언 확인
        advice = result.result["shiftWorkAdvice"]
        assert advice["title"] == "휴무일 식사 가이드"


@pytest.mark.asyncio
async def test_engine_error_handling(mock_cache_service):
    """엔진 에러 처리 테스트"""
    # 데이터베이스 에러 시뮬레이션
    mock_db_service = AsyncMock()
    mock_db_service.get_user_profile.side_effect = Exception("Database connection failed")
    
    engine = ShiftToSleepEngine(mock_cache_service, mock_db_service)
    
    request = ShiftToSleepRequest(
        userId="test-user-id",
        targetDate=TimeUtils.today_kst()
    )
    
    result = await engine.calculate(request, "test-correlation-id")
    
    assert result.result is None
    assert result.whyNotShown == "CALCULATION_ERROR"
    assert result.generatedAt is not None