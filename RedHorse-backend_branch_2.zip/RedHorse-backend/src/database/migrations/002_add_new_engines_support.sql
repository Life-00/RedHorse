-- 마이그레이션: 새로운 엔진 지원 추가
-- 버전: 002
-- 설명: Daily Jumpstart, Sleep Quality, Meal Time Checker 엔진 지원

-- 1. engine_cache 테이블의 engine_type 제약조건 업데이트
ALTER TABLE engine_cache 
DROP CONSTRAINT IF EXISTS engine_cache_engine_type_check;

ALTER TABLE engine_cache 
ADD CONSTRAINT engine_cache_engine_type_check 
CHECK (engine_type IN ('SHIFT_TO_SLEEP', 'CAFFEINE_CUTOFF', 'FATIGUE_RISK', 'DAILY_JUMPSTART', 'SLEEP_QUALITY', 'MEAL_TIME_CHECKER'));

-- 2. sleep_data 테이블 생성 (수면 데이터 - 웨어러블 연동)
CREATE TABLE IF NOT EXISTS sleep_data (
    sleep_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    sleep_date DATE NOT NULL,
    bedtime TIMESTAMPTZ,
    wake_time TIMESTAMPTZ,
    duration_hours DECIMAL(4,2) CHECK (duration_hours >= 0 AND duration_hours <= 24),
    sleep_efficiency INTEGER CHECK (sleep_efficiency >= 0 AND sleep_efficiency <= 100), -- 퍼센트
    deep_sleep_minutes INTEGER CHECK (deep_sleep_minutes >= 0),
    rem_sleep_minutes INTEGER CHECK (rem_sleep_minutes >= 0),
    light_sleep_minutes INTEGER CHECK (light_sleep_minutes >= 0),
    awake_minutes INTEGER CHECK (awake_minutes >= 0),
    sleep_score INTEGER CHECK (sleep_score >= 0 AND sleep_score <= 100), -- 웨어러블 점수
    data_source VARCHAR(20) DEFAULT 'wearable' CHECK (data_source IN ('wearable', 'manual', 'estimated')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    
    -- 제약 조건
    CONSTRAINT unique_user_sleep_date UNIQUE (user_id, sleep_date)
);

-- 인덱스
CREATE INDEX IF NOT EXISTS idx_sleep_data_user_date ON sleep_data(user_id, sleep_date);
CREATE INDEX IF NOT EXISTS idx_sleep_data_date_range ON sleep_data(user_id, sleep_date) WHERE duration_hours IS NOT NULL;

-- 3. meal_records 테이블 생성 (식사 기록)
CREATE TABLE IF NOT EXISTS meal_records (
    meal_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    meal_date DATE NOT NULL,
    meal_type VARCHAR(20) NOT NULL CHECK (meal_type IN ('breakfast', 'lunch', 'dinner', 'snack', 'midnight_meal')),
    meal_time TIMESTAMPTZ NOT NULL,
    duration_minutes INTEGER CHECK (duration_minutes > 0 AND duration_minutes <= 120),
    satisfaction_score INTEGER CHECK (satisfaction_score >= 1 AND satisfaction_score <= 5), -- 1-5 점수
    notes TEXT CHECK (LENGTH(notes) <= 500),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 인덱스
CREATE INDEX IF NOT EXISTS idx_meal_records_user_date ON meal_records(user_id, meal_date);
CREATE INDEX IF NOT EXISTS idx_meal_records_user_type ON meal_records(user_id, meal_type);
CREATE INDEX IF NOT EXISTS idx_meal_records_meal_time ON meal_records(user_id, meal_time);

-- 4. 새로운 테이블들에 대한 트리거 추가
CREATE TRIGGER update_sleep_data_updated_at BEFORE UPDATE ON sleep_data
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_meal_records_updated_at BEFORE UPDATE ON meal_records
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 5. 기본 점프스타트 체크리스트 항목 추가 (기존 사용자용)
INSERT INTO jumpstart_checklists (user_id, item_key, title, description)
SELECT 
    u.user_id,
    t.item_key,
    t.title,
    t.description
FROM users u
CROSS JOIN (VALUES
    ('daily_plan_check', '일일 계획 확인', '개인화된 일일 점프스타트 계획을 확인해보세요'),
    ('sleep_quality_review', '수면 품질 검토', '수면 품질 분석 결과를 확인해보세요'),
    ('meal_timing_optimize', '식사 시간 최적화', '교대근무에 맞는 식사 시간을 확인해보세요')
) AS t(item_key, title, description)
WHERE NOT EXISTS (
    SELECT 1 FROM jumpstart_checklists jc 
    WHERE jc.user_id = u.user_id AND jc.item_key = t.item_key
);

-- 6. 코멘트 추가
COMMENT ON TABLE sleep_data IS '수면 데이터 - 웨어러블 기기 연동';
COMMENT ON TABLE meal_records IS '식사 기록 - Meal Time Checker 엔진용';

COMMENT ON COLUMN sleep_data.sleep_efficiency IS '수면 효율성 (0-100%)';
COMMENT ON COLUMN sleep_data.data_source IS '데이터 소스: wearable, manual, estimated';
COMMENT ON COLUMN meal_records.satisfaction_score IS '식사 만족도 (1-5점)';

-- 완료 메시지
DO $$
BEGIN
    RAISE NOTICE '새로운 엔진 지원 마이그레이션 완료';
    RAISE NOTICE '추가된 테이블: sleep_data, meal_records';
    RAISE NOTICE '업데이트된 제약조건: engine_cache.engine_type';
    RAISE NOTICE '새로운 엔진: DAILY_JUMPSTART, SLEEP_QUALITY, MEAL_TIME_CHECKER';
END $$;